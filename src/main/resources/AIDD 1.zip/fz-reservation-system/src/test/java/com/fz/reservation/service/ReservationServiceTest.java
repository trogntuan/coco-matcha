package com.fz.reservation.service;

import com.fz.reservation.domain.entity.Reservation;
import com.fz.reservation.domain.entity.Seat;
import com.fz.reservation.domain.enums.ReservationStatus;
import com.fz.reservation.domain.enums.SeatStatus;
import com.fz.reservation.dto.request.ReservationRequest;
import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.exception.BusinessException;
import com.fz.reservation.exception.ResourceNotFoundException;
import com.fz.reservation.repository.ReservationRepository;
import com.fz.reservation.repository.SeatRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ReservationServiceTest {

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private SeatRepository seatRepository;

    @InjectMocks
    private ReservationService reservationService;

    private Seat testSeat;
    private Reservation testReservation;
    private ReservationRequest testReservationRequest;
    private Integer testEmployeeId;

    @BeforeEach
    void setUp() {
        testEmployeeId = 1;
        
        testSeat = new Seat();
        testSeat.setId(1);
        testSeat.setFloorId(1);
        testSeat.setName("A101");
        testSeat.setStatus(SeatStatus.AVAILABLE);
        
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime startTime = now.plusHours(1);
        LocalDateTime endTime = now.plusHours(3);
        
        testReservation = new Reservation();
        testReservation.setId(1);
        testReservation.setEmployeeId(testEmployeeId);
        testReservation.setSeatId(testSeat.getId());
        testReservation.setStartTime(startTime);
        testReservation.setEndTime(endTime);
        testReservation.setStatus(ReservationStatus.RESERVED);
        testReservation.setCreatedAt(now);
        
        testReservationRequest = new ReservationRequest();
        testReservationRequest.setSeatId(testSeat.getId());
        testReservationRequest.setStartTime(startTime);
        testReservationRequest.setEndTime(endTime);
    }

    @Test
    void getReservationsByEmployeeId_ShouldReturnReservations() {
        // Arrange
        List<Reservation> reservations = Arrays.asList(testReservation);
        when(reservationRepository.findActiveReservationsByEmployeeId(testEmployeeId)).thenReturn(reservations);
        when(seatRepository.findById(testSeat.getId())).thenReturn(Optional.of(testSeat));
        
        // Act
        List<ReservationResponse> result = reservationService.getReservationsByEmployeeId(testEmployeeId);
        
        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(testReservation.getId(), result.get(0).getId());
        assertEquals(testReservation.getEmployeeId(), result.get(0).getEmployeeId());
        assertEquals(testReservation.getSeatId(), result.get(0).getSeatId());
        assertEquals(testSeat.getName(), result.get(0).getSeatName());
    }

    @Test
    void createReservation_WithValidRequest_ShouldCreateReservation() {
        // Arrange
        when(seatRepository.findById(testSeat.getId())).thenReturn(Optional.of(testSeat));
        when(reservationRepository.countOverlappingReservations(
                eq(testSeat.getId()), 
                any(LocalDateTime.class), 
                any(LocalDateTime.class))).thenReturn(0);
        when(reservationRepository.save(any(Reservation.class))).thenAnswer(invocation -> {
            Reservation savedReservation = invocation.getArgument(0);
            savedReservation.setId(1);
            return savedReservation;
        });
        
        // Act
        ReservationResponse result = reservationService.createReservation(testEmployeeId, testReservationRequest);
        
        // Assert
        assertNotNull(result);
        assertEquals(testSeat.getId(), result.getSeatId());
        assertEquals(ReservationStatus.PENDING, result.getStatus());
        verify(reservationRepository).save(any(Reservation.class));
    }

    @Test
    void createReservation_WithNonExistentSeat_ShouldThrowException() {
        // Arrange
        when(seatRepository.findById(testSeat.getId())).thenReturn(Optional.empty());
        
        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> {
            reservationService.createReservation(testEmployeeId, testReservationRequest);
        });
    }

    @Test
    void createReservation_WithOverlappingReservation_ShouldThrowException() {
        // Arrange
        when(seatRepository.findById(testSeat.getId())).thenReturn(Optional.of(testSeat));
        when(reservationRepository.countOverlappingReservations(
                eq(testSeat.getId()), 
                any(LocalDateTime.class), 
                any(LocalDateTime.class))).thenReturn(1);
        
        // Act & Assert
        assertThrows(BusinessException.class, () -> {
            reservationService.createReservation(testEmployeeId, testReservationRequest);
        });
    }

    @Test
    void checkIn_WithValidReservation_ShouldUpdateStatus() {
        // Arrange
        testReservation.setStartTime(LocalDateTime.now().minusMinutes(10));
        when(reservationRepository.findById(testReservation.getId())).thenReturn(Optional.of(testReservation));
        when(seatRepository.findById(testSeat.getId())).thenReturn(Optional.of(testSeat));
        when(reservationRepository.save(any(Reservation.class))).thenReturn(testReservation);
        
        // Act
        ReservationResponse result = reservationService.checkIn(testReservation.getId(), testEmployeeId);
        
        // Assert
        assertNotNull(result);
        assertEquals(ReservationStatus.IN_USE, result.getStatus());
        verify(seatRepository).save(any(Seat.class));
    }

    @Test
    void checkIn_WithInvalidStatus_ShouldThrowException() {
        // Arrange
        testReservation.setStatus(ReservationStatus.PENDING);
        when(reservationRepository.findById(testReservation.getId())).thenReturn(Optional.of(testReservation));
        
        // Act & Assert
        assertThrows(BusinessException.class, () -> {
            reservationService.checkIn(testReservation.getId(), testEmployeeId);
        });
    }

    @Test
    void returnSeat_WithValidReservation_ShouldUpdateStatus() {
        // Arrange
        testReservation.setStatus(ReservationStatus.IN_USE);
        when(reservationRepository.findById(testReservation.getId())).thenReturn(Optional.of(testReservation));
        when(seatRepository.findById(testSeat.getId())).thenReturn(Optional.of(testSeat));
        when(reservationRepository.save(any(Reservation.class))).thenReturn(testReservation);
        
        // Act
        ReservationResponse result = reservationService.returnSeat(testReservation.getId(), testEmployeeId);
        
        // Assert
        assertNotNull(result);
        assertEquals(ReservationStatus.COMPLETED, result.getStatus());
        verify(seatRepository).save(any(Seat.class));
    }

    @Test
    void returnSeat_WithInvalidStatus_ShouldThrowException() {
        // Arrange
        testReservation.setStatus(ReservationStatus.RESERVED);
        when(reservationRepository.findById(testReservation.getId())).thenReturn(Optional.of(testReservation));
        
        // Act & Assert
        assertThrows(BusinessException.class, () -> {
            reservationService.returnSeat(testReservation.getId(), testEmployeeId);
        });
    }
}
