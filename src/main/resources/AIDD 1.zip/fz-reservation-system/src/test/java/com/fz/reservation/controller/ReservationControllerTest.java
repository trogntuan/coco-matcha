package com.fz.reservation.controller;

import com.fz.reservation.dto.request.ReservationRequest;
import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.service.ReservationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ReservationController.class)
public class ReservationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReservationService reservationService;

    private ReservationResponse testReservationResponse;
    private String testReservationRequestJson;

    @BeforeEach
    void setUp() {
        testReservationResponse = new ReservationResponse();
        testReservationResponse.setId(1);
        testReservationResponse.setEmployeeId(1);
        testReservationResponse.setSeatId(1);
        testReservationResponse.setSeatName("A101");
        testReservationResponse.setFloorId(1);
        testReservationResponse.setFloor(1);
        testReservationResponse.setBuildingId(1);
        testReservationResponse.setBuildingName("Building A");
        testReservationResponse.setStartTime(LocalDateTime.now().plusHours(1));
        testReservationResponse.setEndTime(LocalDateTime.now().plusHours(3));
        
        testReservationRequestJson = "{"
                + "\"seatId\": 1,"
                + "\"startTime\": \"" + LocalDateTime.now().plusHours(1) + "\","
                + "\"endTime\": \"" + LocalDateTime.now().plusHours(3) + "\""
                + "}";
    }

    @Test
    @WithMockUser(username = "1", roles = "USER")
    void getMyReservations_ShouldReturnReservations() throws Exception {
        // Arrange
        List<ReservationResponse> reservations = Arrays.asList(testReservationResponse);
        when(reservationService.getReservationsByEmployeeId(eq(1))).thenReturn(reservations);

        // Act & Assert
        mockMvc.perform(get("/api/reservations/my")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(testReservationResponse.getId()))
                .andExpect(jsonPath("$[0].employeeId").value(testReservationResponse.getEmployeeId()))
                .andExpect(jsonPath("$[0].seatId").value(testReservationResponse.getSeatId()));
    }

    @Test
    @WithMockUser(username = "1", roles = "USER")
    void createReservation_ShouldCreateAndReturnReservation() throws Exception {
        // Arrange
        when(reservationService.createReservation(eq(1), any(ReservationRequest.class)))
                .thenReturn(testReservationResponse);

        // Act & Assert
        mockMvc.perform(post("/api/reservations")
                .contentType(MediaType.APPLICATION_JSON)
                .content(testReservationRequestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(testReservationResponse.getId()))
                .andExpect(jsonPath("$.employeeId").value(testReservationResponse.getEmployeeId()))
                .andExpect(jsonPath("$.seatId").value(testReservationResponse.getSeatId()));
    }

    @Test
    @WithMockUser(username = "1", roles = "USER")
    void checkIn_ShouldUpdateAndReturnReservation() throws Exception {
        // Arrange
        when(reservationService.checkIn(eq(1), eq(1))).thenReturn(testReservationResponse);

        // Act & Assert
        mockMvc.perform(post("/api/reservations/1/check-in")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(testReservationResponse.getId()))
                .andExpect(jsonPath("$.employeeId").value(testReservationResponse.getEmployeeId()))
                .andExpect(jsonPath("$.seatId").value(testReservationResponse.getSeatId()));
    }

    @Test
    @WithMockUser(username = "1", roles = "USER")
    void returnSeat_ShouldUpdateAndReturnReservation() throws Exception {
        // Arrange
        when(reservationService.returnSeat(eq(1), eq(1))).thenReturn(testReservationResponse);

        // Act & Assert
        mockMvc.perform(post("/api/reservations/1/return")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(testReservationResponse.getId()))
                .andExpect(jsonPath("$.employeeId").value(testReservationResponse.getEmployeeId()))
                .andExpect(jsonPath("$.seatId").value(testReservationResponse.getSeatId()));
    }
}
