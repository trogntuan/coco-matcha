CREATE TABLE BUILDING (
    id INT IDENTITY PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL
);

CREATE TABLE FLOOR (
    id INT IDENTITY PRIMARY KEY,
    building_id INT NOT NULL,
    floor INT NOT NULL,
    FOREIGN KEY (building_id) REFERENCES BUILDING(id)
);

CREATE TABLE SEAT (
    id INT IDENTITY PRIMARY KEY,
    floor_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
    FOREIGN KEY (floor_id) REFERENCES FLOOR(id)
);

CREATE TABLE RESERVATION (
    id INT IDENTITY PRIMARY KEY,
    employee_id INT NOT NULL,
    seat_id INT NOT NULL,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    status VARCHAR(20) NOT NULL,
    check_in_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL,
    extended_from_reservation_id INT NULL,
    FOREIGN KEY (seat_id) REFERENCES SEAT(id)
);

-- Sample data for testing
INSERT INTO BUILDING (name, address) VALUES 
('Building A', '123 Main Street'),
('Building B', '456 Park Avenue');

INSERT INTO FLOOR (building_id, floor) VALUES 
(1, 1), (1, 2), (1, 3),
(2, 1), (2, 2);

INSERT INTO SEAT (floor_id, name, status) VALUES 
-- Building A, Floor 1
(1, 'A101', 'AVAILABLE'),
(1, 'A102', 'AVAILABLE'),
(1, 'A103', 'AVAILABLE'),
-- Building A, Floor 2
(2, 'A201', 'AVAILABLE'),
(2, 'A202', 'AVAILABLE'),
-- Building A, Floor 3
(3, 'A301', 'AVAILABLE'),
(3, 'A302', 'AVAILABLE'),
-- Building B, Floor 1
(4, 'B101', 'AVAILABLE'),
(4, 'B102', 'AVAILABLE'),
-- Building B, Floor 2
(5, 'B201', 'AVAILABLE'),
(5, 'B202', 'AVAILABLE');
