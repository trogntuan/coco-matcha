package com.fz.reservation.dto.response;

import lombok.Data;
import java.util.List;

@Data
public class FloorResponse {
    private Integer id;
    private Integer buildingId;
    private Integer floor;
    private List<SeatResponse> seats;
}
