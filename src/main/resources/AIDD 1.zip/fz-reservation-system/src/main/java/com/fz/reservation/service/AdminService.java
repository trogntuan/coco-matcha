package com.fz.reservation.service;

import com.fz.reservation.domain.entity.Reservation;
import com.fz.reservation.domain.entity.Seat;
import com.fz.reservation.domain.enums.ReservationStatus;
import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.dto.response.SeatResponse;
import com.fz.reservation.exception.BusinessException;
import com.fz.reservation.exception.ResourceNotFoundException;
import com.fz.reservation.repository.ReservationRepository;
import com.fz.reservation.repository.SeatRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdminService {

    private final ReservationRepository reservationRepository;
    private final SeatRepository seatRepository;
    private final ReservationService reservationService;

    public AdminService(ReservationRepository reservationRepository, SeatRepository seatRepository, ReservationService reservationService) {
        this.reservationRepository = reservationRepository;
        this.seatRepository = seatRepository;
        this.reservationService = reservationService;
    }

    public List<SeatResponse> getSeatDetails(Integer floorId) {
        List<Seat> seats;
        if (floorId != null) {
            seats = seatRepository.findByFloorId(floorId);
        } else {
            // This would need to be implemented in the repository
            throw new UnsupportedOperationException("Getting all seats is not implemented");
        }
        
        return seats.stream()
                .map(seat -> {
                    SeatResponse response = new SeatResponse();
                    response.setId(seat.getId());
                    response.setFloorId(seat.getFloorId());
                    response.setName(seat.getName());
                    response.setStatus(seat.getStatus());
                    return response;
                })
                .collect(Collectors.toList());
    }

    @Transactional
    public ReservationResponse forceReturnSeat(Integer seatId) {
        // Find active reservation for this seat
        List<Reservation> activeReservations = reservationRepository.findActiveReservationsByEmployeeId(null); // This would need to be modified to find by seat ID
        
        Reservation activeReservation = activeReservations.stream()
                .filter(r -> r.getSeatId().equals(seatId) && r.getStatus() == ReservationStatus.IN_USE)
                .findFirst()
                .orElseThrow(() -> new BusinessException("No active reservation found for seat ID: " + seatId));
        
        // Update reservation status
        activeReservation.setStatus(ReservationStatus.FORCED_CANCEL);
        Reservation updatedReservation = reservationRepository.save(activeReservation);
        
        // Update seat status
        Seat seat = seatRepository.findById(seatId)
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + seatId));
        seat.setStatus(com.fz.reservation.domain.enums.SeatStatus.AVAILABLE);
        seatRepository.save(seat);
        
        return reservationService.mapToReservationResponse(updatedReservation);
    }
}
