package com.fz.reservation.repository;

import com.fz.reservation.domain.entity.Floor;
import com.fz.reservation.mapper.FloorMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class FloorRepository {
    
    private final FloorMapper floorMapper;
    
    public FloorRepository(FloorMapper floorMapper) {
        this.floorMapper = floorMapper;
    }
    
    public List<Floor> findByBuildingId(Integer buildingId) {
        return floorMapper.findByBuildingId(buildingId);
    }
    
    public Optional<Floor> findById(Integer id) {
        return floorMapper.findById(id);
    }
}
