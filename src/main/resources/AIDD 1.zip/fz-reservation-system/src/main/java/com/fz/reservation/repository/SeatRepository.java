package com.fz.reservation.repository;

import com.fz.reservation.domain.entity.Seat;
import com.fz.reservation.domain.enums.SeatStatus;
import com.fz.reservation.mapper.SeatMapper;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public class SeatRepository {
    
    private final SeatMapper seatMapper;
    
    public SeatRepository(SeatMapper seatMapper) {
        this.seatMapper = seatMapper;
    }
    
    public Optional<Seat> findById(Integer id) {
        return seatMapper.findById(id);
    }
    
    public List<Seat> findByFloorId(Integer floorId) {
        return seatMapper.findByFloorId(floorId);
    }
    
    public List<Seat> findAvailableSeats(Integer floorId, Integer buildingId, LocalDateTime startTime, LocalDateTime endTime) {
        return seatMapper.findAvailableSeats(floorId, buildingId, startTime, endTime);
    }
    
    public boolean updateStatus(Integer id, SeatStatus status) {
        return seatMapper.updateStatus(id, status) > 0;
    }
    
    public Seat save(Seat seat) {
        if (seat.getId() == null) {
            // Implementation for insert if needed
            throw new UnsupportedOperationException("Insert operation not implemented");
        } else {
            seatMapper.updateStatus(seat.getId(), seat.getStatus());
            return seat;
        }
    }
}
