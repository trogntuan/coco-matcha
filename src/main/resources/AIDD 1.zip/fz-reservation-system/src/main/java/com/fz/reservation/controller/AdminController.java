package com.fz.reservation.controller;

import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.dto.response.SeatResponse;
import com.fz.reservation.service.AdminService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/seats/details")
    public ResponseEntity<List<SeatResponse>> getSeatDetails(@RequestParam(required = false) Integer floorId) {
        return ResponseEntity.ok(adminService.getSeatDetails(floorId));
    }

    @PostMapping("/seats/{id}/force-return")
    public ResponseEntity<ReservationResponse> forceReturnSeat(@PathVariable Integer id) {
        return ResponseEntity.ok(adminService.forceReturnSeat(id));
    }
}
