package com.fz.reservation.domain.entity;

import com.fz.reservation.domain.enums.ReservationStatus;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Reservation {
    private Integer id;
    private Integer employeeId;
    private Integer seatId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private ReservationStatus status;
    private LocalDateTime checkInAt;
    private LocalDateTime createdAt;
    private Integer extendedFromReservationId;
}
