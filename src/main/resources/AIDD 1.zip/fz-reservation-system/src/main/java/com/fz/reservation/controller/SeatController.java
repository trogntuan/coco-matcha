package com.fz.reservation.controller;

import com.fz.reservation.dto.request.SeatAvailabilityRequest;
import com.fz.reservation.dto.response.SeatResponse;
import com.fz.reservation.service.SeatService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/seats")
public class SeatController {

    private final SeatService seatService;

    public SeatController(SeatService seatService) {
        this.seatService = seatService;
    }

    @GetMapping("/floor/{floorId}")
    public ResponseEntity<List<SeatResponse>> getSeatsByFloorId(@PathVariable Integer floorId) {
        return ResponseEntity.ok(seatService.getSeatsByFloorId(floorId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<SeatResponse> getSeatById(@PathVariable Integer id) {
        return ResponseEntity.ok(seatService.getSeatById(id));
    }

    @PostMapping("/available")
    public ResponseEntity<List<SeatResponse>> getAvailableSeats(@Valid @RequestBody SeatAvailabilityRequest request) {
        return ResponseEntity.ok(seatService.getAvailableSeats(request));
    }
}
