package com.fz.reservation.controller;

import com.fz.reservation.dto.request.ReservationRequest;
import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.service.ReservationService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @PostMapping
    public ResponseEntity<ReservationResponse> createReservation(
            @Valid @RequestBody ReservationRequest request,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.createReservation(employeeId, request));
    }

    @GetMapping("/my")
    public ResponseEntity<List<ReservationResponse>> getMyReservations(Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.getReservationsByEmployeeId(employeeId));
    }

    @GetMapping("/my/history")
    public ResponseEntity<List<ReservationResponse>> getMyReservationHistory(Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.getReservationHistoryByEmployeeId(employeeId));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<ReservationResponse> cancelReservation(
            @PathVariable Integer id,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.cancelReservation(id, employeeId));
    }

    @PostMapping("/{id}/check-in")
    public ResponseEntity<ReservationResponse> checkIn(
            @PathVariable Integer id,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.checkIn(id, employeeId));
    }

    @PostMapping("/{id}/return")
    public ResponseEntity<ReservationResponse> returnSeat(
            @PathVariable Integer id,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.returnSeat(id, employeeId));
    }

    @PostMapping("/{id}/extend")
    public ResponseEntity<ReservationResponse> extendReservation(
            @PathVariable Integer id,
            @Valid @RequestBody ReservationRequest request,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.extendReservation(id, employeeId, request));
    }
}
