package com.fz.reservation.mapper;

import com.fz.reservation.domain.entity.Seat;
import com.fz.reservation.domain.enums.SeatStatus;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Mapper
public interface SeatMapper {
    
    @Select("SELECT * FROM SEAT WHERE id = #{id}")
    Optional<Seat> findById(@Param("id") Integer id);
    
    @Select("SELECT * FROM SEAT WHERE floor_id = #{floorId}")
    List<Seat> findByFloorId(@Param("floorId") Integer floorId);
    
    @Select({
        "SELECT s.* FROM SEAT s",
        "WHERE s.status = 'AVAILABLE'",
        "<if test='floorId != null'>",
        "AND s.floor_id = #{floorId}",
        "</if>",
        "<if test='buildingId != null'>",
        "AND s.floor_id IN (SELECT id FROM FLOOR WHERE building_id = #{buildingId})",
        "</if>",
        "AND s.id NOT IN (",
        "  SELECT r.seat_id FROM RESERVATION r",
        "  WHERE r.status IN ('RESERVED', 'IN_USE', 'PENDING')",
        "  AND NOT (r.end_time <= #{startTime} OR r.start_time >= #{endTime})",
        ")"
    })
    List<Seat> findAvailableSeats(
        @Param("floorId") Integer floorId,
        @Param("buildingId") Integer buildingId,
        @Param("startTime") LocalDateTime startTime,
        @Param("endTime") LocalDateTime endTime
    );
    
    @Update("UPDATE SEAT SET status = #{status} WHERE id = #{id}")
    int updateStatus(@Param("id") Integer id, @Param("status") SeatStatus status);
}
