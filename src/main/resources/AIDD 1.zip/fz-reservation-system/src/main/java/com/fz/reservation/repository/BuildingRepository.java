package com.fz.reservation.repository;

import com.fz.reservation.domain.entity.Building;
import com.fz.reservation.mapper.BuildingMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class BuildingRepository {
    
    private final BuildingMapper buildingMapper;
    
    public BuildingRepository(BuildingMapper buildingMapper) {
        this.buildingMapper = buildingMapper;
    }
    
    public List<Building> findAll() {
        return buildingMapper.findAll();
    }
    
    public Optional<Building> findById(Integer id) {
        return buildingMapper.findById(id);
    }
}
