package com.fz.reservation.dto.response;

import com.fz.reservation.domain.enums.SeatStatus;
import lombok.Data;

@Data
public class SeatResponse {
    private Integer id;
    private Integer floorId;
    private String name;
    private SeatStatus status;
}
