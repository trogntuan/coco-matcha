package com.fz.reservation.mapper;

import com.fz.reservation.domain.entity.Floor;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Optional;

@Mapper
public interface FloorMapper {
    
    @Select("SELECT * FROM FLOOR WHERE building_id = #{buildingId}")
    List<Floor> findByBuildingId(@Param("buildingId") Integer buildingId);
    
    @Select("SELECT * FROM FLOOR WHERE id = #{id}")
    Optional<Floor> findById(@Param("id") Integer id);
}
