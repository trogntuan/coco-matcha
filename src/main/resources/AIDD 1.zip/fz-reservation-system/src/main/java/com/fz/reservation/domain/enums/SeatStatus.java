package com.fz.reservation.domain.enums;

public enum SeatStatus {
    AVAILABLE,      // Ghế có sẵn để đặt
    UNAVAILABLE     // Ghế đang được sử dụng
}
