package com.fz.reservation.controller;

import com.fz.reservation.dto.response.FloorResponse;
import com.fz.reservation.service.FloorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/floors")
public class FloorController {

    private final FloorService floorService;

    public FloorController(FloorService floorService) {
        this.floorService = floorService;
    }

    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<FloorResponse>> getFloorsByBuildingId(@PathVariable Integer buildingId) {
        return ResponseEntity.ok(floorService.getFloorsByBuildingId(buildingId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<FloorResponse> getFloorById(@PathVariable Integer id) {
        return ResponseEntity.ok(floorService.getFloorById(id));
    }
}
