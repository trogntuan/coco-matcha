package com.fz.reservation.repository;

import com.fz.reservation.domain.entity.Reservation;
import com.fz.reservation.domain.enums.ReservationStatus;
import com.fz.reservation.mapper.ReservationMapper;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public class ReservationRepository {
    
    private final ReservationMapper reservationMapper;
    
    public ReservationRepository(ReservationMapper reservationMapper) {
        this.reservationMapper = reservationMapper;
    }
    
    public Optional<Reservation> findById(Integer id) {
        return reservationMapper.findById(id);
    }
    
    public List<Reservation> findActiveReservationsByEmployeeId(Integer employeeId) {
        return reservationMapper.findActiveReservationsByEmployeeId(employeeId);
    }
    
    public List<Reservation> findReservationHistoryByEmployeeId(Integer employeeId, LocalDateTime since) {
        return reservationMapper.findReservationHistoryByEmployeeId(employeeId, since);
    }
    
    public int countOverlappingReservations(Integer seatId, LocalDateTime startTime, LocalDateTime endTime) {
        return reservationMapper.countOverlappingReservations(seatId, startTime, endTime);
    }
    
    public List<Reservation> findPendingReservations() {
        return reservationMapper.findPendingReservations();
    }
    
    public List<Reservation> findExpiredReservations(LocalDateTime cutoffTime) {
        return reservationMapper.findExpiredReservations(cutoffTime);
    }
    
    public List<Reservation> findExpiredInUseReservations() {
        return reservationMapper.findExpiredInUseReservations();
    }
    
    public Reservation save(Reservation reservation) {
        if (reservation.getId() == null) {
            reservationMapper.save(reservation);
        } else {
            reservationMapper.update(reservation);
        }
        return reservation;
    }
    
    public boolean updateStatus(Integer id, ReservationStatus status) {
        return reservationMapper.updateStatus(id, status) > 0;
    }
}
