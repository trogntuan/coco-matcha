package com.fz.reservation.service;

import com.fz.reservation.dto.response.BuildingResponse;
import com.fz.reservation.exception.ResourceNotFoundException;
import com.fz.reservation.repository.BuildingRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BuildingService {

    private final BuildingRepository buildingRepository;

    public BuildingService(BuildingRepository buildingRepository) {
        this.buildingRepository = buildingRepository;
    }

    public List<BuildingResponse> getAllBuildings() {
        return buildingRepository.findAll().stream()
                .map(building -> {
                    BuildingResponse response = new BuildingResponse();
                    response.setId(building.getId());
                    response.setName(building.getName());
                    response.setAddress(building.getAddress());
                    return response;
                })
                .collect(Collectors.toList());
    }

    public BuildingResponse getBuildingById(Integer id) {
        return buildingRepository.findById(id)
                .map(building -> {
                    BuildingResponse response = new BuildingResponse();
                    response.setId(building.getId());
                    response.setName(building.getName());
                    response.setAddress(building.getAddress());
                    return response;
                })
                .orElseThrow(() -> new ResourceNotFoundException("Building not found with id: " + id));
    }
}
