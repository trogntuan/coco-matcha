package com.fz.reservation.mapper;

import com.fz.reservation.domain.entity.Building;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Optional;

@Mapper
public interface BuildingMapper {
    
    @Select("SELECT * FROM BUILDING")
    List<Building> findAll();
    
    @Select("SELECT * FROM BUILDING WHERE id = #{id}")
    Optional<Building> findById(@Param("id") Integer id);
}
