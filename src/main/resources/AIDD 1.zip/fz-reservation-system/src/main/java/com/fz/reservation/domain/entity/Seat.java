package com.fz.reservation.domain.entity;

import com.fz.reservation.domain.enums.SeatStatus;
import lombok.Data;

@Data
public class Seat {
    private Integer id;
    private Integer floorId;
    private String name;
    private SeatStatus status;
}
