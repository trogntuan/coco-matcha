package com.fz.reservation.service;

import com.fz.reservation.dto.response.FloorResponse;
import com.fz.reservation.dto.response.SeatResponse;
import com.fz.reservation.exception.ResourceNotFoundException;
import com.fz.reservation.repository.FloorRepository;
import com.fz.reservation.repository.SeatRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FloorService {

    private final FloorRepository floorRepository;
    private final SeatRepository seatRepository;

    public FloorService(FloorRepository floorRepository, SeatRepository seatRepository) {
        this.floorRepository = floorRepository;
        this.seatRepository = seatRepository;
    }

    public List<FloorResponse> getFloorsByBuildingId(Integer buildingId) {
        return floorRepository.findByBuildingId(buildingId).stream()
                .map(floor -> {
                    FloorResponse response = new FloorResponse();
                    response.setId(floor.getId());
                    response.setBuildingId(floor.getBuildingId());
                    response.setFloor(floor.getFloor());
                    
                    // Optionally load seats for each floor
                    List<SeatResponse> seats = seatRepository.findByFloorId(floor.getId()).stream()
                            .map(seat -> {
                                SeatResponse seatResponse = new SeatResponse();
                                seatResponse.setId(seat.getId());
                                seatResponse.setFloorId(seat.getFloorId());
                                seatResponse.setName(seat.getName());
                                seatResponse.setStatus(seat.getStatus());
                                return seatResponse;
                            })
                            .collect(Collectors.toList());
                    
                    response.setSeats(seats);
                    return response;
                })
                .collect(Collectors.toList());
    }

    public FloorResponse getFloorById(Integer id) {
        return floorRepository.findById(id)
                .map(floor -> {
                    FloorResponse response = new FloorResponse();
                    response.setId(floor.getId());
                    response.setBuildingId(floor.getBuildingId());
                    response.setFloor(floor.getFloor());
                    
                    // Load seats for this floor
                    List<SeatResponse> seats = seatRepository.findByFloorId(floor.getId()).stream()
                            .map(seat -> {
                                SeatResponse seatResponse = new SeatResponse();
                                seatResponse.setId(seat.getId());
                                seatResponse.setFloorId(seat.getFloorId());
                                seatResponse.setName(seat.getName());
                                seatResponse.setStatus(seat.getStatus());
                                return seatResponse;
                            })
                            .collect(Collectors.toList());
                    
                    response.setSeats(seats);
                    return response;
                })
                .orElseThrow(() -> new ResourceNotFoundException("Floor not found with id: " + id));
    }
}
