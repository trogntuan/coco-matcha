package com.fz.reservation.mapper;

import com.fz.reservation.domain.entity.Reservation;
import com.fz.reservation.domain.enums.ReservationStatus;
import org.apache.ibatis.annotations.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Mapper
public interface ReservationMapper {
    
    @Select("SELECT * FROM RESERVATION WHERE id = #{id}")
    Optional<Reservation> findById(@Param("id") Integer id);
    
    @Select("SELECT * FROM RESERVATION WHERE employee_id = #{employeeId} AND status IN ('PENDING', 'RESERVED', 'IN_USE') ORDER BY start_time DESC")
    List<Reservation> findActiveReservationsByEmployeeId(@Param("employeeId") Integer employeeId);
    
    @Select("SELECT * FROM RESERVATION WHERE employee_id = #{employeeId} AND created_at >= #{since} AND status IN ('CANCELLED', 'NO_SHOW', 'COMPLETED', 'FORCED_CANCEL', 'FAIL') ORDER BY created_at DESC")
    List<Reservation> findReservationHistoryByEmployeeId(@Param("employeeId") Integer employeeId, @Param("since") LocalDateTime since);
    
    @Select("SELECT COUNT(*) FROM RESERVATION WHERE seat_id = #{seatId} AND status IN ('RESERVED', 'IN_USE', 'PENDING') AND NOT (end_time <= #{startTime} OR start_time >= #{endTime})")
    int countOverlappingReservations(@Param("seatId") Integer seatId, @Param("startTime") LocalDateTime startTime, @Param("endTime") LocalDateTime endTime);
    
    @Select("SELECT * FROM RESERVATION WHERE status = 'PENDING'")
    List<Reservation> findPendingReservations();
    
    @Select("SELECT * FROM RESERVATION WHERE status = 'RESERVED' AND start_time < #{cutoffTime}")
    List<Reservation> findExpiredReservations(@Param("cutoffTime") LocalDateTime cutoffTime);
    
    @Select("SELECT * FROM RESERVATION WHERE status = 'IN_USE' AND end_time < CURRENT_TIMESTAMP")
    List<Reservation> findExpiredInUseReservations();
    
    @Insert("INSERT INTO RESERVATION (employee_id, seat_id, start_time, end_time, status, check_in_at, created_at, extended_from_reservation_id) VALUES (#{employeeId}, #{seatId}, #{startTime}, #{endTime}, #{status}, #{checkInAt}, #{createdAt}, #{extendedFromReservationId})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int save(Reservation reservation);
    
    @Update("UPDATE RESERVATION SET employee_id = #{employeeId}, seat_id = #{seatId}, start_time = #{startTime}, end_time = #{endTime}, status = #{status}, check_in_at = #{checkInAt}, extended_from_reservation_id = #{extendedFromReservationId} WHERE id = #{id}")
    int update(Reservation reservation);
    
    @Update("UPDATE RESERVATION SET status = #{status} WHERE id = #{id}")
    int updateStatus(@Param("id") Integer id, @Param("status") ReservationStatus status);
}
