package com.fz.reservation.client;

import com.fz.reservation.dto.response.TokenValidationResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class HrManagementClient {
    private final RestTemplate restTemplate;
    private final String hrManagementBaseUrl;

    public HrManagementClient(
            RestTemplate restTemplate,
            @Value("${hr.management.base-url}") String hrManagementBaseUrl) {
        this.restTemplate = restTemplate;
        this.hrManagementBaseUrl = hrManagementBaseUrl;
    }

    public TokenValidationResponse validateToken(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        
        String requestBody = "{\"authorization\": \"Bearer " + token + "\"}";
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        
        ResponseEntity<TokenValidationResponse> response = restTemplate.exchange(
                hrManagementBaseUrl + "/auth/validate",
                HttpMethod.POST,
                entity,
                TokenValidationResponse.class
        );
        
        return response.getBody();
    }
}
