package com.fz.reservation.dto.response;

import com.fz.reservation.domain.enums.ReservationStatus;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ReservationResponse {
    private Integer id;
    private Integer employeeId;
    private Integer seatId;
    private String seatName;
    private Integer floorId;
    private Integer floor;
    private Integer buildingId;
    private String buildingName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private ReservationStatus status;
    private LocalDateTime checkInAt;
    private LocalDateTime createdAt;
    private Integer extendedFromReservationId;
}
