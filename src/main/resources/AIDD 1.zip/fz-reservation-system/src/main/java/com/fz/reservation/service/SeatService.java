package com.fz.reservation.service;

import com.fz.reservation.domain.entity.Seat;
import com.fz.reservation.dto.request.SeatAvailabilityRequest;
import com.fz.reservation.dto.response.SeatResponse;
import com.fz.reservation.exception.ResourceNotFoundException;
import com.fz.reservation.repository.SeatRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SeatService {

    private final SeatRepository seatRepository;

    public SeatService(SeatRepository seatRepository) {
        this.seatRepository = seatRepository;
    }

    public List<SeatResponse> getSeatsByFloorId(Integer floorId) {
        return seatRepository.findByFloorId(floorId).stream()
                .map(this::mapToSeatResponse)
                .collect(Collectors.toList());
    }

    public SeatResponse getSeatById(Integer id) {
        return seatRepository.findById(id)
                .map(this::mapToSeatResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + id));
    }

    public List<SeatResponse> getAvailableSeats(SeatAvailabilityRequest request) {
        return seatRepository.findAvailableSeats(
                request.getFloorId(),
                request.getBuildingId(),
                request.getStartTime(),
                request.getEndTime()
            ).stream()
            .map(this::mapToSeatResponse)
            .collect(Collectors.toList());
    }

    private SeatResponse mapToSeatResponse(Seat seat) {
        SeatResponse response = new SeatResponse();
        response.setId(seat.getId());
        response.setFloorId(seat.getFloorId());
        response.setName(seat.getName());
        response.setStatus(seat.getStatus());
        return response;
    }
}
