package com.fz.reservation.domain.enums;

public enum ReservationStatus {
    PENDING,        // Yêu cầu đặt chỗ, đang chờ phê duyệt
    RESERVED,       // Đã xác nhận, chưa sử dụng
    IN_USE,         // Người dùng đã check-in
    CANCELLED,      // Người dùng đã hủy
    NO_SHOW,        // Đã đặt nhưng không check-in
    COMPLETED,      // Hoàn thành bình thường hoặc Trả sớm
    FORCED_CANCEL,  // Bị quản trị viên buộc trả
    FAIL            // Đặt chỗ thất bại
}
