package com.fz.reservation.dto.request;

import lombok.Data;

@Data
public class TokenValidationRequest {
    private String authorization;
}
