package com.fz.reservation.domain.entity;

import lombok.Data;

@Data
public class Building {
    private Integer id;
    private String name;
    private String address;
}
