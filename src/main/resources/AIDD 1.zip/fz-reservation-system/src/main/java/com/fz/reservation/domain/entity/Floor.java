package com.fz.reservation.domain.entity;

import lombok.Data;

@Data
public class Floor {
    private Integer id;
    private Integer buildingId;
    private Integer floor;
}
