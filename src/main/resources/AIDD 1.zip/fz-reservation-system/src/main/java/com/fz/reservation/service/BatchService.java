package com.fz.reservation.service;

import com.fz.reservation.domain.entity.Reservation;
import com.fz.reservation.domain.enums.ReservationStatus;
import com.fz.reservation.domain.enums.SeatStatus;
import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.repository.ReservationRepository;
import com.fz.reservation.repository.SeatRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BatchService {

    private final ReservationRepository reservationRepository;
    private final SeatRepository seatRepository;
    
    @Value("${reservation.batch.seat-accept-duration-seconds:60}")
    private Integer seatAcceptDurationSeconds;
    
    @Value("${reservation.batch.no-show-limit-minutes:30}")
    private Integer noShowLimitMinutes;

    public BatchService(ReservationRepository reservationRepository, SeatRepository seatRepository) {
        this.reservationRepository = reservationRepository;
        this.seatRepository = seatRepository;
    }

    @Scheduled(fixedRateString = "${reservation.batch.pending-check-rate-ms:60000}")
    @Transactional
    public void updatePendingToReserved() {
        List<Reservation> pendingReservations = reservationRepository.findPendingReservations();
        
        for (Reservation reservation : pendingReservations) {
            // Check if the reservation has been in PENDING state for more than the configured duration
            if (reservation.getCreatedAt().plusSeconds(seatAcceptDurationSeconds).isBefore(LocalDateTime.now())) {
                // Check if the seat is still available for the requested time period
                if (reservationRepository.countOverlappingReservations(
                        reservation.getSeatId(), 
                        reservation.getStartTime(), 
                        reservation.getEndTime()) <= 1) { // Count includes this reservation
                    
                    reservation.setStatus(ReservationStatus.RESERVED);
                } else {
                    reservation.setStatus(ReservationStatus.FAIL);
                }
                
                reservationRepository.save(reservation);
            }
        }
    }

    @Scheduled(fixedRateString = "${reservation.batch.no-show-check-rate-ms:60000}")
    @Transactional
    public void updateReservedToNoShow() {
        LocalDateTime cutoffTime = LocalDateTime.now().minusMinutes(noShowLimitMinutes);
        List<Reservation> expiredReservations = reservationRepository.findExpiredReservations(cutoffTime);
        
        for (Reservation reservation : expiredReservations) {
            reservation.setStatus(ReservationStatus.NO_SHOW);
            reservationRepository.save(reservation);
        }
    }

    @Scheduled(fixedRateString = "${reservation.batch.completion-check-rate-ms:60000}")
    @Transactional
    public void updateInUseToCompleted() {
        List<Reservation> expiredInUseReservations = reservationRepository.findExpiredInUseReservations();
        
        for (Reservation reservation : expiredInUseReservations) {
            // Update reservation status
            reservation.setStatus(ReservationStatus.COMPLETED);
            reservationRepository.save(reservation);
            
            // Update seat status
            seatRepository.updateStatus(reservation.getSeatId(), SeatStatus.AVAILABLE);
        }
    }
}
