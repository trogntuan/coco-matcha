package com.fz.reservation.service;

import com.fz.reservation.domain.entity.Reservation;
import com.fz.reservation.domain.entity.Seat;
import com.fz.reservation.domain.enums.ReservationStatus;
import com.fz.reservation.domain.enums.SeatStatus;
import com.fz.reservation.dto.request.ReservationRequest;
import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.exception.BusinessException;
import com.fz.reservation.exception.ResourceNotFoundException;
import com.fz.reservation.repository.ReservationRepository;
import com.fz.reservation.repository.SeatRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final SeatRepository seatRepository;

    public ReservationService(ReservationRepository reservationRepository, SeatRepository seatRepository) {
        this.reservationRepository = reservationRepository;
        this.seatRepository = seatRepository;
    }

    public List<ReservationResponse> getReservationsByEmployeeId(Integer employeeId) {
        List<Reservation> reservations = reservationRepository.findActiveReservationsByEmployeeId(employeeId);
        return mapToReservationResponses(reservations);
    }

    public List<ReservationResponse> getReservationHistoryByEmployeeId(Integer employeeId) {
        LocalDateTime oneMonthAgo = LocalDateTime.now().minusMonths(1);
        List<Reservation> reservations = reservationRepository.findReservationHistoryByEmployeeId(employeeId, oneMonthAgo);
        return mapToReservationResponses(reservations);
    }

    @Transactional
    public ReservationResponse createReservation(Integer employeeId, ReservationRequest request) {
        // Validate request
        validateReservationRequest(request);
        
        // Check if seat exists
        Seat seat = seatRepository.findById(request.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + request.getSeatId()));
        
        // Check if seat is available for the requested time period
        if (!isSeatAvailable(request.getSeatId(), request.getStartTime(), request.getEndTime())) {
            throw new BusinessException("Seat is not available for the requested time period");
        }
        
        // Create reservation
        Reservation reservation = new Reservation();
        reservation.setEmployeeId(employeeId);
        reservation.setSeatId(request.getSeatId());
        reservation.setStartTime(request.getStartTime());
        reservation.setEndTime(request.getEndTime());
        reservation.setStatus(ReservationStatus.PENDING);
        reservation.setCreatedAt(LocalDateTime.now());
        
        Reservation savedReservation = reservationRepository.save(reservation);
        
        return mapToReservationResponse(savedReservation);
    }

    @Transactional
    public ReservationResponse cancelReservation(Integer reservationId, Integer employeeId) {
        Reservation reservation = getReservationForEmployee(reservationId, employeeId);
        
        if (reservation.getStatus() != ReservationStatus.PENDING && reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new BusinessException("Only PENDING or RESERVED reservations can be cancelled");
        }
        
        reservation.setStatus(ReservationStatus.CANCELLED);
        Reservation updatedReservation = reservationRepository.save(reservation);
        
        return mapToReservationResponse(updatedReservation);
    }

    @Transactional
    public ReservationResponse checkIn(Integer reservationId, Integer employeeId) {
        Reservation reservation = getReservationForEmployee(reservationId, employeeId);
        
        if (reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new BusinessException("Only RESERVED reservations can be checked in");
        }
        
        LocalDateTime now = LocalDateTime.now();
        
        if (now.isBefore(reservation.getStartTime().minusMinutes(30))) {
            throw new BusinessException("Check-in is only allowed 30 minutes before the reservation start time");
        }
        
        if (now.isAfter(reservation.getStartTime().plusMinutes(30))) {
            throw new BusinessException("Check-in is only allowed up to 30 minutes after the reservation start time");
        }
        
        // Update reservation status
        reservation.setStatus(ReservationStatus.IN_USE);
        reservation.setCheckInAt(now);
        Reservation updatedReservation = reservationRepository.save(reservation);
        
        // Update seat status
        Seat seat = seatRepository.findById(reservation.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + reservation.getSeatId()));
        seat.setStatus(SeatStatus.UNAVAILABLE);
        seatRepository.save(seat);
        
        return mapToReservationResponse(updatedReservation);
    }

    @Transactional
    public ReservationResponse returnSeat(Integer reservationId, Integer employeeId) {
        Reservation reservation = getReservationForEmployee(reservationId, employeeId);
        
        if (reservation.getStatus() != ReservationStatus.IN_USE) {
            throw new BusinessException("Only IN_USE reservations can be returned");
        }
        
        // Update reservation status
        reservation.setStatus(ReservationStatus.COMPLETED);
        Reservation updatedReservation = reservationRepository.save(reservation);
        
        // Update seat status
        Seat seat = seatRepository.findById(reservation.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + reservation.getSeatId()));
        seat.setStatus(SeatStatus.AVAILABLE);
        seatRepository.save(seat);
        
        return mapToReservationResponse(updatedReservation);
    }

    @Transactional
    public ReservationResponse extendReservation(Integer reservationId, Integer employeeId, ReservationRequest request) {
        Reservation currentReservation = getReservationForEmployee(reservationId, employeeId);
        
        if (currentReservation.getStatus() != ReservationStatus.IN_USE) {
            throw new BusinessException("Only IN_USE reservations can be extended");
        }
        
        // Validate extension request
        if (!request.getStartTime().isEqual(currentReservation.getEndTime())) {
            throw new BusinessException("Extension start time must be equal to current reservation end time");
        }
        
        if (request.getEndTime().isBefore(request.getStartTime())) {
            throw new BusinessException("Extension end time must be after start time");
        }
        
        // Check if seat is available for the extended time period
        if (!isSeatAvailable(currentReservation.getSeatId(), request.getStartTime(), request.getEndTime())) {
            throw new BusinessException("Seat is not available for the requested extension period");
        }
        
        // Create new reservation for the extended period
        Reservation newReservation = new Reservation();
        newReservation.setEmployeeId(employeeId);
        newReservation.setSeatId(currentReservation.getSeatId());
        newReservation.setStartTime(request.getStartTime());
        newReservation.setEndTime(request.getEndTime());
        newReservation.setStatus(ReservationStatus.IN_USE);
        newReservation.setCreatedAt(LocalDateTime.now());
        newReservation.setCheckInAt(LocalDateTime.now());
        newReservation.setExtendedFromReservationId(currentReservation.getId());
        
        Reservation savedReservation = reservationRepository.save(newReservation);
        
        return mapToReservationResponse(savedReservation);
    }

    private Reservation getReservationForEmployee(Integer reservationId, Integer employeeId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found with id: " + reservationId));
        
        if (!reservation.getEmployeeId().equals(employeeId)) {
            throw new BusinessException("You don't have permission to access this reservation");
        }
        
        return reservation;
    }

    private boolean isSeatAvailable(Integer seatId, LocalDateTime startTime, LocalDateTime endTime) {
        return reservationRepository.countOverlappingReservations(seatId, startTime, endTime) == 0;
    }

    private void validateReservationRequest(ReservationRequest request) {
        if (request.getStartTime().isAfter(request.getEndTime())) {
            throw new BusinessException("Start time must be before end time");
        }
        
        if (request.getStartTime().isBefore(LocalDateTime.now())) {
            throw new BusinessException("Start time must be in the future");
        }
        
        if (request.getEndTime().isAfter(request.getStartTime().plusHours(8))) {
            throw new BusinessException("Reservation duration cannot exceed 8 hours");
        }
    }

    private List<ReservationResponse> mapToReservationResponses(List<Reservation> reservations) {
        return reservations.stream()
                .map(this::mapToReservationResponse)
                .collect(Collectors.toList());
    }

    private ReservationResponse mapToReservationResponse(Reservation reservation) {
        ReservationResponse response = new ReservationResponse();
        response.setId(reservation.getId());
        response.setEmployeeId(reservation.getEmployeeId());
        response.setSeatId(reservation.getSeatId());
        
        // Get seat details
        Seat seat = seatRepository.findById(reservation.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + reservation.getSeatId()));
        response.setSeatName(seat.getName());
        response.setFloorId(seat.getFloorId());
        
        // Get floor and building details from repositories
        // This would be implemented with additional repository calls
        
        response.setStartTime(reservation.getStartTime());
        response.setEndTime(reservation.getEndTime());
        response.setStatus(reservation.getStatus());
        response.setCheckInAt(reservation.getCheckInAt());
        response.setCreatedAt(reservation.getCreatedAt());
        response.setExtendedFromReservationId(reservation.getExtendedFromReservationId());
        
        return response;
    }
}
