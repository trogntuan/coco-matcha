package com.fz.reservation.dto.response;

import lombok.Data;

@Data
public class TokenValidationResponse {
    private boolean isValid;
    private Integer employeeId;
    private boolean isAdmin;
    private String message;
}
