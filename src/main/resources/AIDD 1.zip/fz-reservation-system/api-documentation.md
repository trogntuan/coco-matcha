# API Documentation - FZ Reservation System

## Overview

This document provides details about the REST API endpoints available in the FZ Reservation System. The system is designed to manage office seat reservations in a shared workspace environment.

## Base URL

```
http://[server-address]:8080/api
```

## Authentication

All API endpoints (except for building and floor information) require authentication using JWT tokens. The authentication is handled by the HR Management Server.

To authenticate:

1. Obtain a token from the HR Management Server by calling `/auth/login` endpoint
2. Include the token in the Authorization header of all requests:
   ```
   Authorization: Bearer [your-token]
   ```

## API Endpoints

### Buildings

#### Get All Buildings

```
GET /buildings
```

Returns a list of all available buildings.

**Response:**
```json
[
  {
    "id": 1,
    "name": "Building A",
    "address": "123 Main Street"
  },
  {
    "id": 2,
    "name": "Building B",
    "address": "456 Park Avenue"
  }
]
```

#### Get Building by ID

```
GET /buildings/{id}
```

Returns details of a specific building.

**Response:**
```json
{
  "id": 1,
  "name": "Building A",
  "address": "123 Main Street",
  "floors": [
    {
      "id": 1,
      "buildingId": 1,
      "floor": 1
    }
  ]
}
```

### Floors

#### Get Floors by Building ID

```
GET /floors/building/{buildingId}
```

Returns all floors in a specific building.

**Response:**
```json
[
  {
    "id": 1,
    "buildingId": 1,
    "floor": 1,
    "seats": [
      {
        "id": 1,
        "floorId": 1,
        "name": "A101",
        "status": "AVAILABLE"
      }
    ]
  }
]
```

#### Get Floor by ID

```
GET /floors/{id}
```

Returns details of a specific floor.

**Response:**
```json
{
  "id": 1,
  "buildingId": 1,
  "floor": 1,
  "seats": [
    {
      "id": 1,
      "floorId": 1,
      "name": "A101",
      "status": "AVAILABLE"
    }
  ]
}
```

### Seats

#### Get Seats by Floor ID

```
GET /seats/floor/{floorId}
```

Returns all seats on a specific floor.

**Response:**
```json
[
  {
    "id": 1,
    "floorId": 1,
    "name": "A101",
    "status": "AVAILABLE"
  }
]
```

#### Get Seat by ID

```
GET /seats/{id}
```

Returns details of a specific seat.

**Response:**
```json
{
  "id": 1,
  "floorId": 1,
  "name": "A101",
  "status": "AVAILABLE"
}
```

#### Get Available Seats

```
POST /seats/available
```

Returns seats available for a specific time period.

**Request Body:**
```json
{
  "buildingId": 1,
  "floorId": 1,
  "startTime": "2025-05-30T09:00:00",
  "endTime": "2025-05-30T17:00:00"
}
```

**Response:**
```json
[
  {
    "id": 1,
    "floorId": 1,
    "name": "A101",
    "status": "AVAILABLE"
  }
]
```

### Reservations

#### Create Reservation

```
POST /reservations
```

Creates a new reservation.

**Request Body:**
```json
{
  "seatId": 1,
  "startTime": "2025-05-30T09:00:00",
  "endTime": "2025-05-30T17:00:00"
}
```

**Response:**
```json
{
  "id": 1,
  "employeeId": 1,
  "seatId": 1,
  "seatName": "A101",
  "floorId": 1,
  "floor": 1,
  "buildingId": 1,
  "buildingName": "Building A",
  "startTime": "2025-05-30T09:00:00",
  "endTime": "2025-05-30T17:00:00",
  "status": "PENDING",
  "createdAt": "2025-05-29T02:39:00"
}
```

#### Get My Reservations

```
GET /reservations/my
```

Returns all active reservations for the authenticated user.

**Response:**
```json
[
  {
    "id": 1,
    "employeeId": 1,
    "seatId": 1,
    "seatName": "A101",
    "floorId": 1,
    "floor": 1,
    "buildingId": 1,
    "buildingName": "Building A",
    "startTime": "2025-05-30T09:00:00",
    "endTime": "2025-05-30T17:00:00",
    "status": "RESERVED",
    "createdAt": "2025-05-29T02:39:00"
  }
]
```

#### Get My Reservation History

```
GET /reservations/my/history
```

Returns reservation history for the authenticated user (up to 1 month).

**Response:**
```json
[
  {
    "id": 1,
    "employeeId": 1,
    "seatId": 1,
    "seatName": "A101",
    "floorId": 1,
    "floor": 1,
    "buildingId": 1,
    "buildingName": "Building A",
    "startTime": "2025-04-30T09:00:00",
    "endTime": "2025-04-30T17:00:00",
    "status": "COMPLETED",
    "createdAt": "2025-04-29T02:39:00"
  }
]
```

#### Cancel Reservation

```
POST /reservations/{id}/cancel
```

Cancels a reservation.

**Response:**
```json
{
  "id": 1,
  "employeeId": 1,
  "seatId": 1,
  "seatName": "A101",
  "floorId": 1,
  "floor": 1,
  "buildingId": 1,
  "buildingName": "Building A",
  "startTime": "2025-05-30T09:00:00",
  "endTime": "2025-05-30T17:00:00",
  "status": "CANCELLED",
  "createdAt": "2025-05-29T02:39:00"
}
```

#### Check-in

```
POST /reservations/{id}/check-in
```

Checks in to a reservation.

**Response:**
```json
{
  "id": 1,
  "employeeId": 1,
  "seatId": 1,
  "seatName": "A101",
  "floorId": 1,
  "floor": 1,
  "buildingId": 1,
  "buildingName": "Building A",
  "startTime": "2025-05-30T09:00:00",
  "endTime": "2025-05-30T17:00:00",
  "status": "IN_USE",
  "checkInAt": "2025-05-30T09:05:00",
  "createdAt": "2025-05-29T02:39:00"
}
```

#### Return Seat

```
POST /reservations/{id}/return
```

Returns a seat before the reservation end time.

**Response:**
```json
{
  "id": 1,
  "employeeId": 1,
  "seatId": 1,
  "seatName": "A101",
  "floorId": 1,
  "floor": 1,
  "buildingId": 1,
  "buildingName": "Building A",
  "startTime": "2025-05-30T09:00:00",
  "endTime": "2025-05-30T17:00:00",
  "status": "COMPLETED",
  "checkInAt": "2025-05-30T09:05:00",
  "createdAt": "2025-05-29T02:39:00"
}
```

#### Extend Reservation

```
POST /reservations/{id}/extend
```

Extends the time of a reservation.

**Request Body:**
```json
{
  "seatId": 1,
  "startTime": "2025-05-30T17:00:00",
  "endTime": "2025-05-30T19:00:00"
}
```

**Response:**
```json
{
  "id": 2,
  "employeeId": 1,
  "seatId": 1,
  "seatName": "A101",
  "floorId": 1,
  "floor": 1,
  "buildingId": 1,
  "buildingName": "Building A",
  "startTime": "2025-05-30T17:00:00",
  "endTime": "2025-05-30T19:00:00",
  "status": "IN_USE",
  "checkInAt": "2025-05-30T16:55:00",
  "createdAt": "2025-05-30T16:55:00",
  "extendedFromReservationId": 1
}
```

### Admin Endpoints

#### Get Seat Details

```
GET /admin/seats/details?floorId={floorId}
```

Returns detailed information about seats on a specific floor.

**Response:**
```json
[
  {
    "id": 1,
    "floorId": 1,
    "name": "A101",
    "status": "UNAVAILABLE"
  }
]
```

#### Force Return Seat

```
POST /admin/seats/{id}/force-return
```

Forces the return of a seat that is currently in use.

**Response:**
```json
{
  "id": 1,
  "employeeId": 1,
  "seatId": 1,
  "seatName": "A101",
  "floorId": 1,
  "floor": 1,
  "buildingId": 1,
  "buildingName": "Building A",
  "startTime": "2025-05-30T09:00:00",
  "endTime": "2025-05-30T17:00:00",
  "status": "FORCED_CANCEL",
  "checkInAt": "2025-05-30T09:05:00",
  "createdAt": "2025-05-29T02:39:00"
}
```

## Error Responses

The API returns standard HTTP status codes along with a JSON response body for errors:

```json
{
  "status": 400,
  "message": "Error message"
}
```

For validation errors:

```json
{
  "status": 400,
  "message": "Validation failed",
  "errors": {
    "fieldName": "Error message for this field"
  }
}
```

## Reservation Status Flow

Reservations follow this status flow:

1. **PENDING**: Initial state after creation
2. **RESERVED**: Confirmed by batch process
3. **IN_USE**: After check-in
4. **COMPLETED**: After return or expiration
5. **CANCELLED**: Cancelled by user
6. **NO_SHOW**: No check-in within time limit
7. **FORCED_CANCEL**: Forced return by admin
8. **FAIL**: Failed reservation request
