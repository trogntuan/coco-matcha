# Deployment Guide - FZ Reservation System

## Overview

This document provides instructions for deploying the FZ Reservation System, which consists of a Java Spring Boot backend and integration with a Python HR Management Server.

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher
- HSQLDB (embedded, no separate installation required)
- Python 3.8 or higher (for HR Management Server)
- FastAPI (for HR Management Server)

## System Architecture

The system consists of two main components:

1. **FZ Reservation Server**: Java Spring Boot application that manages seat reservations
2. **HR Management Server**: Python FastAPI application that handles authentication and employee management

## Deployment Steps

### 1. Deploy HR Management Server

1. Navigate to the HR Management Server directory
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Start the server:
   ```
   uvicorn app.main:app --host 0.0.0.0 --port 8000
   ```

### 2. Deploy FZ Reservation Server

1. Navigate to the FZ Reservation Server directory
2. Build the application:
   ```
   mvn clean package
   ```
3. Run the application:
   ```
   java -jar target/reservation-0.0.1-SNAPSHOT.jar
   ```

### 3. Configuration

#### HR Management Server Configuration

The HR Management Server configuration is managed through environment variables:

- `DATABASE_URL`: Path to the SQLite database file
- `SECRET_KEY`: Secret key for JWT token generation
- `ALGORITHM`: Algorithm for JWT token generation (default: HS256)
- `ACCESS_TOKEN_EXPIRE_MINUTES`: Token expiration time in minutes (default: 30)

#### FZ Reservation Server Configuration

The FZ Reservation Server configuration is managed through `application.properties`:

```properties
# Server configuration
server.port=8080
server.servlet.context-path=/api

# Database configuration
spring.datasource.url=jdbc:hsqldb:file:./reservationdb;hsqldb.lock_file=false
spring.datasource.username=sa
spring.datasource.password=
spring.datasource.driver-class-name=org.hsqldb.jdbc.JDBCDriver

# HR Management Server configuration
hr.management.base-url=http://localhost:8000

# Batch configuration
reservation.batch.seat-accept-duration-seconds=60
reservation.batch.no-show-limit-minutes=30
reservation.batch.pending-check-rate-ms=60000
reservation.batch.no-show-check-rate-ms=60000
reservation.batch.completion-check-rate-ms=60000
```

Update the `hr.management.base-url` property to point to your HR Management Server.

### 4. Database Initialization

The FZ Reservation Server uses HSQLDB, which is initialized automatically on first run. The schema and sample data are defined in `src/main/resources/sql/schema.sql`.

### 5. Verify Deployment

1. Verify HR Management Server is running:
   ```
   curl http://localhost:8000/docs
   ```

2. Verify FZ Reservation Server is running:
   ```
   curl http://localhost:8080/api/buildings
   ```

## Security Considerations

1. **JWT Token Security**: Ensure the `SECRET_KEY` for the HR Management Server is strong and kept secure.
2. **CORS Configuration**: The system is configured to allow cross-origin requests. Update the CORS configuration in `WebConfig.java` for production environments.
3. **Database Security**: Update the database credentials for production environments.

## Batch Processes

The FZ Reservation Server includes several batch processes that run at regular intervals:

1. **Update Pending to Reserved**: Confirms pending reservations after a specified duration
2. **Update Reserved to No-Show**: Marks reservations as no-show if not checked in within the time limit
3. **Update In-Use to Completed**: Completes reservations that have reached their end time

The batch process intervals can be configured in `application.properties`.

## Troubleshooting

### Common Issues

1. **Connection Refused to HR Management Server**:
   - Verify the HR Management Server is running
   - Check the `hr.management.base-url` property in `application.properties`

2. **Authentication Failures**:
   - Verify the JWT token is being correctly passed in the Authorization header
   - Check the `SECRET_KEY` and `ALGORITHM` settings match between servers

3. **Database Errors**:
   - Check the database connection properties
   - Verify the database file exists and is accessible

### Logs

- FZ Reservation Server logs are available in the `logs` directory
- HR Management Server logs are output to the console by default

## Production Deployment Recommendations

For production deployments, consider the following:

1. Use a production-grade database (PostgreSQL, MySQL, etc.) instead of HSQLDB
2. Deploy behind a reverse proxy (Nginx, Apache) for SSL termination
3. Use environment-specific configuration files
4. Implement proper monitoring and alerting
5. Set up database backups
6. Configure proper logging with rotation
7. Use a process manager (systemd, PM2) to ensure the services stay running
