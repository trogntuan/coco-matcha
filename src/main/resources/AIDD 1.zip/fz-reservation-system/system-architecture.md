# Kiến trúc hệ thống Đặt Chỗ Ngồi Văn Phòng Chia Sẻ

## 1. Tổng quan kiến trúc

Hệ thống Đặt Chỗ Ngồi Văn Phòng Chia Sẻ được thiết kế theo mô hình kiến trúc phân tầng với các thành phần chính sau:

### 1.1. Các thành phần hệ thống
- **FZ Reservation Client**: Giao diện người dùng được phát triển bằng React
- **FZ Reservation Server**: Backend chính được phát triển bằng Spring Boot và MyBatis
- **HR Management Server**: Server quản lý nhân viên và xác thực được phát triển bằng FastAPI (Python)

### 1.2. Mô hình kiến trúc phân tầng FZ Reservation Server
- **Presentation Layer**: REST API Controllers
- **Business Layer**: Services và Business Logic
- **Data Access Layer**: Repositories và MyBatis Mappers
- **Domain Layer**: Entities và DTOs

## 2. Thiết kế chi tiết FZ Reservation Server

### 2.1. Cấu trúc thư mục dự án
```
fz-reservation-server/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── fz/
│   │   │           └── reservation/
│   │   │               ├── FzReservationApplication.java
│   │   │               ├── config/
│   │   │               │   ├── WebConfig.java
│   │   │               │   ├── SecurityConfig.java
│   │   │               │   └── MyBatisConfig.java
│   │   │               ├── controller/
│   │   │               │   ├── BuildingController.java
│   │   │               │   ├── FloorController.java
│   │   │               │   ├── SeatController.java
│   │   │               │   └── ReservationController.java
│   │   │               ├── service/
│   │   │               │   ├── BuildingService.java
│   │   │               │   ├── FloorService.java
│   │   │               │   ├── SeatService.java
│   │   │               │   ├── ReservationService.java
│   │   │               │   ├── BatchService.java
│   │   │               │   └── AuthService.java
│   │   │               ├── repository/
│   │   │               │   ├── BuildingRepository.java
│   │   │               │   ├── FloorRepository.java
│   │   │               │   ├── SeatRepository.java
│   │   │               │   └── ReservationRepository.java
│   │   │               ├── mapper/
│   │   │               │   ├── BuildingMapper.java
│   │   │               │   ├── FloorMapper.java
│   │   │               │   ├── SeatMapper.java
│   │   │               │   └── ReservationMapper.java
│   │   │               ├── domain/
│   │   │               │   ├── entity/
│   │   │               │   │   ├── Building.java
│   │   │               │   │   ├── Floor.java
│   │   │               │   │   ├── Seat.java
│   │   │               │   │   └── Reservation.java
│   │   │               │   └── enums/
│   │   │               │       ├── ReservationStatus.java
│   │   │               │       └── SeatStatus.java
│   │   │               ├── dto/
│   │   │               │   ├── request/
│   │   │               │   │   ├── ReservationRequest.java
│   │   │               │   │   └── SeatAvailabilityRequest.java
│   │   │               │   └── response/
│   │   │               │       ├── BuildingResponse.java
│   │   │               │       ├── FloorResponse.java
│   │   │               │       ├── SeatResponse.java
│   │   │               │       └── ReservationResponse.java
│   │   │               ├── client/
│   │   │               │   └── HrManagementClient.java
│   │   │               ├── exception/
│   │   │               │   ├── GlobalExceptionHandler.java
│   │   │               │   ├── BusinessException.java
│   │   │               │   └── ResourceNotFoundException.java
│   │   │               ├── security/
│   │   │               │   ├── JwtAuthenticationFilter.java
│   │   │               │   └── TokenValidator.java
│   │   │               └── util/
│   │   │                   ├── DateTimeUtil.java
│   │   │                   └── Constants.java
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── application-dev.properties
│   │       ├── application-prod.properties
│   │       └── mybatis/
│   │           ├── BuildingMapper.xml
│   │           ├── FloorMapper.xml
│   │           ├── SeatMapper.xml
│   │           └── ReservationMapper.xml
│   └── test/
│       └── java/
│           └── com/
│               └── fz/
│                   └── reservation/
│                       ├── controller/
│                       ├── service/
│                       └── repository/
└── pom.xml
```

### 2.2. Entities và Enums

#### 2.2.1. Entities

**Building.java**
```java
package com.fz.reservation.domain.entity;

import lombok.Data;

@Data
public class Building {
    private Integer id;
    private String name;
    private String address;
}
```

**Floor.java**
```java
package com.fz.reservation.domain.entity;

import lombok.Data;

@Data
public class Floor {
    private Integer id;
    private Integer buildingId;
    private Integer floor;
}
```

**Seat.java**
```java
package com.fz.reservation.domain.entity;

import com.fz.reservation.domain.enums.SeatStatus;
import lombok.Data;

@Data
public class Seat {
    private Integer id;
    private Integer floorId;
    private String name;
    private SeatStatus status;
}
```

**Reservation.java**
```java
package com.fz.reservation.domain.entity;

import com.fz.reservation.domain.enums.ReservationStatus;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Reservation {
    private Integer id;
    private Integer employeeId;
    private Integer seatId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private ReservationStatus status;
    private LocalDateTime checkInAt;
    private LocalDateTime createdAt;
    private Integer extendedFromReservationId;
}
```

#### 2.2.2. Enums

**ReservationStatus.java**
```java
package com.fz.reservation.domain.enums;

public enum ReservationStatus {
    PENDING,        // Yêu cầu đặt chỗ, đang chờ phê duyệt
    RESERVED,       // Đã xác nhận, chưa sử dụng
    IN_USE,         // Người dùng đã check-in
    CANCELLED,      // Người dùng đã hủy
    NO_SHOW,        // Đã đặt nhưng không check-in
    COMPLETED,      // Hoàn thành bình thường hoặc Trả sớm
    FORCED_CANCEL,  // Bị quản trị viên buộc trả
    FAIL            // Đặt chỗ thất bại
}
```

**SeatStatus.java**
```java
package com.fz.reservation.domain.enums;

public enum SeatStatus {
    AVAILABLE,      // Ghế có sẵn để đặt
    UNAVAILABLE     // Ghế đang được sử dụng
}
```

### 2.3. DTOs (Data Transfer Objects)

#### 2.3.1. Request DTOs

**ReservationRequest.java**
```java
package com.fz.reservation.dto.request;

import lombok.Data;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
public class ReservationRequest {
    @NotNull(message = "Seat ID is required")
    private Integer seatId;
    
    @NotNull(message = "Start time is required")
    @Future(message = "Start time must be in the future")
    private LocalDateTime startTime;
    
    @NotNull(message = "End time is required")
    @Future(message = "End time must be in the future")
    private LocalDateTime endTime;
}
```

**SeatAvailabilityRequest.java**
```java
package com.fz.reservation.dto.request;

import lombok.Data;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
public class SeatAvailabilityRequest {
    private Integer buildingId;
    private Integer floorId;
    
    @NotNull(message = "Start time is required")
    @Future(message = "Start time must be in the future")
    private LocalDateTime startTime;
    
    @NotNull(message = "End time is required")
    @Future(message = "End time must be in the future")
    private LocalDateTime endTime;
}
```

#### 2.3.2. Response DTOs

**BuildingResponse.java**
```java
package com.fz.reservation.dto.response;

import lombok.Data;
import java.util.List;

@Data
public class BuildingResponse {
    private Integer id;
    private String name;
    private String address;
    private List<FloorResponse> floors;
}
```

**FloorResponse.java**
```java
package com.fz.reservation.dto.response;

import lombok.Data;
import java.util.List;

@Data
public class FloorResponse {
    private Integer id;
    private Integer buildingId;
    private Integer floor;
    private List<SeatResponse> seats;
}
```

**SeatResponse.java**
```java
package com.fz.reservation.dto.response;

import com.fz.reservation.domain.enums.SeatStatus;
import lombok.Data;

@Data
public class SeatResponse {
    private Integer id;
    private Integer floorId;
    private String name;
    private SeatStatus status;
}
```

**ReservationResponse.java**
```java
package com.fz.reservation.dto.response;

import com.fz.reservation.domain.enums.ReservationStatus;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ReservationResponse {
    private Integer id;
    private Integer employeeId;
    private Integer seatId;
    private String seatName;
    private Integer floorId;
    private Integer floor;
    private Integer buildingId;
    private String buildingName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private ReservationStatus status;
    private LocalDateTime checkInAt;
    private LocalDateTime createdAt;
    private Integer extendedFromReservationId;
}
```

## 3. Tích hợp với HR Management Server

### 3.1. HR Management Client

**HrManagementClient.java**
```java
package com.fz.reservation.client;

import com.fz.reservation.dto.response.TokenValidationResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class HrManagementClient {
    private final RestTemplate restTemplate;
    private final String hrManagementBaseUrl;

    public HrManagementClient(
            RestTemplate restTemplate,
            @Value("${hr.management.base-url}") String hrManagementBaseUrl) {
        this.restTemplate = restTemplate;
        this.hrManagementBaseUrl = hrManagementBaseUrl;
    }

    public TokenValidationResponse validateToken(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        
        String requestBody = "{\"authorization\": \"Bearer " + token + "\"}";
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);
        
        ResponseEntity<TokenValidationResponse> response = restTemplate.exchange(
                hrManagementBaseUrl + "/auth/validate",
                HttpMethod.POST,
                entity,
                TokenValidationResponse.class
        );
        
        return response.getBody();
    }
}
```

**TokenValidationResponse.java**
```java
package com.fz.reservation.dto.response;

import lombok.Data;

@Data
public class TokenValidationResponse {
    private boolean isValid;
    private Integer employeeId;
    private boolean isAdmin;
    private String message;
}
```

### 3.2. Security Configuration

**SecurityConfig.java**
```java
package com.fz.reservation.config;

import com.fz.reservation.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .cors().and()
            .csrf().disable()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and()
            .authorizeRequests()
            .antMatchers("/api/buildings/**", "/api/floors/**").permitAll()
            .antMatchers("/api/admin/**").hasRole("ADMIN")
            .anyRequest().authenticated()
            .and()
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type"));
        configuration.setExposedHeaders(Arrays.asList("Authorization"));
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
```

**JwtAuthenticationFilter.java**
```java
package com.fz.reservation.security;

import com.fz.reservation.client.HrManagementClient;
import com.fz.reservation.dto.response.TokenValidationResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final HrManagementClient hrManagementClient;

    public JwtAuthenticationFilter(HrManagementClient hrManagementClient) {
        this.hrManagementClient = hrManagementClient;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        
        String authorizationHeader = request.getHeader("Authorization");
        
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }
        
        String token = authorizationHeader.substring(7);
        
        try {
            TokenValidationResponse validationResponse = hrManagementClient.validateToken(token);
            
            if (validationResponse.isValid()) {
                List<SimpleGrantedAuthority> authorities = validationResponse.isAdmin() ?
                        Collections.singletonList(new SimpleGrantedAuthority("ROLE_ADMIN")) :
                        Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"));
                
                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                        validationResponse.getEmployeeId(), null, authorities);
                
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        } catch (Exception e) {
            logger.error("Could not validate token", e);
        }
        
        filterChain.doFilter(request, response);
    }
}
```

## 4. REST API Endpoints

### 4.1. Building Controller

**BuildingController.java**
```java
package com.fz.reservation.controller;

import com.fz.reservation.dto.response.BuildingResponse;
import com.fz.reservation.service.BuildingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/buildings")
public class BuildingController {

    private final BuildingService buildingService;

    public BuildingController(BuildingService buildingService) {
        this.buildingService = buildingService;
    }

    @GetMapping
    public ResponseEntity<List<BuildingResponse>> getAllBuildings() {
        return ResponseEntity.ok(buildingService.getAllBuildings());
    }

    @GetMapping("/{id}")
    public ResponseEntity<BuildingResponse> getBuildingById(@PathVariable Integer id) {
        return ResponseEntity.ok(buildingService.getBuildingById(id));
    }
}
```

### 4.2. Floor Controller

**FloorController.java**
```java
package com.fz.reservation.controller;

import com.fz.reservation.dto.response.FloorResponse;
import com.fz.reservation.service.FloorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/floors")
public class FloorController {

    private final FloorService floorService;

    public FloorController(FloorService floorService) {
        this.floorService = floorService;
    }

    @GetMapping("/building/{buildingId}")
    public ResponseEntity<List<FloorResponse>> getFloorsByBuildingId(@PathVariable Integer buildingId) {
        return ResponseEntity.ok(floorService.getFloorsByBuildingId(buildingId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<FloorResponse> getFloorById(@PathVariable Integer id) {
        return ResponseEntity.ok(floorService.getFloorById(id));
    }
}
```

### 4.3. Seat Controller

**SeatController.java**
```java
package com.fz.reservation.controller;

import com.fz.reservation.dto.request.SeatAvailabilityRequest;
import com.fz.reservation.dto.response.SeatResponse;
import com.fz.reservation.service.SeatService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/seats")
public class SeatController {

    private final SeatService seatService;

    public SeatController(SeatService seatService) {
        this.seatService = seatService;
    }

    @GetMapping("/floor/{floorId}")
    public ResponseEntity<List<SeatResponse>> getSeatsByFloorId(@PathVariable Integer floorId) {
        return ResponseEntity.ok(seatService.getSeatsByFloorId(floorId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<SeatResponse> getSeatById(@PathVariable Integer id) {
        return ResponseEntity.ok(seatService.getSeatById(id));
    }

    @PostMapping("/available")
    public ResponseEntity<List<SeatResponse>> getAvailableSeats(@Valid @RequestBody SeatAvailabilityRequest request) {
        return ResponseEntity.ok(seatService.getAvailableSeats(request));
    }
}
```

### 4.4. Reservation Controller

**ReservationController.java**
```java
package com.fz.reservation.controller;

import com.fz.reservation.dto.request.ReservationRequest;
import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.service.ReservationService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @PostMapping
    public ResponseEntity<ReservationResponse> createReservation(
            @Valid @RequestBody ReservationRequest request,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.createReservation(employeeId, request));
    }

    @GetMapping("/my")
    public ResponseEntity<List<ReservationResponse>> getMyReservations(Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.getReservationsByEmployeeId(employeeId));
    }

    @GetMapping("/my/history")
    public ResponseEntity<List<ReservationResponse>> getMyReservationHistory(Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.getReservationHistoryByEmployeeId(employeeId));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<ReservationResponse> cancelReservation(
            @PathVariable Integer id,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.cancelReservation(id, employeeId));
    }

    @PostMapping("/{id}/check-in")
    public ResponseEntity<ReservationResponse> checkIn(
            @PathVariable Integer id,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.checkIn(id, employeeId));
    }

    @PostMapping("/{id}/return")
    public ResponseEntity<ReservationResponse> returnSeat(
            @PathVariable Integer id,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.returnSeat(id, employeeId));
    }

    @PostMapping("/{id}/extend")
    public ResponseEntity<ReservationResponse> extendReservation(
            @PathVariable Integer id,
            @Valid @RequestBody ReservationRequest request,
            Authentication authentication) {
        Integer employeeId = (Integer) authentication.getPrincipal();
        return ResponseEntity.ok(reservationService.extendReservation(id, employeeId, request));
    }
}
```

### 4.5. Admin Controller

**AdminController.java**
```java
package com.fz.reservation.controller;

import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.dto.response.SeatResponse;
import com.fz.reservation.service.AdminService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/seats/details")
    public ResponseEntity<List<SeatResponse>> getSeatDetails(@RequestParam(required = false) Integer floorId) {
        return ResponseEntity.ok(adminService.getSeatDetails(floorId));
    }

    @PostMapping("/seats/{id}/force-return")
    public ResponseEntity<ReservationResponse> forceReturnSeat(@PathVariable Integer id) {
        return ResponseEntity.ok(adminService.forceReturnSeat(id));
    }
}
```

## 5. Service Layer

### 5.1. Building Service

**BuildingService.java**
```java
package com.fz.reservation.service;

import com.fz.reservation.dto.response.BuildingResponse;
import com.fz.reservation.exception.ResourceNotFoundException;
import com.fz.reservation.repository.BuildingRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BuildingService {

    private final BuildingRepository buildingRepository;

    public BuildingService(BuildingRepository buildingRepository) {
        this.buildingRepository = buildingRepository;
    }

    public List<BuildingResponse> getAllBuildings() {
        return buildingRepository.findAll().stream()
                .map(building -> {
                    BuildingResponse response = new BuildingResponse();
                    response.setId(building.getId());
                    response.setName(building.getName());
                    response.setAddress(building.getAddress());
                    return response;
                })
                .collect(Collectors.toList());
    }

    public BuildingResponse getBuildingById(Integer id) {
        return buildingRepository.findById(id)
                .map(building -> {
                    BuildingResponse response = new BuildingResponse();
                    response.setId(building.getId());
                    response.setName(building.getName());
                    response.setAddress(building.getAddress());
                    return response;
                })
                .orElseThrow(() -> new ResourceNotFoundException("Building not found with id: " + id));
    }
}
```

### 5.2. Reservation Service

**ReservationService.java**
```java
package com.fz.reservation.service;

import com.fz.reservation.domain.entity.Reservation;
import com.fz.reservation.domain.entity.Seat;
import com.fz.reservation.domain.enums.ReservationStatus;
import com.fz.reservation.domain.enums.SeatStatus;
import com.fz.reservation.dto.request.ReservationRequest;
import com.fz.reservation.dto.response.ReservationResponse;
import com.fz.reservation.exception.BusinessException;
import com.fz.reservation.exception.ResourceNotFoundException;
import com.fz.reservation.repository.ReservationRepository;
import com.fz.reservation.repository.SeatRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final SeatRepository seatRepository;

    public ReservationService(ReservationRepository reservationRepository, SeatRepository seatRepository) {
        this.reservationRepository = reservationRepository;
        this.seatRepository = seatRepository;
    }

    public List<ReservationResponse> getReservationsByEmployeeId(Integer employeeId) {
        List<Reservation> reservations = reservationRepository.findActiveReservationsByEmployeeId(employeeId);
        return mapToReservationResponses(reservations);
    }

    public List<ReservationResponse> getReservationHistoryByEmployeeId(Integer employeeId) {
        LocalDateTime oneMonthAgo = LocalDateTime.now().minusMonths(1);
        List<Reservation> reservations = reservationRepository.findReservationHistoryByEmployeeId(employeeId, oneMonthAgo);
        return mapToReservationResponses(reservations);
    }

    @Transactional
    public ReservationResponse createReservation(Integer employeeId, ReservationRequest request) {
        // Validate request
        validateReservationRequest(request);
        
        // Check if seat exists
        Seat seat = seatRepository.findById(request.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + request.getSeatId()));
        
        // Check if seat is available for the requested time period
        if (!isSeatAvailable(request.getSeatId(), request.getStartTime(), request.getEndTime())) {
            throw new BusinessException("Seat is not available for the requested time period");
        }
        
        // Create reservation
        Reservation reservation = new Reservation();
        reservation.setEmployeeId(employeeId);
        reservation.setSeatId(request.getSeatId());
        reservation.setStartTime(request.getStartTime());
        reservation.setEndTime(request.getEndTime());
        reservation.setStatus(ReservationStatus.PENDING);
        reservation.setCreatedAt(LocalDateTime.now());
        
        Reservation savedReservation = reservationRepository.save(reservation);
        
        return mapToReservationResponse(savedReservation);
    }

    @Transactional
    public ReservationResponse cancelReservation(Integer reservationId, Integer employeeId) {
        Reservation reservation = getReservationForEmployee(reservationId, employeeId);
        
        if (reservation.getStatus() != ReservationStatus.PENDING && reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new BusinessException("Only PENDING or RESERVED reservations can be cancelled");
        }
        
        reservation.setStatus(ReservationStatus.CANCELLED);
        Reservation updatedReservation = reservationRepository.save(reservation);
        
        return mapToReservationResponse(updatedReservation);
    }

    @Transactional
    public ReservationResponse checkIn(Integer reservationId, Integer employeeId) {
        Reservation reservation = getReservationForEmployee(reservationId, employeeId);
        
        if (reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new BusinessException("Only RESERVED reservations can be checked in");
        }
        
        LocalDateTime now = LocalDateTime.now();
        
        if (now.isBefore(reservation.getStartTime().minusMinutes(30))) {
            throw new BusinessException("Check-in is only allowed 30 minutes before the reservation start time");
        }
        
        if (now.isAfter(reservation.getStartTime().plusMinutes(30))) {
            throw new BusinessException("Check-in is only allowed up to 30 minutes after the reservation start time");
        }
        
        // Update reservation status
        reservation.setStatus(ReservationStatus.IN_USE);
        reservation.setCheckInAt(now);
        Reservation updatedReservation = reservationRepository.save(reservation);
        
        // Update seat status
        Seat seat = seatRepository.findById(reservation.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + reservation.getSeatId()));
        seat.setStatus(SeatStatus.UNAVAILABLE);
        seatRepository.save(seat);
        
        return mapToReservationResponse(updatedReservation);
    }

    @Transactional
    public ReservationResponse returnSeat(Integer reservationId, Integer employeeId) {
        Reservation reservation = getReservationForEmployee(reservationId, employeeId);
        
        if (reservation.getStatus() != ReservationStatus.IN_USE) {
            throw new BusinessException("Only IN_USE reservations can be returned");
        }
        
        // Update reservation status
        reservation.setStatus(ReservationStatus.COMPLETED);
        Reservation updatedReservation = reservationRepository.save(reservation);
        
        // Update seat status
        Seat seat = seatRepository.findById(reservation.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + reservation.getSeatId()));
        seat.setStatus(SeatStatus.AVAILABLE);
        seatRepository.save(seat);
        
        return mapToReservationResponse(updatedReservation);
    }

    @Transactional
    public ReservationResponse extendReservation(Integer reservationId, Integer employeeId, ReservationRequest request) {
        Reservation currentReservation = getReservationForEmployee(reservationId, employeeId);
        
        if (currentReservation.getStatus() != ReservationStatus.IN_USE) {
            throw new BusinessException("Only IN_USE reservations can be extended");
        }
        
        // Validate extension request
        if (!request.getStartTime().isEqual(currentReservation.getEndTime())) {
            throw new BusinessException("Extension start time must be equal to current reservation end time");
        }
        
        if (request.getEndTime().isBefore(request.getStartTime())) {
            throw new BusinessException("Extension end time must be after start time");
        }
        
        // Check if seat is available for the extended time period
        if (!isSeatAvailable(currentReservation.getSeatId(), request.getStartTime(), request.getEndTime())) {
            throw new BusinessException("Seat is not available for the requested extension period");
        }
        
        // Create new reservation for the extended period
        Reservation newReservation = new Reservation();
        newReservation.setEmployeeId(employeeId);
        newReservation.setSeatId(currentReservation.getSeatId());
        newReservation.setStartTime(request.getStartTime());
        newReservation.setEndTime(request.getEndTime());
        newReservation.setStatus(ReservationStatus.IN_USE);
        newReservation.setCreatedAt(LocalDateTime.now());
        newReservation.setCheckInAt(LocalDateTime.now());
        newReservation.setExtendedFromReservationId(currentReservation.getId());
        
        Reservation savedReservation = reservationRepository.save(newReservation);
        
        return mapToReservationResponse(savedReservation);
    }

    private Reservation getReservationForEmployee(Integer reservationId, Integer employeeId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found with id: " + reservationId));
        
        if (!reservation.getEmployeeId().equals(employeeId)) {
            throw new BusinessException("You don't have permission to access this reservation");
        }
        
        return reservation;
    }

    private boolean isSeatAvailable(Integer seatId, LocalDateTime startTime, LocalDateTime endTime) {
        return reservationRepository.countOverlappingReservations(seatId, startTime, endTime) == 0;
    }

    private void validateReservationRequest(ReservationRequest request) {
        if (request.getStartTime().isAfter(request.getEndTime())) {
            throw new BusinessException("Start time must be before end time");
        }
        
        if (request.getStartTime().isBefore(LocalDateTime.now())) {
            throw new BusinessException("Start time must be in the future");
        }
        
        if (request.getEndTime().isAfter(request.getStartTime().plusHours(8))) {
            throw new BusinessException("Reservation duration cannot exceed 8 hours");
        }
    }

    private List<ReservationResponse> mapToReservationResponses(List<Reservation> reservations) {
        return reservations.stream()
                .map(this::mapToReservationResponse)
                .collect(Collectors.toList());
    }

    private ReservationResponse mapToReservationResponse(Reservation reservation) {
        ReservationResponse response = new ReservationResponse();
        response.setId(reservation.getId());
        response.setEmployeeId(reservation.getEmployeeId());
        response.setSeatId(reservation.getSeatId());
        
        // Get seat details
        Seat seat = seatRepository.findById(reservation.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + reservation.getSeatId()));
        response.setSeatName(seat.getName());
        response.setFloorId(seat.getFloorId());
        
        // Get floor and building details from repositories
        
        response.setStartTime(reservation.getStartTime());
        response.setEndTime(reservation.getEndTime());
        response.setStatus(reservation.getStatus());
        response.setCheckInAt(reservation.getCheckInAt());
        response.setCreatedAt(reservation.getCreatedAt());
        response.setExtendedFromReservationId(reservation.getExtendedFromReservationId());
        
        return response;
    }
}
```

## 6. MyBatis Mappers

### 6.1. Reservation Mapper XML

**ReservationMapper.xml**
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.fz.reservation.mapper.ReservationMapper">
    
    <resultMap id="reservationResultMap" type="com.fz.reservation.domain.entity.Reservation">
        <id property="id" column="id"/>
        <result property="employeeId" column="employee_id"/>
        <result property="seatId" column="seat_id"/>
        <result property="startTime" column="start_time"/>
        <result property="endTime" column="end_time"/>
        <result property="status" column="status" typeHandler="org.apache.ibatis.type.EnumTypeHandler"/>
        <result property="checkInAt" column="check_in_at"/>
        <result property="createdAt" column="created_at"/>
        <result property="extendedFromReservationId" column="extended_from_reservation_id"/>
    </resultMap>
    
    <select id="findById" resultMap="reservationResultMap">
        SELECT * FROM RESERVATION WHERE id = #{id}
    </select>
    
    <select id="findActiveReservationsByEmployeeId" resultMap="reservationResultMap">
        SELECT * FROM RESERVATION 
        WHERE employee_id = #{employeeId} 
        AND status IN ('PENDING', 'RESERVED', 'IN_USE')
        ORDER BY start_time DESC
    </select>
    
    <select id="findReservationHistoryByEmployeeId" resultMap="reservationResultMap">
        SELECT * FROM RESERVATION 
        WHERE employee_id = #{employeeId} 
        AND created_at >= #{since}
        AND status IN ('CANCELLED', 'NO_SHOW', 'COMPLETED', 'FORCED_CANCEL', 'FAIL')
        ORDER BY created_at DESC
    </select>
    
    <select id="countOverlappingReservations" resultType="int">
        SELECT COUNT(*) FROM RESERVATION 
        WHERE seat_id = #{seatId} 
        AND status IN ('RESERVED', 'IN_USE', 'PENDING')
        AND NOT (end_time <= #{startTime} OR start_time >= #{endTime})
    </select>
    
    <select id="findPendingReservations" resultMap="reservationResultMap">
        SELECT * FROM RESERVATION WHERE status = 'PENDING'
    </select>
    
    <select id="findExpiredReservations" resultMap="reservationResultMap">
        SELECT * FROM RESERVATION 
        WHERE status = 'RESERVED' 
        AND start_time < #{cutoffTime}
    </select>
    
    <select id="findExpiredInUseReservations" resultMap="reservationResultMap">
        SELECT * FROM RESERVATION 
        WHERE status = 'IN_USE' 
        AND end_time < NOW()
    </select>
    
    <insert id="save" useGeneratedKeys="true" keyProperty="id">
        INSERT INTO RESERVATION (
            employee_id, seat_id, start_time, end_time, status, check_in_at, created_at, extended_from_reservation_id
        ) VALUES (
            #{employeeId}, #{seatId}, #{startTime}, #{endTime}, #{status}, #{checkInAt}, #{createdAt}, #{extendedFromReservationId}
        )
        <selectKey keyProperty="id" resultType="int" order="AFTER">
            SELECT LAST_INSERT_ID()
        </selectKey>
    </insert>
    
    <update id="update">
        UPDATE RESERVATION
        SET employee_id = #{employeeId},
            seat_id = #{seatId},
            start_time = #{startTime},
            end_time = #{endTime},
            status = #{status},
            check_in_at = #{checkInAt},
            extended_from_reservation_id = #{extendedFromReservationId}
        WHERE id = #{id}
    </update>
    
    <update id="updateStatus">
        UPDATE RESERVATION
        SET status = #{status}
        WHERE id = #{id}
    </update>
</mapper>
```

### 6.2. Seat Mapper XML

**SeatMapper.xml**
```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.fz.reservation.mapper.SeatMapper">
    
    <resultMap id="seatResultMap" type="com.fz.reservation.domain.entity.Seat">
        <id property="id" column="id"/>
        <result property="floorId" column="floor_id"/>
        <result property="name" column="name"/>
        <result property="status" column="status" typeHandler="org.apache.ibatis.type.EnumTypeHandler"/>
    </resultMap>
    
    <select id="findById" resultMap="seatResultMap">
        SELECT * FROM SEAT WHERE id = #{id}
    </select>
    
    <select id="findByFloorId" resultMap="seatResultMap">
        SELECT * FROM SEAT WHERE floor_id = #{floorId}
    </select>
    
    <select id="findAvailableSeats" resultMap="seatResultMap">
        SELECT s.* FROM SEAT s
        WHERE s.status = 'AVAILABLE'
        <if test="floorId != null">
            AND s.floor_id = #{floorId}
        </if>
        <if test="buildingId != null">
            AND s.floor_id IN (SELECT id FROM FLOOR WHERE building_id = #{buildingId})
        </if>
        AND s.id NOT IN (
            SELECT r.seat_id FROM RESERVATION r
            WHERE r.status IN ('RESERVED', 'IN_USE', 'PENDING')
            AND NOT (r.end_time <= #{startTime} OR r.start_time >= #{endTime})
        )
    </select>
    
    <update id="updateStatus">
        UPDATE SEAT
        SET status = #{status}
        WHERE id = #{id}
    </update>
</mapper>
```

## 7. Configuration

### 7.1. Application Properties

**application.properties**
```properties
# Server configuration
server.port=8080
server.servlet.context-path=/api

# Database configuration
spring.datasource.url=jdbc:hsqldb:file:./reservationdb;hsqldb.lock_file=false
spring.datasource.username=sa
spring.datasource.password=
spring.datasource.driver-class-name=org.hsqldb.jdbc.JDBCDriver

# MyBatis configuration
mybatis.mapper-locations=classpath:mybatis/*.xml
mybatis.type-aliases-package=com.fz.reservation.domain.entity
mybatis.configuration.map-underscore-to-camel-case=true

# HR Management Server configuration
hr.management.base-url=http://localhost:8000

# Batch configuration
reservation.batch.seat-accept-duration-seconds=60
reservation.batch.no-show-limit-minutes=30
```

### 7.2. MyBatis Configuration

**MyBatisConfig.java**
```java
package com.fz.reservation.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan("com.fz.reservation.mapper")
public class MyBatisConfig {
}
```

## 8. Exception Handling

**GlobalExceptionHandler.java**
```java
package com.fz.reservation.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFoundException(ResourceNotFoundException ex) {
        ErrorResponse error = new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ErrorResponse> handleBusinessException(BusinessException ex) {
        ErrorResponse error = new ErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ValidationErrorResponse> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        ValidationErrorResponse error = new ValidationErrorResponse(HttpStatus.BAD_REQUEST.value(), "Validation failed", errors);
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGlobalException(Exception ex) {
        ErrorResponse error = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "An unexpected error occurred");
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    static class ErrorResponse {
        private final int status;
        private final String message;

        public ErrorResponse(int status, String message) {
            this.status = status;
            this.message = message;
        }

        public int getStatus() {
            return status;
        }

        public String getMessage() {
            return message;
        }
    }

    static class ValidationErrorResponse extends ErrorResponse {
        private final Map<String, String> errors;

        public ValidationErrorResponse(int status, String message, Map<String, String> errors) {
            super(status, message);
            this.errors = errors;
        }

        public Map<String, String> getErrors() {
            return errors;
        }
    }
}
```

**ResourceNotFoundException.java**
```java
package com.fz.reservation.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
```

**BusinessException.java**
```java
package com.fz.reservation.exception;

public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}
```
