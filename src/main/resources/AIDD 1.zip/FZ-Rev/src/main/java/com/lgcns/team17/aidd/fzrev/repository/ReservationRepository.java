package com.lgcns.team17.aidd.fzrev.repository;

import com.lgcns.team17.aidd.fzrev.domain.Reservation;
import com.lgcns.team17.aidd.fzrev.domain.enums.ReservationStatus;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Mapper
public interface ReservationRepository {
    int insert(Reservation reservation);
    Optional<Reservation> findById(@Param("id") int id);
    List<Reservation> findByEmployeeId(@Param("employeeId") int employeeId);

    List<Reservation> findByEmployeeIdAndStatusInAndEndTimeAfter(
            @Param("employeeId") int employeeId,
            @Param("statuses") List<ReservationStatus> statuses,
            @Param("currentTime") LocalDateTime currentTime
    );

    List<Reservation> findBySeatIdAndStatusInAndOverlappingTime(
            @Param("seatId") int seatId,
            @Param("statuses") List<ReservationStatus> statuses,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime,
            @Param("excludeReservationId") Integer excludeReservationId // Để loại trừ đặt chỗ hiện tại khi cập nhật/gia hạn
    );

    Long sumDailyReservationDurationForEmployee(
            @Param("employeeId") int employeeId,
            @Param("date") LocalDate date, // Chỉ cần ngày
            @Param("statusesToSum") List<ReservationStatus> statusesToSum,
            @Param("excludeReservationId") Integer excludeReservationId
    );

    int updateStatus(@Param("id") int id, @Param("status") ReservationStatus status, @Param("updatedAt") LocalDateTime updatedAt);
    int updateStatusAndCheckInTime(@Param("id") int id, @Param("status") ReservationStatus status, @Param("checkInAt") LocalDateTime checkInAt, @Param("updatedAt") LocalDateTime updatedAt);

    List<Reservation> findReservationsByStatusAndStartTimeBefore(@Param("status") ReservationStatus status, @Param("cutoffTime") LocalDateTime cutoffTime);
    List<Reservation> findReservationsByStatusAndEndTimeBefore(@Param("status") ReservationStatus status, @Param("cutoffTime") LocalDateTime cutoffTime);

    List<Reservation> findHistoryByEmployeeIdAndDateRange(
            @Param("employeeId") int employeeId,
            @Param("queryStartDate") LocalDateTime queryStartDate,
            @Param("queryEndDate") LocalDateTime queryEndDate,
            @Param("offset") int offset,
            @Param("limit") int limit
    );

        List<Reservation> findActiveInUseReservationsBySeatIdAtTime(@Param("seatId") int seatId, @Param("currentTime") LocalDateTime currentTime);
    int updateStatusForIds(@Param("ids") List<Integer> ids, @Param("status") ReservationStatus status, @Param("updatedAt") LocalDateTime updatedAt);

    // Cho việc tìm chuỗi gia hạn
    List<Reservation> findByExtendedFromReservationId(@Param("originalReservationId") int originalReservationId);
    // (Bạn có thể cần thêm các query khác)
    long countHistoryByEmployeeIdAndDateRange(
            @Param("employeeId") int employeeId,
            @Param("queryStartDate") LocalDateTime queryStartDate,
            @Param("queryEndDate") LocalDateTime queryEndDate
    );
}
