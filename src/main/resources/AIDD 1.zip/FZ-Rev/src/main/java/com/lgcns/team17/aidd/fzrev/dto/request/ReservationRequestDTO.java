package com.lgcns.team17.aidd.fzrev.dto.request;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ReservationRequestDTO {
    @NotNull(message = "Seat ID cannot be null")
    private Integer seatId;

    @NotNull(message = "Start time cannot be null")
    @Future(message = "Start time must be in the future") // Hoặc dùng custom validator
    private LocalDateTime startTime;

    @NotNull(message = "End time cannot be null")
    private LocalDateTime endTime;

    // Custom validation: endTime > startTime (có thể dùng @AssertTrue trên một method getter)
}