package com.lgcns.team17.aidd.fzrev.service.impl;

import com.lgcns.team17.aidd.fzrev.domain.Building;
import com.lgcns.team17.aidd.fzrev.domain.Floor;
import com.lgcns.team17.aidd.fzrev.domain.Reservation;
import com.lgcns.team17.aidd.fzrev.domain.Seat;
import com.lgcns.team17.aidd.fzrev.domain.enums.SeatStatus;
import com.lgcns.team17.aidd.fzrev.dto.response.*;
import com.lgcns.team17.aidd.fzrev.exception.BusinessLogicException;
import com.lgcns.team17.aidd.fzrev.exception.ResourceNotFoundException;
import com.lgcns.team17.aidd.fzrev.repository.BuildingRepository;
import com.lgcns.team17.aidd.fzrev.repository.FloorRepository;
import com.lgcns.team17.aidd.fzrev.repository.ReservationRepository;
import com.lgcns.team17.aidd.fzrev.repository.SeatRepository;
import com.lgcns.team17.aidd.fzrev.service.SeatService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Quan trọng cho các method đọc

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true) // Mặc định các method đọc là readOnly
public class SeatServiceImpl implements SeatService {

    private static final Logger logger = LoggerFactory.getLogger(SeatServiceImpl.class);

    private final BuildingRepository buildingRepository;
    private final FloorRepository floorRepository;
    private final SeatRepository seatRepository;
    private final ReservationRepository reservationRepository; // Cần để kiểm tra trạng thái đặt chỗ hiện tại

    public SeatServiceImpl(BuildingRepository buildingRepository,
                           FloorRepository floorRepository,
                           SeatRepository seatRepository,
                           ReservationRepository reservationRepository) {
        this.buildingRepository = buildingRepository;
        this.floorRepository = floorRepository;
        this.seatRepository = seatRepository;
        this.reservationRepository = reservationRepository;
    }

    @Override
    public List<BuildingDTO> getAllBuildings() {
        return buildingRepository.findAll().stream()
                .map(building -> new BuildingDTO(building.getId(), building.getName(), building.getAddress()))
                .collect(Collectors.toList());
    }

    @Override
    public List<FloorDTO> getFloorsByBuilding(int buildingId) {
        buildingRepository.findById(buildingId) // Kiểm tra building tồn tại
                .orElseThrow(() -> new ResourceNotFoundException("Building", "id", buildingId));
        return floorRepository.findByBuildingId(buildingId).stream()
                .map(floor -> new FloorDTO(floor.getId(), floor.getBuildingId(), floor.getFloor(), "Tầng " + floor.getFloor())) // Tên tầng có thể cần logic phức tạp hơn
                .collect(Collectors.toList());
    }

    @Override
    public List<SeatStatusDTO> getSeatStatusesByFloor(int floorId) {
        Floor floor = floorRepository.findById(floorId)
                .orElseThrow(() -> new ResourceNotFoundException("Floor", "id", floorId));
        Building building = buildingRepository.findById(floor.getBuildingId())
                .orElseThrow(() -> new ResourceNotFoundException("Building", "id", floor.getBuildingId()));


        List<Seat> seats = seatRepository.findByFloorId(floorId);
        List<SeatStatusDTO> seatStatusDTOs = new ArrayList<>();

        for (Seat seat : seats) {
            String statusDisplay = "UNAVAILABLE"; // Mặc định là không có sẵn nếu không phải BROKEN
            if (seat.getStatus() == SeatStatus.AVAILABLE) {
                statusDisplay = "AVAILABLE";
            } else if (seat.getStatus() == SeatStatus.BROKEN) {
                statusDisplay = "BROKEN"; // Hoặc "UNAVAILABLE" tùy theo yêu cầu UI nhân viên
            } else if (seat.getStatus() == SeatStatus.UNAVAILABLE) {
                // Kiểm tra xem có ai đang IN_USE không, nhưng cho nhân viên, chỉ cần biết là UNAVAILABLE là đủ
                // Logic phức tạp hơn để hiển thị "OCCUPIED" nếu cần, nhưng tài liệu chỉ nói "Có sẵn/Không có sẵn"
            }

            seatStatusDTOs.add(SeatStatusDTO.builder()
                    .id(seat.getId())
                    .name(seat.getName())
                    .status(statusDisplay)
                    .buildingName(building.getName())
                    .floorName("Tầng " + floor.getFloor()) // Hoặc floor.getName() nếu có
                    .build());
        }
        return seatStatusDTOs;
    }

    @Override
    public List<SeatDetailDTO> getDetailedSeatStatusesByFloor(int floorId) {
        Floor floor = floorRepository.findById(floorId)
                .orElseThrow(() -> new ResourceNotFoundException("Floor", "id", floorId));
        Building building = buildingRepository.findById(floor.getBuildingId())
                .orElseThrow(() -> new ResourceNotFoundException("Building", "id", floor.getBuildingId()));

        List<Seat> seats = seatRepository.findByFloorId(floorId); // Hoặc findDetailedSeatsByFloorId nếu có query riêng
        List<SeatDetailDTO> seatDetailDTOs = new ArrayList<>();

        for (Seat seat : seats) {
            SeatDetailDTO dto = SeatDetailDTO.builder()
                    .id(seat.getId())
                    .name(seat.getName())
                    .status(seat.getStatus())
                    .floorId(seat.getFloorId())
                    .floorName("Tầng " + floor.getFloor())
                    .buildingName(building.getName())
                    .updatedAt(seat.getUpdatedAt())
                    .build();

            if (seat.getStatus() == SeatStatus.UNAVAILABLE) {
                // Tìm đặt chỗ IN_USE hiện tại cho ghế này để lấy thông tin người đặt
                List<Reservation> currentReservations = reservationRepository.findActiveInUseReservationsBySeatIdAtTime(seat.getId(), LocalDateTime.now());
                if (!currentReservations.isEmpty()) {
                    Reservation currentRes = currentReservations.get(0); // Giả sử chỉ có 1 người đang IN_USE
                    dto.setCurrentOccupantEmployeeId(currentRes.getEmployeeId());
                    dto.setCurrentReservationEndTime(currentRes.getEndTime());
                }
            }
            seatDetailDTOs.add(dto);
        }
        return seatDetailDTOs;
    }

    @Override
    public PagedResponseDTO<SeatRepository.AvailableSeatInfo> findAvailableSeats(
            AvailableSeatSearchRequestDTO request, int page, int size) {
        // Validate request (startTime < endTime, startTime is future)
        if (request.getStartTime().isBefore(LocalDateTime.now().minusMinutes(1))) { // Cho phép sai số nhỏ
            throw new BusinessLogicException("RE003", "Search start time must be in the future.");
        }
        if (!request.getEndTime().isAfter(request.getStartTime())) {
            throw new BusinessLogicException("RE001", "Search end time must be after start time.");
        }

        if (page < 0) page = 0;
        if (size <= 0) size = 5; // Mặc định theo tài liệu
        int offset = page * size;

        List<SeatRepository.AvailableSeatInfo> availableSeats = seatRepository.findAvailableSeatsInTimeRange(
                request.getStartTime(), request.getEndTime(),
                request.getBuildingId(), request.getFloorId(),
                offset, size
        );

        long totalElements = seatRepository.countAvailableSeatsInTimeRange(
                request.getStartTime(), request.getEndTime(),
                request.getBuildingId(), request.getFloorId()
        );

        return new PagedResponseDTO<>(availableSeats, page, size, totalElements);
    }
}