package com.lgcns.team17.aidd.fzrev.domain;
import com.lgcns.team17.aidd.fzrev.domain.enums.SeatStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Seat {
    private Integer id;
    private Integer floorId;
    private String name; // Ví dụ: A-1
    private SeatStatus status; // AVAILABLE, UNAVAILABLE, BROKEN
    private LocalDateTime updatedAt;

    // Thông tin join (tùy chọn, có thể lấy qua service)
    private transient String floorName; // Ví dụ "Tầng 1"
    private transient String buildingName; // Ví dụ "Tòa nhà E_13"
}