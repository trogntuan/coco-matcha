package com.lgcns.team17.aidd.fzrev.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data

public class HRTokenValidationResponse {
    @JsonProperty("is_valid")
    private boolean isValid;
    @JsonProperty("employee_id")
    private Integer employeeId;
    @JsonProperty("is_admin")
    private Boolean isAdmin;
    private String message;
    // getters, setters, helper getRoles()
}