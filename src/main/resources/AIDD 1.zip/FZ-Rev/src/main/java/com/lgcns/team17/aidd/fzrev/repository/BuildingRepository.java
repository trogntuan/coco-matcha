package com.lgcns.team17.aidd.fzrev.repository;

import com.lgcns.team17.aidd.fzrev.domain.Building;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Optional;

@Mapper
public interface BuildingRepository {
    List<Building> findAll();
    Optional<Building> findById(int id);
    // Các method khác nếu cần (insert, update, delete - có thể không cần cho SPRINT này)
}
