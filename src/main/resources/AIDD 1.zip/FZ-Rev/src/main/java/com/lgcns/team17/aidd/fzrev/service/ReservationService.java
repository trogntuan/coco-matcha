package com.lgcns.team17.aidd.fzrev.service;


import com.lgcns.team17.aidd.fzrev.domain.Reservation;
import com.lgcns.team17.aidd.fzrev.dto.request.ReservationRequestDTO;
import com.lgcns.team17.aidd.fzrev.dto.response.PagedResponseDTO;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface ReservationService {
    Reservation createReservation(int employeeId, ReservationRequestDTO request);
    Reservation getReservationById(int reservationId, int employeeId); // employeeId để kiểm tra quyền
    Reservation cancelReservation(int reservationId, int employeeId);
    Reservation checkIn(int reservationId, int employeeId);
    Reservation extendReservation(int reservationId, int employeeId);
    List<Reservation> returnSeat(int reservationId, int employeeId); // Trả về chuỗi đã cập nhật

    List<Reservation> getMyCurrentReservations(int employeeId); // PENDING, RESERVED, IN_USE từ hôm nay
    PagedResponseDTO<Reservation> getMyReservationHistory(int employeeId, LocalDate startDate, LocalDate endDate, int page, int size);

    // Methods cho Admin (nếu có, ví dụ: buộc trả)
    List<Reservation> forceReturnSeatByAdmin(int seatId);
    // ... trong ReservationRepository.java ...

}