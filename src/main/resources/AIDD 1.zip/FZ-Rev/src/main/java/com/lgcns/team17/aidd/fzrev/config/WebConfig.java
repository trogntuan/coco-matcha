package com.lgcns.team17.aidd.fzrev.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
//                .allowedOriginPatterns("*") // Cho phép tất cả các origin
                .allowedOrigins("http://localhost:3001", "http://localhost:3000", "https://your-production-domain.com") // Thay thế bằng domain của bạn
                .allowedMethods("*") // Cho phép tất cả các phương thức HTTP
                .allowedHeaders("*")
                .allowedMethods("*")
                .allowCredentials(false)
                .maxAge(3000);
    }
}