package com.lgcns.team17.aidd.fzrev.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Floor {
    private Integer id;
    private Integer buildingId;
    private Integer floor; // Số tầng, ví dụ: 1, 2, -1 (tầng hầm)
    private String name; // Tên tầng, ví dụ: "Tầng 1", "Tầng trệt" (tùy chọn, có thể tạo động)

    // Thông tin join (tùy chọn)
    private transient String buildingName;
}
