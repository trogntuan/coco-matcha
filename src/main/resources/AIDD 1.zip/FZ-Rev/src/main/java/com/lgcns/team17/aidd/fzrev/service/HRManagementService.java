package com.lgcns.team17.aidd.fzrev.service;
import com.lgcns.team17.aidd.fzrev.dto.request.HRTokenValidationRequest;
import com.lgcns.team17.aidd.fzrev.dto.response.HRTokenValidationResponse;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono; // Quan trọng: dùng Mono

import java.time.Duration; // Nếu muốn thêm timeout cho từng request

@Service
@RequiredArgsConstructor
public class HRManagementService {


    private static final Logger logger = LoggerFactory.getLogger(HRManagementService.class);
    private final WebClient webClient;

    // Inject WebClient đã cấu hìn
    public Mono<HRTokenValidationResponse> validateToken(String bearerToken) {
        HRTokenValidationRequest requestBody = new HRTokenValidationRequest(bearerToken);
        String validatePath = "/auth/validate"; // Đường dẫn API

        logger.debug("Sending token validation request to HRMS for token: {}", bearerToken.substring(0, Math.min(bearerToken.length(), 15)) + "..."); // Log một phần token

        return webClient.post()
                .uri(validatePath)
                .body(BodyInserters.fromValue(requestBody))
                .retrieve()
                // Xử lý lỗi HTTP từ phía server HRMS
                .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(),
                        clientResponse -> clientResponse.bodyToMono(String.class) // Đọc body lỗi (nếu có)
                                .flatMap(errorBody -> {
                                    logger.error("HRMS API error: Status {}, Body {}", clientResponse.statusCode(), errorBody);
                                    // Ném một custom exception hoặc trả về Mono.error
                                    return Mono.error(new HRMSApiException("Error from HRMS: " + clientResponse.statusCode() + " - " + errorBody, clientResponse.statusCode()));
                                })
                )
                .bodyToMono(HRTokenValidationResponse.class)
                // Thêm timeout cho request này nếu cần (ngoài timeout global của WebClient)
                // .timeout(Duration.ofSeconds(5))
                .doOnError(error -> logger.error("Error during WebClient call to HRMS validate API: {}", error.getMessage(), error));
    }

    // Fallback method cho Circuit Breaker
    @SuppressWarnings("unused") // Được gọi bởi Resilience4J
    public Mono<HRTokenValidationResponse> validateTokenFallback(String bearerToken, Throwable t) {
        logger.error("Fallback for HRMS validateToken (Token: {}...) due to: {}", bearerToken.substring(0, Math.min(bearerToken.length(),15))+"...", t.getMessage());
        HRTokenValidationResponse fallbackResponse = new HRTokenValidationResponse();
        fallbackResponse.setValid(false);
        fallbackResponse.setMessage("HR Management Service is temporarily unavailable. Token validation failed.");
        // Trả về Mono chứa response fallback
        return Mono.just(fallbackResponse);
    }
}

// Custom exception cho lỗi từ HRMS (tùy chọn)
class HRMSApiException extends RuntimeException {
    private final HttpStatusCode statusCode;
    public HRMSApiException(String message, HttpStatusCode statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
    public HttpStatusCode getStatusCode() {
        return statusCode;
    }
}