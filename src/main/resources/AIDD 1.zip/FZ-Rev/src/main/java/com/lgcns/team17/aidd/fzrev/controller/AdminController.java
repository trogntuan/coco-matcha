package com.lgcns.team17.aidd.fzrev.controller;

import com.lgcns.team17.aidd.fzrev.domain.Reservation;
import com.lgcns.team17.aidd.fzrev.dto.response.SeatDetailDTO;
import com.lgcns.team17.aidd.fzrev.service.ReservationService;
import com.lgcns.team17.aidd.fzrev.service.SeatService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin")
@PreAuthorize("hasRole('ADMIN')") // Tất cả API trong controller này yêu cầu role ADMIN
public class AdminController {

    private final SeatService seatService;
    private final ReservationService reservationService; // Admin có thể cần ReservationService

    public AdminController(SeatService seatService, ReservationService reservationService) {
        this.seatService = seatService;
        this.reservationService = reservationService;
    }

    // A0102: Truy xuất Trạng thái Chi tiết Ghế (Admin)
    @GetMapping("/floors/{floorId}/seats/details")
    public ResponseEntity<List<SeatDetailDTO>> getDetailedSeatStatusesByFloor(@PathVariable int floorId) {
        return ResponseEntity.ok(seatService.getDetailedSeatStatusesByFloor(floorId));
    }

    // A0101: Buộc Trả Ghế (Admin)
    @PostMapping("/seats/{seatId}/force-return")
    public ResponseEntity<List<Reservation>> forceReturnSeat(@PathVariable int seatId) {
        // Logic buộc trả ghế có thể nằm trong ReservationService hoặc một AdminService riêng
        List<Reservation> affectedReservations = reservationService.forceReturnSeatByAdmin(seatId);
        return ResponseEntity.ok(affectedReservations);
    }

    // Các API khác của Admin nếu có
}