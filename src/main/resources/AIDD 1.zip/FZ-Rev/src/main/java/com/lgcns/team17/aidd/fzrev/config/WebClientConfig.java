package com.lgcns.team17.aidd.fzrev.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.util.concurrent.TimeUnit;

@Configuration
public class WebClientConfig {

    @Value("${hr.service.base-url}")
    private String hrmsBaseUrl;

    @Value("${app.webclient.connect-timeout-ms:5000}") // 5 giây
    private int connectTimeoutMs;

    @Value("${app.webclient.read-timeout-ms:10000}")  // 10 giây
    private int readTimeoutMs;

    @Value("${app.webclient.write-timeout-ms:10000}") // 10 giây
    private int writeTimeoutMs;

    @Bean(name = "webClient") // Đặt tên cho bean để dễ inject
    public WebClient webClient() {
        HttpClient httpClient = HttpClient.create()
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectTimeoutMs)
                .responseTimeout(java.time.Duration.ofMillis(readTimeoutMs)) // Timeout cho toàn bộ response
                .doOnConnected(conn ->
                        conn.addHandlerLast(new ReadTimeoutHandler(readTimeoutMs, TimeUnit.MILLISECONDS))
                                .addHandlerLast(new WriteTimeoutHandler(writeTimeoutMs, TimeUnit.MILLISECONDS)));

        return WebClient.builder()
                .baseUrl(hrmsBaseUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                // Bạn có thể thêm các default headers khác hoặc ExchangeFilterFunctions ở đây
                .build();
    }

    // Các beans khác (RestTemplate nếu vẫn dùng ở đâu đó, etc.)
}