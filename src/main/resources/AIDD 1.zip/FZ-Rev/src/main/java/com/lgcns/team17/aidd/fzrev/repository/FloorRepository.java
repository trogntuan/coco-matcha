package com.lgcns.team17.aidd.fzrev.repository;

import com.lgcns.team17.aidd.fzrev.domain.Floor;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Optional;

@Mapper
public interface FloorRepository {
    List<Floor> findByBuildingId(@Param("buildingId") int buildingId);
    Optional<Floor> findById(int id);
    Optional<Floor> findByBuildingIdAndFloorNumber(@Param("buildingId") int buildingId, @Param("floorNumber") int floorNumber);
    // Các method khác nếu cần
}
