package com.lgcns.team17.aidd.fzrev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableScheduling
@EnableTransactionManagement
public class FzRevApplication {
    public static void main(String[] args) {
        SpringApplication.run(FzRevApplication.class, args);
    }

}
