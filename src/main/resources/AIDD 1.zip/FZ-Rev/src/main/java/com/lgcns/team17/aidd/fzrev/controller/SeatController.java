package com.lgcns.team17.aidd.fzrev.controller;


import com.lgcns.team17.aidd.fzrev.dto.response.*;
import com.lgcns.team17.aidd.fzrev.repository.SeatRepository;
import com.lgcns.team17.aidd.fzrev.service.SeatService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/")
public class SeatController { // Tách BuildingFloorController nếu muốn

    private final SeatService seatService;

    public SeatController(SeatService seatService) {
        this.seatService = seatService;
    }

    // U0203: Truy xuất Tất cả Tòa nhà (Nhân viên)
    @GetMapping("/seats/buildings")
//    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<List<BuildingDTO>> getAllBuildings() {
        return ResponseEntity.ok(seatService.getAllBuildings());
    }

    // U0204: Truy xuất Tầng (Nhân viên)
    @GetMapping("/buildings/{buildingId}/floors")
//    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<List<FloorDTO>> getFloorsByBuilding(@PathVariable int buildingId) {
        return ResponseEntity.ok(seatService.getFloorsByBuilding(buildingId));
    }

    // U0201: Truy xuất Trạng thái Ghế (Nhân viên)
    @GetMapping("/floors/{floorId}/seats/status")
//    @PreAuthorize("hasRole('EMPLOYEE')") // Chỉ nhân viên theo UC
    public ResponseEntity<List<SeatStatusDTO>> getSeatStatusesByFloor(@PathVariable int floorId) {
        return ResponseEntity.ok(seatService.getSeatStatusesByFloor(floorId));
    }

    // U0101: Truy xuất Ghế Trống Theo Khoảng Thời Gian (Nhân viên)
    // POST vì request body có thể phức tạp, hoặc GET với nhiều query params
    @PostMapping("/seats/available") // Hoặc @GetMapping("/seats/available") với @RequestParam
//    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<PagedResponseDTO<SeatRepository.AvailableSeatInfo>> findAvailableSeats(
            @Valid @RequestBody AvailableSeatSearchRequestDTO searchRequest,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size) {
        return ResponseEntity.ok(seatService.findAvailableSeats(searchRequest, page, size));
    }
}