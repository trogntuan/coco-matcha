package com.lgcns.team17.aidd.fzrev.dto.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FloorDTO {
    private Integer id;
    private Integer buildingId;
    private Integer floorNumber; // Số tầng
    private String name; // Tên hiển thị của tầng
}