package com.lgcns.team17.aidd.fzrev.domain;

import java.time.LocalDateTime;

import com.lgcns.team17.aidd.fzrev.domain.enums.ReservationStatus;
import lombok.Data;
 import lombok.Builder;
 import lombok.AllArgsConstructor;
 import lombok.NoArgsConstructor;

 @Data
 @Builder
 @NoArgsConstructor
 @AllArgsConstructor
public class Reservation {
    private Integer id;
    private Integer employeeId;
    private Integer seatId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private ReservationStatus status;
    private LocalDateTime checkInAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer extendedFromReservationId;
}