package com.lgcns.team17.aidd.fzrev.exception;

import org.springframework.http.HttpStatus;
// Không cần @ResponseStatus ở đây nếu bạn muốn GlobalExceptionHandler xử lý và map tới status cụ thể hơn
// @ResponseStatus(HttpStatus.BAD_REQUEST)
public class BusinessLogicException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private final String errorCode; // Mã lỗi tùy chỉnh (ví dụ: RE001, RE002)
    private final HttpStatus httpStatus; // Tùy chọn: HttpStatus cụ thể cho lỗi này

    /**
     * Constructs a new business logic exception with the specified error code and detail message.
     * Defaults to HttpStatus.BAD_REQUEST.
     *
     * @param errorCode the error code associated with this business logic violation.
     * @param message the detail message.
     */
    public BusinessLogicException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.httpStatus = HttpStatus.BAD_REQUEST; // Mặc định là BAD_REQUEST
    }

    /**
     * Constructs a new business logic exception with the specified error code, detail message,
     * and HTTP status.
     *
     * @param errorCode the error code.
     * @param message the detail message.
     * @param httpStatus the HTTP status to be associated with this exception.
     */
    public BusinessLogicException(String errorCode, String message, HttpStatus httpStatus) {
        super(message);
        this.errorCode = errorCode;
        this.httpStatus = httpStatus;
    }

    /**
     * Constructs a new business logic exception with the specified error code, detail message,
     * and cause. Defaults to HttpStatus.BAD_REQUEST.
     *
     * @param errorCode the error code.
     * @param message the detail message.
     * @param cause the cause.
     */
    public BusinessLogicException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.httpStatus = HttpStatus.BAD_REQUEST;
    }

    /**
     * Constructs a new business logic exception with the specified error code, detail message,
     * HTTP status, and cause.
     *
     * @param errorCode the error code.
     * @param message the detail message.
     * @param httpStatus the HTTP status.
     * @param cause the cause.
     */
    public BusinessLogicException(String errorCode, String message, HttpStatus httpStatus, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.httpStatus = httpStatus;
    }


    public String getErrorCode() {
        return errorCode;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}
