package com.lgcns.team17.aidd.fzrev.dto.response;

import com.lgcns.team17.aidd.fzrev.domain.enums.SeatStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SeatDetailDTO { // DTO này có thể giống hệt domain Seat nếu domain đã đủ
    private Integer id;
    private String name;
    private SeatStatus status; // AVAILABLE, UNAVAILABLE, BROKEN
    private Integer floorId;
    private String floorName; // Ví dụ "Tầng 1"
    private String buildingName;
    private LocalDateTime updatedAt;
    // Có thể thêm thông tin người đang đặt nếu status là UNAVAILABLE (tùy yêu cầu)
    private Integer currentOccupantEmployeeId;
    private LocalDateTime currentReservationEndTime;
}