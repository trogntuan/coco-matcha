package com.lgcns.team17.aidd.fzrev.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HRTokenValidationRequest {
    private String authorization;
    // constructor, getter
}
