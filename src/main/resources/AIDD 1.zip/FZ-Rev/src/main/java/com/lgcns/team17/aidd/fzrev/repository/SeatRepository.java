package com.lgcns.team17.aidd.fzrev.repository;

import com.lgcns.team17.aidd.fzrev.domain.Seat;
import com.lgcns.team17.aidd.fzrev.domain.enums.SeatStatus;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Mapper
public interface SeatRepository {
    Optional<Seat> findById(@Param("id") int id);
    List<Seat> findByFloorId(@Param("floorId") int floorId);

    int updateStatus(@Param("id") int id, @Param("status") SeatStatus status, @Param("updatedAt") LocalDateTime updatedAt);

    // Query để tìm các ghế trống trong một khoảng thời gian (U0101) - phức tạp, kết hợp ReservationRepository
    // Có thể cần một DTO đặc biệt cho kết quả này.
    List<AvailableSeatInfo> findAvailableSeatsInTimeRange(
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime,
            @Param("buildingId") Integer buildingId, // Tùy chọn
            @Param("floorId") Integer floorId,       // Tùy chọn
            @Param("offset") int offset,
            @Param("limit") int limit
    );
    long countAvailableSeatsInTimeRange( // Để phân trang cho U0101
                                         @Param("startTime") LocalDateTime startTime,
                                         @Param("endTime") LocalDateTime endTime,
                                         @Param("buildingId") Integer buildingId,
                                         @Param("floorId") Integer floorId
    );

    // Lớp nội tuyến hoặc DTO riêng cho kết quả query phức tạp
    // (Nếu dùng cách này, MyBatis cần cấu hình result map)
    class SeatWithDetails extends Seat {
        private String floorName;
        private String buildingName;
        private String buildingAddress;
        // getters, setters
    }

    class AvailableSeatInfo extends Seat { // Kế thừa từ Seat để có thông tin cơ bản
        // Có thể không cần thêm trường gì ở đây nếu Seat đã đủ
        // Hoặc có thể chỉ chứa các trường cần thiết cho việc hiển thị ghế trống
        // private String buildingName;
        // private Integer floorNumber;
    }
}
