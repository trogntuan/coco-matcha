package com.lgcns.team17.aidd.fzrev.service.impl;

import com.lgcns.team17.aidd.fzrev.domain.Reservation;
import com.lgcns.team17.aidd.fzrev.domain.Seat;
import com.lgcns.team17.aidd.fzrev.domain.enums.ReservationStatus;
import com.lgcns.team17.aidd.fzrev.domain.enums.SeatStatus;
import com.lgcns.team17.aidd.fzrev.dto.request.ReservationRequestDTO;
import com.lgcns.team17.aidd.fzrev.dto.response.PagedResponseDTO;
import com.lgcns.team17.aidd.fzrev.exception.BusinessLogicException;
import com.lgcns.team17.aidd.fzrev.exception.ResourceNotFoundException;
import com.lgcns.team17.aidd.fzrev.repository.ReservationRepository;
import com.lgcns.team17.aidd.fzrev.repository.SeatRepository;
import com.lgcns.team17.aidd.fzrev.service.ReservationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReservationServiceImpl implements ReservationService {
    private static final Logger logger = LoggerFactory.getLogger(ReservationServiceImpl.class);

    private final ReservationRepository reservationRepository;
    private final SeatRepository seatRepository; // Inject SeatRepository

    @Value("${app.reservation.max-duration-hours:8}")
    private int maxReservationHoursPerDay;

    @Value("${app.batch.no-show.limit-minutes:15}")
    private int noShowLimitMinutes;


    public ReservationServiceImpl(ReservationRepository reservationRepository, SeatRepository seatRepository) {
        this.reservationRepository = reservationRepository;
        this.seatRepository = seatRepository;
    }

    private int getCurrentEmployeeId() {
        // Helper để lấy employeeId từ Spring Security Context
        // Cần đảm bảo UserDetails.getUsername() trả về employeeId dạng String
        return Integer.parseInt(SecurityContextHolder.getContext().getAuthentication().getName());
    }

    private void checkOwnership(Reservation reservation, int employeeId) {
        if (reservation.getEmployeeId() != employeeId) {
            throw new BusinessLogicException("RE003", "User not authorized for this reservation.");
        }
    }

    @Override
    @Transactional
    public Reservation createReservation(int employeeId, ReservationRequestDTO request) {
        logger.info("Attempting to create reservation for employee {} with request: {}", employeeId, request);

        // 1. Validate input (đã có @Valid ở controller)
        if (request.getStartTime().isBefore(LocalDateTime.now())) {
            throw new BusinessLogicException("RE003", "Reservation start time must be in the future.");
        }
        if (!request.getEndTime().isAfter(request.getStartTime())) {
            throw new BusinessLogicException("RE001", "End time must be after start time.");
        }

        // 2. Fetch Seat and validate
        Seat seat = seatRepository.findById(request.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + request.getSeatId()));
        if (seat.getStatus() == SeatStatus.BROKEN) {
            throw new BusinessLogicException("RE003", "Cannot reserve a broken seat (" + seat.getName() + ").");
        }

        // 3. Check for overlapping reservations for the same seat
        List<ReservationStatus> conflictingStatuses = Arrays.asList(ReservationStatus.RESERVED, ReservationStatus.IN_USE);
        List<Reservation> overlapping = reservationRepository.findBySeatIdAndStatusInAndOverlappingTime(
                request.getSeatId(), conflictingStatuses, request.getStartTime(), request.getEndTime(), null);
        if (!overlapping.isEmpty()) {
            throw new BusinessLogicException("RE002", "Seat " + seat.getName() + " is already reserved for the requested time slot.");
        }

        // 4. Check daily reservation limit
        long requestedDurationMinutes = Duration.between(request.getStartTime(), request.getEndTime()).toMinutes();
        List<ReservationStatus> statusesToSum = Arrays.asList(ReservationStatus.PENDING, ReservationStatus.RESERVED, ReservationStatus.IN_USE);
        Long existingDurationMinutes = reservationRepository.sumDailyReservationDurationForEmployee(
                employeeId, request.getStartTime().toLocalDate(), statusesToSum, null);

        if ((existingDurationMinutes + requestedDurationMinutes) > maxReservationHoursPerDay * 60L) {
            throw new BusinessLogicException("RE004", "Maximum daily reservation time of " + maxReservationHoursPerDay + " hours exceeded.");
        }

        // 5. Create and save reservation
        Reservation newReservation = Reservation.builder()
                .employeeId(employeeId)
                .seatId(request.getSeatId())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .status(ReservationStatus.PENDING) // Initial status
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        reservationRepository.insert(newReservation); // MyBatis trả về số row bị ảnh hưởng, ID được set vào object
        logger.info("Reservation (ID: {}) created successfully for employee {} and seat {}", newReservation.getId(), employeeId, request.getSeatId());
        return newReservation; // newReservation giờ đã có ID
    }

    @Override
    public Reservation getReservationById(int reservationId, int employeeId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found with id: " + reservationId));
        // Admin có thể xem mọi đặt chỗ, nhân viên chỉ xem của mình
        // if (!isAdminUser() && reservation.getEmployeeId() != employeeId) { // Cần helper isAdminUser()
        //    throw new BusinessLogicException("RE003", "User not authorized to view this reservation.");
        // }
        // Tạm thời cho phép nếu ID khớp hoặc nếu admin (logic này cần làm rõ hơn cho get)
        // Để đơn giản, nếu là API "của tôi" thì controller đã truyền employeeId đúng
        return reservation;
    }


    @Override
    @Transactional
    public Reservation cancelReservation(int reservationId, int employeeId) {
        logger.info("Attempting to cancel reservation ID {} for employee {}", reservationId, employeeId);
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found with id: " + reservationId));
        checkOwnership(reservation, employeeId);

        if (reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new BusinessLogicException("RE003", "Only RESERVED reservations can be cancelled. Current status: " + reservation.getStatus());
        }

        reservationRepository.updateStatus(reservationId, ReservationStatus.CANCELLED, LocalDateTime.now());
        reservation.setStatus(ReservationStatus.CANCELLED);
        reservation.setUpdatedAt(LocalDateTime.now());
        logger.info("Reservation {} cancelled.", reservationId);
        return reservation;
    }

    @Override
    @Transactional
    public Reservation checkIn(int reservationId, int employeeId) {
        logger.info("Attempting to check-in for reservation ID {} by employee {}", reservationId, employeeId);
        // 1. Fetch reservation and seat
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found: " + reservationId));
        checkOwnership(reservation, employeeId);

        Seat seat = seatRepository.findById(reservation.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found for reservation: " + reservation.getSeatId()));

        // 2. Validate states
        if (reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new BusinessLogicException("RE003", "Reservation not in RESERVED state. Current status: " + reservation.getStatus());
        }
        if (seat.getStatus() != SeatStatus.AVAILABLE) {
            throw new BusinessLogicException("RE003", "Seat " + seat.getName() + " is not AVAILABLE for check-in. Current status: " + seat.getStatus());
        }

        // 3. Validate check-in time window (ví dụ: 15 phút trước đến `noShowLimitMinutes` sau start_time)
        LocalDateTime now = LocalDateTime.now();
        if (now.isBefore(reservation.getStartTime().minusMinutes(15)) || now.isAfter(reservation.getStartTime().plusMinutes(noShowLimitMinutes))) {
            // throw new BusinessLogicException("RE003", "Check-in is not allowed at this time. Reservation starts at " + reservation.getStartTime());
            logger.warn("Check-in for reservation {} is outside the allowed window. Current time: {}, Start time: {}", reservationId, now, reservation.getStartTime());
            // Quyết định: cho phép check-in trễ hay không? Tài liệu không nói rõ. Giả sử vẫn cho.
        }

        // 4. Update states
        LocalDateTime checkInTime = LocalDateTime.now();
        reservationRepository.updateStatusAndCheckInTime(reservationId, ReservationStatus.IN_USE, checkInTime, checkInTime);
        seatRepository.updateStatus(seat.getId(), SeatStatus.UNAVAILABLE, checkInTime);

        reservation.setStatus(ReservationStatus.IN_USE);
        reservation.setCheckInAt(checkInTime);
        reservation.setUpdatedAt(checkInTime);
        logger.info("Employee {} checked into reservation {}, seat {} is now UNAVAILABLE.", employeeId, reservationId, seat.getId());
        return reservation;
    }

    @Override
    @Transactional
    public Reservation extendReservation(int reservationId, int employeeId) {
        logger.info("Attempting to extend reservation ID {} for employee {}", reservationId, employeeId);
        // 1. Fetch original reservation and seat
        Reservation originalRes = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Original reservation not found: " + reservationId));
        checkOwnership(originalRes, employeeId);

        Seat seat = seatRepository.findById(originalRes.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found: " + originalRes.getSeatId()));

        // 2. Validate states
        if (originalRes.getStatus() != ReservationStatus.IN_USE) {
            throw new BusinessLogicException("RE003", "Only IN_USE reservations can be extended. Current status: " + originalRes.getStatus());
        }
        if (seat.getStatus() != SeatStatus.UNAVAILABLE) {
            throw new BusinessLogicException("RE003", "Seat " + seat.getName() + " must be UNAVAILABLE to extend. Current status: " + seat.getStatus());
        }

        // 3. Calculate new times for 1-hour extension
        LocalDateTime newStartTime = originalRes.getEndTime();
        LocalDateTime newEndTime = newStartTime.plusHours(1);

        if (newEndTime.toLocalDate().isAfter(newStartTime.toLocalDate()) || newEndTime.toLocalTime().equals(LocalTime.MIDNIGHT)) {
            throw new BusinessLogicException("RE003", "Extension cannot go beyond midnight or exactly to midnight of the current reservation day.");
        }

        // 4. Check for overlapping reservations for the extension period
        List<ReservationStatus> conflictingStatuses = Arrays.asList(ReservationStatus.RESERVED, ReservationStatus.IN_USE);
        List<Reservation> overlapping = reservationRepository.findBySeatIdAndStatusInAndOverlappingTime(
                originalRes.getSeatId(), conflictingStatuses, newStartTime, newEndTime, null); // Không cần exclude ID vì là bản ghi mới
        if (!overlapping.isEmpty()) {
            throw new BusinessLogicException("RE003", "Cannot extend reservation for seat " + seat.getName() + ", it is booked by another user after current reservation.");
        }

        // 5. Check total daily reservation limit (bao gồm cả chuỗi gia hạn trước đó và phần mới)
        long extensionDurationMinutes = Duration.between(newStartTime, newEndTime).toMinutes();
        List<ReservationStatus> statusesToSum = Arrays.asList(ReservationStatus.PENDING, ReservationStatus.RESERVED, ReservationStatus.IN_USE);

        // Tính tổng thời gian của cả chuỗi hiện tại (bao gồm originalRes và các phần đã gia hạn trước nó)
        // Cần một hàm helper để tìm tất cả các phần của một chuỗi đặt chỗ
        List<Reservation> currentChain = findFullReservationChain(originalRes.getId(), true); // true = backward only to find root and its chain
        long chainDurationMinutes = currentChain.stream()
                .mapToLong(r -> Duration.between(r.getStartTime(), r.getEndTime()).toMinutes())
                .sum();

        if ((chainDurationMinutes + extensionDurationMinutes) > maxReservationHoursPerDay * 60L) {
            throw new BusinessLogicException("RE004", "Maximum daily reservation time of " + maxReservationHoursPerDay + " hours exceeded with extension.");
        }

        // 6. Create new extension reservation
        Reservation extension = Reservation.builder()
                .employeeId(employeeId)
                .seatId(originalRes.getSeatId())
                .startTime(newStartTime)
                .endTime(newEndTime)
                .status(ReservationStatus.IN_USE) // Gia hạn là đang sử dụng ngay
                .checkInAt(originalRes.getCheckInAt()) // Kế thừa thời gian check-in
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .extendedFromReservationId(originalRes.getId()) // Liên kết với đặt chỗ gốc (hoặc phần gia hạn gần nhất)
                .build();

        reservationRepository.insert(extension);
        logger.info("Reservation {} extended for employee {} with new reservation ID {}.", reservationId, employeeId, extension.getId());
        return extension;
    }


    @Override
    @Transactional
    public List<Reservation> returnSeat(int reservationId, int employeeId) {
        logger.info("Attempting to return seat for reservation ID {} by employee {}", reservationId, employeeId);
        Reservation targetReservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found: " + reservationId));
        checkOwnership(targetReservation, employeeId);

        if (targetReservation.getStatus() != ReservationStatus.IN_USE) {
            throw new BusinessLogicException("RE003", "Reservation not IN_USE, cannot return seat. Current status: " + targetReservation.getStatus());
        }

        Seat seat = seatRepository.findById(targetReservation.getSeatId())
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found for reservation: " + targetReservation.getSeatId()));
        if (seat.getStatus() != SeatStatus.UNAVAILABLE) {
            throw new BusinessLogicException("RE003", "Seat " + seat.getName() + " is not UNAVAILABLE. Current status: " + seat.getStatus());
        }

        // Tìm tất cả các đặt chỗ trong chuỗi gia hạn (cả quá khứ và tương lai của chuỗi từ targetReservation)
        List<Reservation> fullChain = findFullReservationChain(reservationId, false); // false = both directions
        List<Integer> chainIdsToUpdate = new ArrayList<>();

        for (Reservation r : fullChain) {
            // Chỉ cập nhật các phần IN_USE hoặc RESERVED (phần tương lai của chuỗi)
            if (r.getStatus() == ReservationStatus.IN_USE || r.getStatus() == ReservationStatus.RESERVED) {
                chainIdsToUpdate.add(r.getId());
            }
        }

        if (!chainIdsToUpdate.isEmpty()) {
            reservationRepository.updateStatusForIds(chainIdsToUpdate, ReservationStatus.COMPLETED, LocalDateTime.now());
            logger.info("Updated reservations in chain {} to COMPLETED.", chainIdsToUpdate);
        } else {
            // Trường hợp không có chuỗi, chỉ cập nhật targetReservation
            reservationRepository.updateStatus(targetReservation.getId(), ReservationStatus.COMPLETED, LocalDateTime.now());
            logger.info("Updated reservation {} to COMPLETED.", targetReservation.getId());
        }

        seatRepository.updateStatus(seat.getId(), SeatStatus.AVAILABLE, LocalDateTime.now());
        logger.info("Seat {} (ID: {}) returned by employee {}, set to AVAILABLE.", seat.getName(), seat.getId(), employeeId);

        // Tải lại các đặt chỗ đã cập nhật để trả về
        List<Reservation> updatedChain = new ArrayList<>();
        if (!chainIdsToUpdate.isEmpty()) {
            for (Integer id : chainIdsToUpdate) {
                reservationRepository.findById(id).ifPresent(updatedChain::add);
            }
        } else {
            reservationRepository.findById(targetReservation.getId()).ifPresent(updatedChain::add);
        }
        return updatedChain;
    }

    @Override
    public List<Reservation> getMyCurrentReservations(int employeeId) {
        // Lấy các đặt chỗ PENDING, RESERVED, IN_USE có end_time >= thời điểm hiện tại
        return reservationRepository.findByEmployeeIdAndStatusInAndEndTimeAfter(
                employeeId,
                Arrays.asList(ReservationStatus.PENDING, ReservationStatus.RESERVED, ReservationStatus.IN_USE),
                LocalDateTime.now()
        );
    }

    @Override
    public PagedResponseDTO<Reservation> getMyReservationHistory(int employeeId, LocalDate startDate, LocalDate endDate, int page, int size) {
        // Validate page, size
        if (page < 0) page = 0;
        if (size <= 0) size = 5; // Mặc định

        LocalDateTime queryStartDate = startDate.atStartOfDay();
        LocalDateTime queryEndDate = endDate.atTime(LocalTime.MAX);

        // Tài liệu nói "lên đến 1 tháng", logic này cần được controller hoặc service kiểm tra
        // Ví dụ: if (Duration.between(queryStartDate, queryEndDate).toDays() > 30) { // throw error }

        int offset = page * size;
        List<Reservation> history = reservationRepository.findHistoryByEmployeeIdAndDateRange(
                employeeId, queryStartDate, queryEndDate, offset, size
        );
        // Cần một query để đếm tổng số record cho phân trang (không có trong ví dụ repository)
        long totalElements = reservationRepository.countHistoryByEmployeeIdAndDateRange(employeeId, queryStartDate, queryEndDate); // Cần implement method này


        // return new PagedResponseDTO<>(history, page, size, totalElements);
        // Tạo class PagedResponseDTO<T>
        // Ví dụ:
        return new PagedResponseDTO<>(history, page, size, totalElements, (int)Math.ceil((double)totalElements / size));
    }


    @Override
    @Transactional
    public List<Reservation> forceReturnSeatByAdmin(int seatId) {
        // Logic cho admin:
        // 1. Tìm ghế
        Seat seat = seatRepository.findById(seatId)
                .orElseThrow(() -> new ResourceNotFoundException("Seat not found with id: " + seatId));

        // 2. Tìm các đặt chỗ IN_USE hiện tại cho ghế này
        List<Reservation> activeReservations = reservationRepository.findActiveInUseReservationsBySeatIdAtTime(seatId, LocalDateTime.now());
        if (activeReservations.isEmpty()) {
            // Nếu ghế đang UNAVAILABLE mà không có đặt chỗ IN_USE nào -> có thể là lỗi dữ liệu
            // Hoặc chỉ đơn giản là không có gì để buộc trả. Cập nhật trạng thái ghế nếu cần.
            if (seat.getStatus() == SeatStatus.UNAVAILABLE) {
                seatRepository.updateStatus(seatId, SeatStatus.AVAILABLE, LocalDateTime.now());
                logger.warn("Seat {} was UNAVAILABLE but no active reservation found. Set to AVAILABLE by admin.", seatId);
            }
            return Collections.emptyList();
        }

        List<Reservation> allAffectedReservations = new ArrayList<>();
        for (Reservation activeRes : activeReservations) {
            List<Reservation> chain = findFullReservationChain(activeRes.getId(), false); // Cả chuỗi
            allAffectedReservations.addAll(chain);
        }

        List<Integer> idsToForceCancel = allAffectedReservations.stream()
                .filter(r -> r.getStatus() == ReservationStatus.IN_USE || r.getStatus() == ReservationStatus.RESERVED)
                .map(Reservation::getId)
                .distinct() // Tránh trùng lặp nếu các activeReservations thuộc cùng một chuỗi
                .collect(Collectors.toList());

        if (!idsToForceCancel.isEmpty()) {
            reservationRepository.updateStatusForIds(idsToForceCancel, ReservationStatus.FORCED_CANCEL, LocalDateTime.now());
            logger.info("Admin forced return for seat {}, reservations {} updated to FORCED_CANCEL.", seatId, idsToForceCancel);
        }

        seatRepository.updateStatus(seatId, SeatStatus.AVAILABLE, LocalDateTime.now());
        logger.info("Seat {} set to AVAILABLE by admin force return.", seatId);

        List<Reservation> updatedReservations = new ArrayList<>();
        if (!idsToForceCancel.isEmpty()) {
            for (Integer id : idsToForceCancel) {
                reservationRepository.findById(id).ifPresent(updatedReservations::add);
            }
        }
        return updatedReservations;
    }


    // Helper method to find full reservation chain (can be complex)
    // backwardOnly: true_Chỉ tìm ngược về gốc và các phần của chuỗi đó.
    // backwardOnly: false_Tìm cả ngược và xuôi từ reservationId đã cho.
    private List<Reservation> findFullReservationChain(int reservationId, boolean backwardOnly) {
        List<Reservation> chain = new ArrayList<>();
        Reservation current = reservationRepository.findById(reservationId).orElse(null);
        if (current == null) return Collections.emptyList();

        // Go backward to find the root and add all previous parts
        Reservation temp = current;
        while (temp != null) {
            if (!chain.contains(temp)) { // Tránh thêm trùng nếu có vòng lặp (không nên xảy ra)
                chain.add(0, temp); // Add to beginning to keep chronological order
            }
            if (temp.getExtendedFromReservationId() == null) break; // Reached the root
            temp = reservationRepository.findById(temp.getExtendedFromReservationId()).orElse(null);
        }

        if (!backwardOnly) {
            // Go forward from the last element added (which is 'current' or a successor if 'current' was not a leaf)
            // Start from the initial 'current' if it's already in the chain.
            // This part needs to be careful not to create infinite loops if data is inconsistent.
            // We need to find elements whose `extendedFromReservationId` is the ID of an element already in the chain.
            List<Reservation> forwardParts = new ArrayList<>();
            List<Reservation> toSearchFrom = new ArrayList<>(chain); // Các phần đã có trong chuỗi (từ gốc đến `current`)

            while (!toSearchFrom.isEmpty()) {
                Reservation lastInSearch = toSearchFrom.remove(0);
                List<Reservation> extensions = reservationRepository.findByExtendedFromReservationId(lastInSearch.getId());
                for (Reservation ext : extensions) {
                    if (chain.stream().noneMatch(r -> r.getId().equals(ext.getId()))) { // Chỉ thêm nếu chưa có
                        forwardParts.add(ext);
                        toSearchFrom.add(ext); // Thêm vào danh sách để tìm tiếp các phần mở rộng của nó
                    }
                }
            }
            chain.addAll(forwardParts);
        }
        return chain.stream().distinct().collect(Collectors.toList()); // Đảm bảo không có trùng lặp cuối cùng
    }
}
