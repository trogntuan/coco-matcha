package com.lgcns.team17.aidd.fzrev.controller;

import com.lgcns.team17.aidd.fzrev.domain.Reservation;
import com.lgcns.team17.aidd.fzrev.domain.enums.ReservationStatus;
import com.lgcns.team17.aidd.fzrev.dto.request.ReservationRequestDTO;
import com.lgcns.team17.aidd.fzrev.dto.response.PagedResponseDTO;
import com.lgcns.team17.aidd.fzrev.service.ReservationService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    private int getAuthenticatedEmployeeId(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new IllegalStateException("User not authenticated"); // Should be caught by Spring Security
        }
        return Integer.parseInt(authentication.getName()); // Assumes username is employeeId
    }

    @PostMapping
//    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<Reservation> createReservation(@Valid @RequestBody ReservationRequestDTO reservationRequest, Authentication authentication) {
        int employeeId = getAuthenticatedEmployeeId(authentication);
        Reservation createdReservation = reservationService.createReservation(employeeId, reservationRequest);
        return new ResponseEntity<>(createdReservation, HttpStatus.CREATED);
    }

    @GetMapping()
//    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<List<Reservation>> getMyCurrentReservations(Authentication authentication) {
        int employeeId = getAuthenticatedEmployeeId(authentication);
        List<Reservation> reservations = reservationService.getMyCurrentReservations(employeeId);
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/history")
//    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<PagedResponseDTO<Reservation>> getMyReservationHistory(
            Authentication authentication,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size) {
        int employeeId = getAuthenticatedEmployeeId(authentication);
        PagedResponseDTO<Reservation> history = reservationService.getMyReservationHistory(employeeId, startDate, endDate, page, size);
        return ResponseEntity.ok(history);
    }

    @GetMapping("/{reservationId}")
//    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')") // Nhân viên chỉ xem được của mình (logic trong service)
    public ResponseEntity<Reservation> getReservationById(@PathVariable int reservationId, Authentication authentication) {
        int employeeId = getAuthenticatedEmployeeId(authentication); // employeeId của người đang gọi
        // Service sẽ kiểm tra quyền xem
        Reservation reservation = reservationService.getReservationById(reservationId, employeeId);
        return ResponseEntity.ok(reservation);
    }

    @PutMapping("/{reservationId}/cancel")
//    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<Reservation> cancelReservation(@PathVariable int reservationId, Authentication authentication) {
        int employeeId = getAuthenticatedEmployeeId(authentication);
        Reservation cancelledReservation = reservationService.cancelReservation(reservationId, employeeId);
        return ResponseEntity.ok(cancelledReservation);
    }

    @PostMapping("/{reservationId}/check-in")
//    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<Reservation> checkIn(@PathVariable int reservationId, Authentication authentication) {
        int employeeId = getAuthenticatedEmployeeId(authentication);
        Reservation checkedInReservation = reservationService.checkIn(reservationId, employeeId);
        return ResponseEntity.ok(checkedInReservation);
    }

    @PostMapping("/{reservationId}/extend")
//    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<Reservation> extendReservation(@PathVariable int reservationId, Authentication authentication) {
        int employeeId = getAuthenticatedEmployeeId(authentication);
        Reservation extendedReservation = reservationService.extendReservation(reservationId, employeeId);
        return ResponseEntity.ok(extendedReservation);
    }

    @PostMapping("/{reservationId}/return")
//    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<List<Reservation>> returnSeat(@PathVariable int reservationId, Authentication authentication) {
        int employeeId = getAuthenticatedEmployeeId(authentication);
        List<Reservation> returnedReservations = reservationService.returnSeat(reservationId, employeeId);
        return ResponseEntity.ok(returnedReservations);
    }
}