package com.lgcns.team17.aidd.fzrev.filter;
// Import service mới
import com.lgcns.team17.aidd.fzrev.dto.response.HRTokenValidationResponse;
import com.lgcns.team17.aidd.fzrev.service.HRManagementService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component; // Đánh dấu là Component để Spring quản lý
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import reactor.core.publisher.Mono; // Import Mono

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component // Quan trọng: Đánh dấu là Component để Spring có thể inject HRManagementService
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    @Autowired
    private HRManagementService hrManagementService; // Inject service gọi HRMS

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        try {
            String jwt = parseJwt(request); // Lấy token từ header "Authorization: Bearer <token>"
            if (jwt != null) {
                // Gọi HRMS để xác thực token. `.block()` sẽ chờ kết quả (đồng bộ)
                // Trong môi trường non-blocking hoàn toàn, bạn sẽ không .block() ở đây.
                HRTokenValidationResponse validationData = hrManagementService.validateToken("Bearer " + jwt)
                        .onErrorResume(e -> { // Xử lý lỗi từ Mono (ví dụ timeout, lỗi mạng trước khi gọi API)
                            logger.error("Error obtaining token validation response from HRMS: {}", e.getMessage());
                            HRTokenValidationResponse errorResponse = new HRTokenValidationResponse();
                            errorResponse.setValid(false);
                            errorResponse.setMessage("Failed to connect to HRMS for token validation: " + e.getMessage());
                            return Mono.just(errorResponse);
                        })
                        .block(); // Chuyển từ non-blocking (Mono) sang blocking

                if (validationData != null && validationData.isValid()) {
                    String employeeIdStr = String.valueOf(validationData.getEmployeeId());
                    List<String> rolesFromHR = validationData.getIsAdmin()? List.of("ADMIN") : List.of("EMPLOYEE");

                    List<GrantedAuthority> authorities = rolesFromHR.stream()
                            .map(role -> new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()))
                            .collect(Collectors.toList());

                    UserDetails userDetails = new User(employeeIdStr, "", authorities);

                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                            userDetails, null, userDetails.getAuthorities());
                    SecurityContextHolder.getContext().setAuthentication(authentication);

                    logger.debug("User {} authenticated with roles: {}", employeeIdStr, rolesFromHR);
                } else {
                    String message = (validationData != null) ? validationData.getMessage() : "Unknown validation error";
                    logger.warn("Token validation failed or HRMS response indicates invalid token: {}", message);
                    // Không set authentication, request sẽ bị từ chối bởi AuthEntryPointJwt
                    // AuthEntryPointJwt sẽ được kích hoạt nếu SecurityContextHolder.getContext().getAuthentication() là null
                    // hoặc nếu một AuthenticationException được ném ra sau đó trong chuỗi filter.
                }
            }
        } catch (Exception e) {
            // Lỗi này có thể xảy ra nếu .block() bị gián đoạn hoặc có lỗi không mong muốn khác
            logger.error("Cannot set user authentication due to an unexpected error: {}", e.getMessage(), e);
            // Đảm bảo SecurityContext được clear nếu có lỗi
            SecurityContextHolder.clearContext();
        }

        filterChain.doFilter(request, response);
    }

    private String parseJwt(HttpServletRequest request) {
        String headerAuth = request.getHeader("Authorization");
        if (StringUtils.hasText(headerAuth) && headerAuth.startsWith("Bearer ")) {
            return headerAuth.substring(7);
        }
        return null;
    }
}