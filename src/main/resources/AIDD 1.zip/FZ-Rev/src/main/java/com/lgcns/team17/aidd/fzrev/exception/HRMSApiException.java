package com.lgcns.team17.aidd.fzrev.exception;

import org.springframework.http.HttpStatusCode;

public class HRMSApiException extends RuntimeException {
    private final HttpStatusCode statusCode;

    public HRMSApiException(String message, HttpStatusCode statusCode) {
        super(message);
        this.statusCode = statusCode;
    }

    public HttpStatusCode getStatusCode() {
        return statusCode;
    }
}