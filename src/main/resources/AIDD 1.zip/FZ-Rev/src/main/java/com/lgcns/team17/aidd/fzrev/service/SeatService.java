package com.lgcns.team17.aidd.fzrev.service;

import com.lgcns.team17.aidd.fzrev.dto.response.*;
import com.lgcns.team17.aidd.fzrev.repository.SeatRepository;

import java.util.List;

public interface SeatService {
    // For Employees (U0203, U0204, U0201)
    List<BuildingDTO> getAllBuildings();
    List<FloorDTO> getFloorsByBuilding(int buildingId);
    List<SeatStatusDTO> getSeatStatusesByFloor(int floorId); // U0201

    // For Admins (A0102)
    List<SeatDetailDTO> getDetailedSeatStatusesByFloor(int floorId); // A0102

    // For searching available seats (U0101)
    PagedResponseDTO<SeatRepository.AvailableSeatInfo> findAvailableSeats(
            AvailableSeatSearchRequestDTO searchRequest, int page, int size);
}