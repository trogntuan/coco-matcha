package com.lgcns.team17.aidd.fzrev.dto.response;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SeatStatusDTO { // DTO này đơn giản hơn SeatDetailDTO
    private Integer id;
    private String name; // Tên ghế, ví dụ A-1
    private String status; // "AVAILABLE" hoặc "UNAVAILABLE" (hoặc một enum tùy chỉnh cho UI)
    // Dựa trên Seat.status và có thể cả Reservation status
    private String buildingName;
    private String floorName; // Ví dụ "Tầng 1"
}
