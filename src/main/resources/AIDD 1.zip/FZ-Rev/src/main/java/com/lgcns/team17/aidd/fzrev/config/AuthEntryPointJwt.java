package com.lgcns.team17.aidd.fzrev.config;


import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@Component // Đánh dấu là một Spring component để có thể inject hoặc được SecurityConfig sử dụng
public class AuthEntryPointJwt implements AuthenticationEntryPoint {

    private static final Logger logger = LoggerFactory.getLogger(AuthEntryPointJwt.class);
    private final ObjectMapper objectMapper = new ObjectMapper(); // Để serialize Map thành JSON

    @Override
    public void commence(HttpServletRequest request,
                         HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {

        logger.error("Unauthorized error: {}", authException.getMessage());
        // Bạn có thể log thêm request.getRequestURI() nếu muốn biết tài nguyên nào bị từ chối

        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // HTTP Status 401

        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        body.put("status", HttpServletResponse.SC_UNAUTHORIZED);
        body.put("error", "Unauthorized");
        body.put("message", "Authentication token was not provided, is invalid, or has expired. Full authentication is required to access this resource.");
        // Bạn có thể tùy chỉnh message dựa trên authException.getMessage() nếu muốn chi tiết hơn,
        // nhưng cẩn thận không lộ thông tin nhạy cảm.
        // body.put("detail", authException.getMessage()); // Cân nhắc việc này
        body.put("path", request.getServletPath());

        // Ghi JSON response vào output stream
        objectMapper.writeValue(response.getOutputStream(), body);
    }
}