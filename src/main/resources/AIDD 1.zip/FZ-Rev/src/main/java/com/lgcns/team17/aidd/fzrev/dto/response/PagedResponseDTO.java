package com.lgcns.team17.aidd.fzrev.dto.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Data Transfer Object for paged responses.
 *
 * @param <T> the type of the content in the page
 */
@Getter
@Setter
@NoArgsConstructor // Cần thiết cho Jackson Deserialization nếu DTO này cũng được dùng làm request
public class PagedResponseDTO<T> {

    /**
     * The content of the current page.
     */
    private List<T> content;

    /**
     * The current page number (0-indexed).
     */
    private int currentPage;

    /**
     * The number of items requested per page.
     */
    private int pageSize;

    /**
     * The total number of items available across all pages.
     */
    private long totalElements;

    /**
     * The total number of pages available.
     */
    private int totalPages;

    /**
     * Indicates if this is the first page.
     */
    private boolean first;

    /**
     * Indicates if this is the last page.
     */
    private boolean last;

    /**
     * The number of elements in the current page.
     */
    private int numberOfElements;

    /**
     * Indicates if the current page is empty.
     */
    private boolean empty;


    /**
     * Constructor to create a PagedResponseDTO.
     *
     * @param content The content of the current page.
     * @param currentPage The current page number (0-indexed).
     * @param pageSize The number of items requested per page.
     * @param totalElements The total number of items available across all pages.
     */
    public PagedResponseDTO(List<T> content, int currentPage, int pageSize, long totalElements) {
        this.content = content;
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.totalElements = totalElements;

        if (pageSize > 0) {
            this.totalPages = (int) Math.ceil((double) totalElements / pageSize);
        } else {
            this.totalPages = (totalElements > 0) ? 1 : 0;
        }

        this.first = (currentPage == 0);
        this.last = (currentPage >= totalPages - 1); // currentPage là 0-indexed
        this.numberOfElements = (content != null) ? content.size() : 0;
        this.empty = (this.numberOfElements == 0);
    }

    /**
     * Constructor to create a PagedResponseDTO, calculating totalPages.
     * This is a convenience constructor if totalPages is already known.
     *
     * @param content The content of the current page.
     * @param currentPage The current page number (0-indexed).
     * @param pageSize The number of items requested per page.
     * @param totalElements The total number of items available across all pages.
     * @param totalPages The total number of pages available.
     */
    public PagedResponseDTO(List<T> content, int currentPage, int pageSize, long totalElements, int totalPages) {
        this.content = content;
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.totalElements = totalElements;
        this.totalPages = totalPages;

        this.first = (currentPage == 0);
        this.last = (currentPage >= totalPages - 1);
        this.numberOfElements = (content != null) ? content.size() : 0;
        this.empty = (this.numberOfElements == 0);
    }

}