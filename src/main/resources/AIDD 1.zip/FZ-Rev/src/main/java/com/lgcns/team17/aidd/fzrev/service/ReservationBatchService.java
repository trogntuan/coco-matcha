package com.lgcns.team17.aidd.fzrev.service;

import com.lgcns.team17.aidd.fzrev.domain.Reservation;
import com.lgcns.team17.aidd.fzrev.domain.Seat;
import com.lgcns.team17.aidd.fzrev.domain.enums.ReservationStatus;
import com.lgcns.team17.aidd.fzrev.domain.enums.SeatStatus;
import com.lgcns.team17.aidd.fzrev.repository.ReservationRepository;
import com.lgcns.team17.aidd.fzrev.repository.SeatRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;


import java.util.Arrays;

@Service
public class ReservationBatchService {
    private static final Logger logger = LoggerFactory.getLogger(ReservationBatchService.class);

    private final ReservationRepository reservationRepository;
    private final SeatRepository seatRepository;

    @Value("${app.batch.no-show.limit-minutes:15}")
    private int noShowLimitMinutes;

    public ReservationBatchService(ReservationRepository reservationRepository, SeatRepository seatRepository) {
        this.reservationRepository = reservationRepository;
        this.seatRepository = seatRepository;
    }

    @Scheduled(cron = "${app.batch.pending-to-reserved.cron:0 */1 * * * ?}")
    @Transactional
    public void processPendingReservations() {
        logger.info("Batch Job: processPendingReservations - Started at {}", LocalDateTime.now());
        // 1. Lấy các PENDING reservations (ví dụ, những PENDING có start_time trong X giờ tới)
        //    Hoặc theo logic "xác nhận" của tài liệu. Giả sử lấy tất cả PENDING.
        List<Reservation> pendingList = reservationRepository.findReservationsByStatusAndStartTimeBefore(
                ReservationStatus.PENDING, LocalDateTime.now().plusDays(7)); // Lấy PENDING trong 7 ngày tới (ví dụ)

        int successCount = 0;
        int failCount = 0;

        for (Reservation pending : pendingList) {
            // 2. Kiểm tra lại tính hợp lệ (ghế không BROKEN, không trùng với RESERVED/IN_USE khác)
            Seat seat = seatRepository.findById(pending.getSeatId()).orElse(null);
            if (seat == null || seat.getStatus() == SeatStatus.BROKEN) {
                reservationRepository.updateStatus(pending.getId(), ReservationStatus.FAIL, LocalDateTime.now());
                logger.warn("Pending reservation {} failed: Seat {} not found or broken.", pending.getId(), pending.getSeatId());
                failCount++;
                continue;
            }

            List<Reservation> overlapping = reservationRepository.findBySeatIdAndStatusInAndOverlappingTime(
                    pending.getSeatId(),
                    Arrays.asList(ReservationStatus.RESERVED, ReservationStatus.IN_USE),
                    pending.getStartTime(),
                    pending.getEndTime(),
                    pending.getId() // Loại trừ chính nó
            );

            if (overlapping.isEmpty()) {
                reservationRepository.updateStatus(pending.getId(), ReservationStatus.RESERVED, LocalDateTime.now());
                logger.info("Pending reservation {} confirmed to RESERVED.", pending.getId());
                successCount++;
            } else {
                reservationRepository.updateStatus(pending.getId(), ReservationStatus.FAIL, LocalDateTime.now());
                logger.warn("Pending reservation {} failed: Overlapping with existing reservations {}.", pending.getId(), overlapping.stream().map(Reservation::getId).toList());
                failCount++;
            }
        }
        logger.info("Batch Job: processPendingReservations - Finished. RESERVED: {}, FAIL: {}", successCount, failCount);
    }


    @Scheduled(cron = "${app.batch.reserved-to-noshow.cron:0 */5 * * * ?}")
    @Transactional
    public void processNoShowReservations() {
        logger.info("Batch Job: processNoShowReservations - Started at {}", LocalDateTime.now());
        // Tìm các RESERVED mà start_time đã qua + noShowLimitMinutes và chưa check-in
        LocalDateTime cutoffTime = LocalDateTime.now().minusMinutes(noShowLimitMinutes);
        List<Reservation> candidates = reservationRepository.findReservationsByStatusAndStartTimeBefore(ReservationStatus.RESERVED, cutoffTime);
        int noShowCount = 0;
        for (Reservation r : candidates) {
            if (r.getCheckInAt() == null) { // Kiểm tra lại chưa check-in
                reservationRepository.updateStatus(r.getId(), ReservationStatus.NO_SHOW, LocalDateTime.now());
                logger.info("Reservation {} marked as NO_SHOW.", r.getId());
                noShowCount++;
            }
        }
        logger.info("Batch Job: processNoShowReservations - Finished. Marked {} as NO_SHOW.", noShowCount);
    }

    @Scheduled(cron = "${app.batch.inuse-to-completed.cron:0 */2 * * * ?}")
    @Transactional
    public void processCompletedReservations() {
        logger.info("Batch Job: processCompletedReservations - Started at {}", LocalDateTime.now());
        // Tìm các IN_USE mà end_time đã qua
        List<Reservation> expired = reservationRepository.findReservationsByStatusAndEndTimeBefore(ReservationStatus.IN_USE, LocalDateTime.now());
        int completedCount = 0;
        for (Reservation r : expired) {
            reservationRepository.updateStatus(r.getId(), ReservationStatus.COMPLETED, LocalDateTime.now());
            seatRepository.updateStatus(r.getSeatId(), SeatStatus.AVAILABLE, LocalDateTime.now());
            logger.info("Reservation {} (seat {}) marked as COMPLETED due to expiration. Seat set to AVAILABLE.", r.getId(), r.getSeatId());
            completedCount++;
        }
        logger.info("Batch Job: processCompletedReservations - Finished. Marked {} as COMPLETED.", completedCount);
    }
}