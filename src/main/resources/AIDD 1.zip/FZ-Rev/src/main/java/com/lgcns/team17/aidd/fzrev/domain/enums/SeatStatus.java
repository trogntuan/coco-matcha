package com.lgcns.team17.aidd.fzrev.domain.enums;
public enum SeatStatus {
    AVAILABLE, UNAVAILABLE, BROKEN
}
