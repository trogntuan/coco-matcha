package com.lgcns.team17.aidd.fzrevc.entity;

import lombok.Data;

@Data
public class Building {
    private Long id;
    private String name;
    private String address;
    private String description;
}