package com.lgcns.team17.aidd.fzrevc.controller;

import com.lgcns.team17.aidd.fzrevc.dto.response.ApiResponse;
import com.lgcns.team17.aidd.fzrevc.dto.response.SeatResponse;
import com.lgcns.team17.aidd.fzrevc.security.AuthenticatedUser;
import com.lgcns.team17.aidd.fzrevc.service.AdminService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin") // Consistent API path prefix
@RequiredArgsConstructor
@Slf4j
public class AdminController {
    private final AdminService adminService;

    @PutMapping("/seats/{seatId}/force-checkout") // A0101
    public ResponseEntity<ApiResponse<Void>> forceCheckoutSeat(
            @AuthenticationPrincipal AuthenticatedUser adminUser, // Lấy thông tin admin đã xác thực
            @PathVariable Long seatId) {
        // adminUser.getId() có thể được truyền vào service để log ai đã thực hiện hành động
        adminService.forceCheckoutSeat(seatId, adminUser.getId());
        return ResponseEntity.ok(ApiResponse.success("ADM001", "Seat forced checkout successfully.", null));
    }

    @GetMapping("/seats/detailed-status") // A0102
    public ResponseEntity<ApiResponse<List<SeatResponse>>> getDetailedSeatStatus(
            // @AuthenticationPrincipal AuthenticatedUser adminUser, // Không cần thiết cho logic này
            @RequestParam(required = false) Long buildingId,
            @RequestParam(required = false) Long floorId) {
        List<SeatResponse> seatResponses = adminService.getDetailedSeatStatus(buildingId, floorId);
        return ResponseEntity.ok(ApiResponse.success("ADM002", "Detailed seat status retrieved successfully.", seatResponses));
    }
}