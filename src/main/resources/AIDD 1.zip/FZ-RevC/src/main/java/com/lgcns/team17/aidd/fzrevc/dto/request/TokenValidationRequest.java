package com.lgcns.team17.aidd.fzrevc.dto.request;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TokenValidationRequest {
    private String authorization; // e.g., "Bearer <token>"
}