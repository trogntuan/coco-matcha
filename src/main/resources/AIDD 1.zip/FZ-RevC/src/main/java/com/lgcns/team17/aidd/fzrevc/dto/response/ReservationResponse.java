package com.lgcns.team17.aidd.fzrevc.dto.response;

import com.lgcns.team17.aidd.fzrevc.enums.ReservationStatus;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ReservationResponse {
    private Long id;
    private Long employeeId;
    private String employeeName;
    private Long seatId;
    private String seatNumber;
    private String buildingName;
    private String floorName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private ReservationStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime checkInAt;
    private Long extendedFromReservationId;
}