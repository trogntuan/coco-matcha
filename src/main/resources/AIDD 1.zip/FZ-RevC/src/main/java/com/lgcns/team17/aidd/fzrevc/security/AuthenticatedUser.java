package com.lgcns.team17.aidd.fzrevc.security;

import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Getter
public class AuthenticatedUser implements UserDetails {
    private final Long id;
    private final String username; // Employee ID as string or email
    private final boolean isAdmin;
    private final Collection<? extends GrantedAuthority> authorities;
    private final String token; // Original token

    public AuthenticatedUser(Long id, String username, boolean isAdmin,
                             List<GrantedAuthority> authorities, String token) {
        this.id = id;
        this.username = username;
        this.isAdmin = isAdmin;
        this.authorities = Collections.unmodifiableList(authorities);
        this.token = token;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() { return authorities; }
    @Override
    public String getPassword() { return null; } // Not used for JWT
    @Override
    public String getUsername() { return username; }
    @Override
    public boolean isAccountNonExpired() { return true; }
    @Override
    public boolean isAccountNonLocked() { return true; }
    @Override
    public boolean isCredentialsNonExpired() { return true; }
    @Override
    public boolean isEnabled() { return true; }
}
