package com.lgcns.team17.aidd.fzrevc.controller;

import com.lgcns.team17.aidd.fzrevc.dto.request.FindAvailableSeatsRequest;
import com.lgcns.team17.aidd.fzrevc.dto.response.ApiResponse;
import com.lgcns.team17.aidd.fzrevc.dto.response.SeatResponse;
import com.lgcns.team17.aidd.fzrevc.entity.Building;
import com.lgcns.team17.aidd.fzrevc.entity.Floor;
import com.lgcns.team17.aidd.fzrevc.service.SeatService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
// import org.springframework.security.core.annotation.AuthenticationPrincipal; // Không cần thiết ở đây
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/seats")
@RequiredArgsConstructor
public class SeatController {

    private final SeatService seatService;


    @GetMapping("/available") // U0101
    public ResponseEntity<ApiResponse<List<SeatResponse>>> findAvailableSeats(
            @Valid @ModelAttribute FindAvailableSeatsRequest requestParams) {
        List<SeatResponse> availableSeats = seatService.findAvailableSeats(
                requestParams.getBuildingId(),
                requestParams.getFloorId(),
                requestParams.getStartTime(),
                requestParams.getEndTime(),
                requestParams.getSkip(),
                requestParams.getLimit()
        );
        return ResponseEntity.ok(ApiResponse.success("SEAT001", "Available seats retrieved.", availableSeats));
    }

    @GetMapping("/status") // U0201
    public ResponseEntity<ApiResponse<List<SeatResponse>>> getSeatStatusForEmployee(
            // @AuthenticationPrincipal AuthenticatedUser currentUser,
            @RequestParam Long buildingId,
            @RequestParam Long floorId) {
        List<SeatResponse> seatStatuses = seatService.getSeatStatus(buildingId, floorId);
        return ResponseEntity.ok(ApiResponse.success("SEAT002", "Seat statuses retrieved.", seatStatuses));
    }

    @GetMapping("/buildings") // U0203
    public ResponseEntity<ApiResponse<List<Building>>> getAllBuildings(
            /* @AuthenticationPrincipal AuthenticatedUser currentUser */ ) {
        List<Building> buildings = seatService.getAllBuildings();
        return ResponseEntity.ok(ApiResponse.success("BLD001", "All buildings retrieved.", buildings));
    }

    @GetMapping("/buildings/{buildingId}/floors") // U0204
    public ResponseEntity<ApiResponse<List<Floor>>> getFloorsByBuilding(
            // @AuthenticationPrincipal AuthenticatedUser currentUser,
            @PathVariable Long buildingId) {
        List<Floor> floors = seatService.getFloorsByBuildingId(buildingId);
        return ResponseEntity.ok(ApiResponse.success("FLR001", "Floors retrieved for building.", floors));
    }
}