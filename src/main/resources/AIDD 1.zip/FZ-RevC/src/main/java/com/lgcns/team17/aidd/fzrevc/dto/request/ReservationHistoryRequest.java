package com.lgcns.team17.aidd.fzrevc.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate; // Using LocalDate for query_start_date and query_end_date as per spec

@Data
public class ReservationHistoryRequest {
    @NotNull
    private LocalDate queryStartDate;
    @NotNull
    private LocalDate queryEndDate;
    private int skip = 0;
    private int limit = 10;
}