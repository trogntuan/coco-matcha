package com.lgcns.team17.aidd.fzrevc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableScheduling
@EnableTransactionManagement
public class FzRevCApplication {

    public static void main(String[] args) {
        SpringApplication.run(FzRevCApplication.class, args);
    }

}
