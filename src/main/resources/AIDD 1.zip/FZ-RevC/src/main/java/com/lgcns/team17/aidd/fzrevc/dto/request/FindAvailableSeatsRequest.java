package com.lgcns.team17.aidd.fzrevc.dto.request;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class FindAvailableSeatsRequest {
    @NotNull
    @FutureOrPresent // start_time can be now for immediate search
    private LocalDateTime startTime;
    @NotNull
    private LocalDateTime endTime;
    private Long buildingId; // Optional
    private Long floorId;    // Optional
    private int skip = 0;
    private int limit = 10; // Default limit
}