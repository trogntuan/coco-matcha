package com.lgcns.team17.aidd.fzrevc.mapper;

import com.lgcns.team17.aidd.fzrevc.entity.Reservation;
import com.lgcns.team17.aidd.fzrevc.enums.ReservationStatus;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface ReservationMapper {

    void insertReservation(Reservation reservation);

    List<Reservation> findByEmployeeIdAndDateRange(
            @Param("employeeId") Long employeeId,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate,
            @Param("skip") int skip,
            @Param("limit") int limit
    );

    List<Reservation> findConflictingReservations(
            @Param("seatId") Long seatId,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime,
            @Param("excludeId") Long excludeId
    );

    void updateStatus(
            @Param("id") Long id,
            @Param("status") ReservationStatus status
    );

    void updateCheckIn(
            @Param("id") Long id,
            @Param("checkInAt") LocalDateTime checkInAt,
            @Param("status") ReservationStatus status
    );


    List<Reservation> findReservedReservationsForNoShow(@Param("limitMinutes") int limitMinutes);

    List<Reservation> findExpiredInUseReservations(LocalDateTime localDateTime);

    List<Reservation> findReservationChain(@Param("reservationId") Long reservationId);

    void updateReservationChainStatus(
            @Param("reservationIds") List<Long> reservationIds,
            @Param("status") ReservationStatus status
    );

    Reservation findByIdWithDetails(@Param("id") Long id);

    int calculateDailyReservationMinutesForDate(
            @Param("employeeId") Long employeeId,
            @Param("date") LocalDate date // Using LocalDate as per refined logic
    );

    List<Reservation> findReservationsByStatus(@Param("status") ReservationStatus status);

    List<Reservation> findActiveReservationsByEmployeeIdForTodayAndFuture(
            @Param("employeeId") Long employeeId,
            @Param("currentTime") LocalDateTime currentTime
    );

    List<Reservation> findActiveInUseReservationsBySeatAtTime(
            @Param("seatId") Long seatId,
            @Param("currentTime") LocalDateTime currentTime
    );


}