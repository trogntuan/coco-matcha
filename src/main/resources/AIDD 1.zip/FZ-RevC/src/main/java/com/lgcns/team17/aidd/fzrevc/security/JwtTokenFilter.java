package com.lgcns.team17.aidd.fzrevc.security;

import com.lgcns.team17.aidd.fzrevc.dto.response.TokenValidationResponse;
import com.lgcns.team17.aidd.fzrevc.exception.BusinessException;
import com.lgcns.team17.aidd.fzrevc.service.HRService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
@RequiredArgsConstructor
public class JwtTokenFilter extends OncePerRequestFilter {

    private final HRService hrService;

    public static final String ROLE_PREFIX = "ROLE_";
    public static final String ROLE_USER = "USER";
    public static final String ROLE_ADMIN = "ADMIN";

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain filterChain) throws ServletException, IOException {
        try {
            String jwt = extractJwtFromRequest(request);

            if (StringUtils.hasText(jwt) && SecurityContextHolder.getContext().getAuthentication() == null) { // Check if not already authenticated
                String authorizationHeader = "Bearer " + jwt;
                TokenValidationResponse validationResponse = hrService.validateTokenAndGetUserDetails(authorizationHeader);

                if (validationResponse.isValid() && validationResponse.getEmployeeId() != null) {
                    List<GrantedAuthority> authorities = new ArrayList<>();
                    authorities.add(new SimpleGrantedAuthority(ROLE_PREFIX + ROLE_USER));
                    if (validationResponse.isAdmin()) {
                        authorities.add(new SimpleGrantedAuthority(ROLE_PREFIX + ROLE_ADMIN));
                    }

                    String usernameForPrincipal = String.valueOf(validationResponse.getEmployeeId());
                    AuthenticatedUser authenticatedUser = new AuthenticatedUser(
                            validationResponse.getEmployeeId(),
                            usernameForPrincipal,
                            validationResponse.isAdmin(),
                            authorities,
                            jwt
                    );

                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
                            authenticatedUser, null, authenticatedUser.getAuthorities());
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    log.debug("User '{}' authenticated with roles: {}", authenticatedUser.getUsername(), authenticatedUser.getAuthorities());
                } else {
                    log.warn("Token validation by HRService returned invalid for token (first 10 chars): {}", jwt.substring(0, Math.min(jwt.length(), 10)));
                    SecurityContextHolder.clearContext(); // Clear context if validation failed
                }
            }
        } catch (BusinessException e) {
            SecurityContextHolder.clearContext();
            log.warn("Authentication failed due to BusinessException: {}. Request URI: {}", e.getMessage(), request.getRequestURI());
            // Exception will be handled by AuthenticationEntryPoint or AccessDeniedHandler
        } catch (Exception e) {
            SecurityContextHolder.clearContext();
            log.error("Could not set user authentication in security context for URI: {}", request.getRequestURI(), e);
        }
        filterChain.doFilter(request, response);
    }

    private String extractJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}