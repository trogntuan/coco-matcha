package com.lgcns.team17.aidd.fzrevc.mapper;

import com.lgcns.team17.aidd.fzrevc.entity.Building;
import com.lgcns.team17.aidd.fzrevc.entity.Floor;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface BuildingMapper {

    List<Building> findAllBuildings();

    List<Floor> findFloorsByBuildingId(@Param("buildingId") Long buildingId);
}
