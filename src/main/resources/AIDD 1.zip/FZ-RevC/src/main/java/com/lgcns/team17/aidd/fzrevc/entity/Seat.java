package com.lgcns.team17.aidd.fzrevc.entity;
import com.lgcns.team17.aidd.fzrevc.enums.SeatStatus;
import lombok.Data;

@Data
public class Seat {
    private Long id;
    private String seatNumber;
    private Long floorId;
    private SeatStatus status;
    private String description;

    // Joined fields
    private Floor floor;
    private Building building;
}