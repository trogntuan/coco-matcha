package com.lgcns.team17.aidd.fzrevc.service;

import com.lgcns.team17.aidd.fzrevc.entity.Reservation;
import com.lgcns.team17.aidd.fzrevc.entity.Seat;
import com.lgcns.team17.aidd.fzrevc.enums.ReservationStatus;
import com.lgcns.team17.aidd.fzrevc.enums.SeatStatus;
import com.lgcns.team17.aidd.fzrevc.mapper.ReservationMapper;
import com.lgcns.team17.aidd.fzrevc.mapper.SeatMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class BatchService {

    private final ReservationMapper reservationMapper;
    private final SeatMapper seatMapper;
    private final int noShowLimitMinutes;
    // seatAcceptDurationSeconds seems unused for updatePendingToReserved based on logic description
    // private final int seatAcceptDurationSeconds;

    public BatchService(ReservationMapper reservationMapper, SeatMapper seatMapper,
                        @Value("${batch.updateReservedToNoShow.noShowLimitMinutes}") int noShowLimitMinutes
            /* @Value("${batch.updatePendingToReserved.seatAcceptDurationSeconds}") int seatAcceptDurationSeconds */) {
        this.reservationMapper = reservationMapper;
        this.seatMapper = seatMapper;
        this.noShowLimitMinutes = noShowLimitMinutes;
        // this.seatAcceptDurationSeconds = seatAcceptDurationSeconds;
    }

    // Helper method to process each pending reservation in its own transaction
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void processSinglePendingReservation(Reservation pr) {
        log.debug("Processing PENDING reservation ID: {} in new transaction.", pr.getId());
        try {
            // Re-validate conditions at the time of batch execution
            Seat seat = seatMapper.findById(pr.getSeatId());
            if (seat == null) {
                log.warn("PENDING reservation {} invalid: Seat {} does not exist. Setting to FAIL.", pr.getId(), pr.getSeatId());
                reservationMapper.updateStatus(pr.getId(), ReservationStatus.FAIL);
                return;
            }
            if (seat.getStatus() == SeatStatus.BROKEN) {
                log.warn("PENDING reservation {} invalid: Seat {} is BROKEN. Setting to FAIL.", pr.getId(), pr.getSeatId());
                reservationMapper.updateStatus(pr.getId(), ReservationStatus.FAIL);
                return;
            }

            // Kiểm tra xem trong khoảng [start_time, end_time] yêu cầu, ghế này có bị trùng
            // với bất kỳ đặt chỗ nào khác đang ở trạng thái RESERVED hoặc IN_USE không.
            List<Reservation> conflicts = reservationMapper.findConflictingReservations(
                    pr.getSeatId(), pr.getStartTime(), pr.getEndTime(), pr.getId() // Exclude self for re-validation
            );

            if (!conflicts.isEmpty()) {
                log.warn("PENDING reservation {} invalid: Conflicts found with other RESERVED/IN_USE reservations. Setting to FAIL.", pr.getId());
                reservationMapper.updateStatus(pr.getId(), ReservationStatus.FAIL);
                return;
            }

            // If all checks pass, move to RESERVED
            reservationMapper.updateStatus(pr.getId(), ReservationStatus.RESERVED);
            log.info("PENDING reservation {} successfully moved to RESERVED.", pr.getId());

        } catch (Exception e) {
            log.error("Error processing PENDING reservation {} in its transaction: {}. Setting to FAIL.", pr.getId(), e.getMessage(), e);
            // Attempt to set to FAIL even if other DB operations failed.
            try {
                reservationMapper.updateStatus(pr.getId(), ReservationStatus.FAIL);
            } catch (Exception ex) {
                log.error("CRITICAL: Failed to even set reservation {} to FAIL after an error during processing: {}", pr.getId(), ex.getMessage(), ex);
            }
        }
    }


    @Scheduled(cron = "${batch.updatePendingToReserved.cron}")
    // This outer method does not need @Transactional itself if processSinglePendingReservation handles it.
    public void updatePendingToReserved() {
        log.info("Batch job: updatePendingToReserved - STARTED");
        List<Reservation> pendingReservations = reservationMapper.findReservationsByStatus(ReservationStatus.PENDING);
        log.info("Found {} PENDING reservations to process.", pendingReservations.size());

        for (Reservation pr : pendingReservations) {
            // Calling a self-invoked method with @Transactional(propagation = Propagation.REQUIRES_NEW)
            // requires it to be in a different bean or use AspectJ weaving.
            // For simplicity here, direct call implies it runs in the same transaction if this method had one,
            // or no transaction if this method doesn't.
            // To ensure REQUIRES_NEW, inject ApplicationContext and get BatchService bean to call processSinglePendingReservation,
            // or move processSinglePendingReservation to another @Service bean.
            // Let's assume for now that if one fails, others can proceed.
            // The current structure will make processSinglePendingReservation run in the SAME transaction context
            // if updatePendingToReserved had @Transactional.
            // If updatePendingToReserved does NOT have @Transactional, then processSinglePendingReservation will correctly start a new one.
            processSinglePendingReservation(pr);
        }
        log.info("Batch job: updatePendingToReserved - COMPLETED.");
    }

    @Scheduled(cron = "${batch.updateReservedToNoShow.cron}")
    @Transactional // This job can run as a single transaction
    public void updateReservedToNoShow() {
        log.info("Batch job: updateReservedToNoShow - STARTED. noShowLimitMinutes: {}", noShowLimitMinutes);
        LocalDateTime noShowDeadline = LocalDateTime.now().minusMinutes(noShowLimitMinutes);

        // Fetches RESERVED reservations where start_time has passed beyond the noShowLimit (start_time < noShowDeadline)
        // and check_in_at is NULL.
        List<Reservation> candidates = reservationMapper.findReservationsForNoShowUpdate(noShowDeadline);
        log.info("Found {} RESERVED reservations as candidates for NO_SHOW.", candidates.size());

        for (Reservation r : candidates) {
            // Double check condition, though query should be precise.
            if (r.getCheckInAt() == null && r.getStatus() == ReservationStatus.RESERVED && r.getStartTime().isBefore(noShowDeadline)) {
                reservationMapper.updateStatus(r.getId(), ReservationStatus.NO_SHOW);
                log.info("RESERVED reservation {} (StartTime: {}) moved to NO_SHOW.", r.getId(), r.getStartTime());
            } else {
                log.debug("Skipping reservation {} for NO_SHOW update. CheckInAt: {}, Status: {}, StartTime: {}",
                        r.getId(), r.getCheckInAt(), r.getStatus(), r.getStartTime());
            }
        }
        log.info("Batch job: updateReservedToNoShow - COMPLETED.");
    }

    @Scheduled(cron = "${batch.updateInUseToCompleted.cron}")
    @Transactional // This job can run as a single transaction
    public void updateInUseToCompleted() {
        log.info("Batch job: updateInUseToCompleted - STARTED");
        LocalDateTime now = LocalDateTime.now();
        // Fetches IN_USE reservations where end_time has passed (end_time < now)
        List<Reservation> expiredReservations = reservationMapper.findExpiredInUseReservations(now);
        log.info("Found {} IN_USE reservations as candidates for COMPLETION.", expiredReservations.size());

        for (Reservation r : expiredReservations) {
            // Double check condition
            if (r.getStatus() == ReservationStatus.IN_USE && r.getEndTime().isBefore(now)) {
                reservationMapper.updateStatus(r.getId(), ReservationStatus.COMPLETED);
                // Also free up the seat
                // Important: Only set to AVAILABLE if no other current or future reservation makes it UNAVAILABLE.
                // The spec implies a direct change. Let's check if any other IN_USE or RESERVED exists for this seat now.
                // For simplicity as per spec: "Cập nhật ... SEAT.status = 'AVAILABLE'"
                // A more robust check would be:
                // List<Reservation> otherActiveOrFutureReservations = reservationMapper.findConflictingReservations(r.getSeatId(), now, now.plusYears(1), r.getId());
                // if (otherActiveOrFutureReservations.isEmpty()) {
                //    seatMapper.updateStatus(r.getSeatId(), SeatStatus.AVAILABLE);
                // } else {
                //    log.info("Seat {} not set to AVAILABLE as other reservations exist.", r.getSeatId());
                // }
                seatMapper.updateStatus(r.getSeatId(), SeatStatus.AVAILABLE);
                log.info("IN_USE reservation {} (EndTime: {}) moved to COMPLETED. Seat {} set to AVAILABLE.", r.getId(), r.getEndTime(), r.getSeatId());
            } else {
                log.debug("Skipping reservation {} for COMPLETION update. Status: {}, EndTime: {}",
                        r.getId(), r.getStatus(), r.getEndTime());
            }
        }
        log.info("Batch job: updateInUseToCompleted - COMPLETED.");
    }
}