package com.lgcns.team17.aidd.fzrevc.mapper;

import com.lgcns.team17.aidd.fzrevc.entity.Seat;
import com.lgcns.team17.aidd.fzrevc.enums.SeatStatus;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface SeatMapper {

    List<Seat> findAvailableSeats(
            @Param("buildingId") Long buildingId,
            @Param("floorId") Long floorId,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime,
            @Param("skip") int skip,
            @Param("limit") int limit
    );

    List<Seat> findSeatsByBuildingAndFloor(
            @Param("buildingId") Long buildingId,
            @Param("floorId") Long floorId
    );

    Seat findById(@Param("id") Long id);

    void updateStatus(
            @Param("id") Long id,
            @Param("status") SeatStatus status
    );

    List<Seat> findSeatsByBuildingAndFloorWithDetails(
            @Param("buildingId") Long buildingId,
            @Param("floorId") Long floorId
    );
}
