package com.lgcns.team17.aidd.fzrevc.dto.response;

import com.lgcns.team17.aidd.fzrevc.enums.SeatStatus;
import lombok.Data;

@Data
public class SeatResponse {
    private Long id;
    private String seatNumber;
    private Long floorId;
    private String floorName;
    private Long buildingId;
    private String buildingName;
    private SeatStatus status;
    private String description;
}
