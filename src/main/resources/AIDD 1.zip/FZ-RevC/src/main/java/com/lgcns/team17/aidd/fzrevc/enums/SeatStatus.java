package com.lgcns.team17.aidd.fzrevc.enums;

public enum SeatStatus {
    AVAILABLE, UNAVAILABLE, BROKEN
}