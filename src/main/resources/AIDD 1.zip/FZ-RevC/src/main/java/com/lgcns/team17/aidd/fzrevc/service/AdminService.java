package com.lgcns.team17.aidd.fzrevc.service;
import com.lgcns.team17.aidd.fzrevc.dto.response.SeatResponse;
import com.lgcns.team17.aidd.fzrevc.entity.Reservation;
import com.lgcns.team17.aidd.fzrevc.entity.Seat;
import com.lgcns.team17.aidd.fzrevc.enums.ReservationStatus;
import com.lgcns.team17.aidd.fzrevc.enums.SeatStatus;
import com.lgcns.team17.aidd.fzrevc.exception.BusinessException;
import com.lgcns.team17.aidd.fzrevc.mapper.ReservationMapper;
import com.lgcns.team17.aidd.fzrevc.mapper.SeatMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
@Service
@RequiredArgsConstructor
@Slf4j
public class AdminService {

    private final ReservationMapper reservationMapper;
    private final SeatMapper seatMapper;
    private final SeatService seatService; // For reusing mapToSeatResponse

    @Transactional
    public void forceCheckoutSeat(Long seatId, Long adminId /* Thêm adminId để log, không dùng cho logic chính */) {
        log.info("Admin action by adminId {}: Forcing checkout for seat ID: {}", adminId, seatId);

        Seat seat = seatMapper.findById(seatId);
        if (seat == null) {
            log.warn("Force checkout failed: Seat with ID {} not found.", seatId);
            throw new BusinessException("RE001", "Seat not found."); // RE001: Dữ liệu vào không hợp lệ
        }

        // Find IN_USE reservations for this seat whose current time falls within [start_time, end_time]
        List<Reservation> activeReservationsOnSeat = reservationMapper.findActiveInUseReservationsBySeatAtTime(seatId, LocalDateTime.now());

        if (activeReservationsOnSeat.isEmpty()) {
            log.info("No active IN_USE reservation found for seat {} at current time. Ensuring seat is AVAILABLE if it was stuck.", seatId);
            if (seat.getStatus() == SeatStatus.UNAVAILABLE) {
                seatMapper.updateStatus(seatId, SeatStatus.AVAILABLE);
                log.info("Seat {} was UNAVAILABLE, set to AVAILABLE.", seatId);
            }
            // According to spec, if no IN_USE, this action might not be strictly necessary,
            // but setting seat to AVAILABLE is a safe side effect.
            return;
        }

        List<Long> allChainIdsToForceCancel = new ArrayList<>();
        for (Reservation activeReservation : activeReservationsOnSeat) {
            log.info("Processing active reservation ID {} (status: {}) on seat {} for forced checkout.",
                    activeReservation.getId(), activeReservation.getStatus(), seatId);

            // "Nếu đặt chỗ này thuộc một chuỗi gia hạn, xác định tất cả các đặt chỗ IN_USE hoặc RESERVED (các phần tương lai của chuỗi) trong chuỗi đó."
            List<Reservation> chain = reservationMapper.findReservationChain(activeReservation.getId());
            List<Long> currentChainIds = chain.stream()
                    .filter(r -> r.getStatus() == ReservationStatus.IN_USE ||
                            (r.getStatus() == ReservationStatus.RESERVED && r.getStartTime().isAfter(activeReservation.getStartTime()))) // future RESERVED parts
                    .map(Reservation::getId)
                    .collect(Collectors.toList());

            if (!currentChainIds.contains(activeReservation.getId()) && activeReservation.getStatus() == ReservationStatus.IN_USE) {
                // Ensure the current active reservation is part of the list if it's IN_USE
                currentChainIds.add(activeReservation.getId());
            }
            allChainIdsToForceCancel.addAll(currentChainIds);
        }

        List<Long> distinctChainIds = allChainIdsToForceCancel.stream().distinct().collect(Collectors.toList());

        if (!distinctChainIds.isEmpty()) {
            reservationMapper.updateReservationChainStatus(distinctChainIds, ReservationStatus.FORCED_CANCEL);
            log.info("FORCED_CANCEL status set for reservation chain IDs: {}", distinctChainIds);
        }

        // "Cập nhật seat.status = 'AVAILABLE'"
        seatMapper.updateStatus(seatId, SeatStatus.AVAILABLE);
        log.info("Seat {} status set to AVAILABLE after admin forced checkout.", seatId);
        // "Lưu ý: Điều này có thể gây xung đột nếu có các đặt chỗ RESERVED *khác* ... Tài liệu không làm rõ"
        // Current implementation follows the spec: only the IN_USE chain is FORCED_CANCELLED. Other future RESERVED bookings by other users remain.
    }

    // A0102. Truy xuất Trạng thái Chi tiết Ghế
    public List<SeatResponse> getDetailedSeatStatus(Long buildingId, Long floorId) {
        log.debug("Admin action: Fetching detailed seat status for building {} and floor {}", buildingId, floorId);
        // The spec says "trả về đầy đủ thông tin ghế bao gồm status chi tiết (`AVAILABLE`, `UNAVAILABLE`, `BROKEN`)."
        // The existing seatMapper.findSeatsByBuildingAndFloorWithDetails should provide this.
        // Mapping to SeatResponse is handled in the controller or here.
        List<Seat> seats = seatMapper.findSeatsByBuildingAndFloorWithDetails(buildingId, floorId);
        return seats.stream()
                .map(seatService::mapToSeatResponse) // Reusing SeatService's mapping logic
                .collect(Collectors.toList());
    }
}