package com.lgcns.team17.aidd.fzrevc.controller;

import com.lgcns.team17.aidd.fzrevc.dto.request.CreateReservationRequest;
import com.lgcns.team17.aidd.fzrevc.dto.request.ReservationHistoryRequest;
import com.lgcns.team17.aidd.fzrevc.dto.response.ApiResponse;
import com.lgcns.team17.aidd.fzrevc.dto.response.ReservationResponse;
import com.lgcns.team17.aidd.fzrevc.security.AuthenticatedUser;
import com.lgcns.team17.aidd.fzrevc.service.HRService;
import com.lgcns.team17.aidd.fzrevc.service.ReservationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reservations")
@RequiredArgsConstructor
public class ReservationController {

    private final ReservationService reservationService;
    private final HRService hrService;

    // U0102. Đăng ký Đặt chỗ
    @PostMapping // U0102
    public ResponseEntity<ApiResponse<ReservationResponse>> createReservation(
            @AuthenticationPrincipal AuthenticatedUser currentUser, // Lấy user từ security context
            @Valid @RequestBody CreateReservationRequest request) {
        // Service sẽ nhận currentUser.getId()
        ReservationResponse response = reservationService.createReservation(request, currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("RS001", "Reservation created successfully (PENDING).", response));
    }

    // U0103. Hủy Đặt chỗ
    @PutMapping("/{reservationId}/cancel") // U0103
    public ResponseEntity<ApiResponse<Void>> cancelReservation(
            @AuthenticationPrincipal AuthenticatedUser currentUser,
            @PathVariable Long reservationId) {
        reservationService.cancelReservation(currentUser.getId(), reservationId);
        return ResponseEntity.ok(ApiResponse.success("RS002", "Reservation cancelled successfully.", null));
    }

    // U0104. Gia hạn Thời gian Đặt chỗ
    @PostMapping("/{reservationId}/extend") // U0104
    public ResponseEntity<ApiResponse<ReservationResponse>> extendReservation(
            @AuthenticationPrincipal AuthenticatedUser currentUser,
            @PathVariable Long reservationId) {
        ReservationResponse extendedReservation = reservationService.extendReservation(currentUser.getId(), reservationId);
        return ResponseEntity.ok(ApiResponse.success("RS003", "Reservation extended successfully.", extendedReservation));
    }

    // U0105. Truy xuất Lịch sử Đặt chỗ
    @GetMapping("/history") // U0105
    public ResponseEntity<ApiResponse<List<ReservationResponse>>> getReservationHistory(
            @AuthenticationPrincipal AuthenticatedUser currentUser,
            @Valid @ModelAttribute ReservationHistoryRequest requestParams) {
        List<ReservationResponse> history = reservationService.getReservationHistory(
                currentUser.getId(),
                requestParams.getQueryStartDate(),
                requestParams.getQueryEndDate(),
                requestParams.getSkip(),
                requestParams.getLimit()
        );
        return ResponseEntity.ok(ApiResponse.success("RS004", "Reservation history retrieved.", history));
    }

    // U0106. Truy xuất Trạng thái Đặt chỗ của tôi (current/active)
    @GetMapping("/me/current") // U0106
    public ResponseEntity<ApiResponse<List<ReservationResponse>>> getMyCurrentReservations(
            @AuthenticationPrincipal AuthenticatedUser currentUser) {
        List<ReservationResponse> currentReservations = reservationService.getMyCurrentReservations(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("RS005", "Current reservations retrieved.", currentReservations));
    }

    // U0202. Check-in (Moved from SeatController to ReservationController as it acts on a reservation)
    @PostMapping("/{reservationId}/check-in") // U0202
    public ResponseEntity<ApiResponse<Void>> checkIn(
            @AuthenticationPrincipal AuthenticatedUser currentUser,
            @PathVariable Long reservationId) {
        reservationService.checkIn(currentUser.getId(), reservationId);
        return ResponseEntity.ok(ApiResponse.success("RS006", "Check-in successful.", null));
    }

    // U0205. Trả Ghế (Check-out)
    @PutMapping("/{reservationId}/check-out") // U0205
    public ResponseEntity<ApiResponse<Void>> checkOut(
            @AuthenticationPrincipal AuthenticatedUser currentUser,
            @PathVariable Long reservationId) {
        reservationService.checkOut(currentUser.getId(), reservationId);
        return ResponseEntity.ok(ApiResponse.success("RS007", "Check-out successful. Seat is now available.", null));
    }
}