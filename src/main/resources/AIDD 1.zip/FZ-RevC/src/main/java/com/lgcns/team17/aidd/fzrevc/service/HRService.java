package com.lgcns.team17.aidd.fzrevc.service;
import com.lgcns.team17.aidd.fzrevc.dto.request.TokenValidationRequest;
import com.lgcns.team17.aidd.fzrevc.dto.response.TokenValidationResponse;
import com.lgcns.team17.aidd.fzrevc.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier; // Để inject đúng WebClient bean
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono; // Sử dụng Reactor Mono

import java.time.Duration;

@Service
@Slf4j
public class HRService {

    private final WebClient hrWebClient; // Inject WebClient đã được cấu hình
    private final String validateTokenPath;

    public HRService(@Qualifier("hrWebClient") WebClient hrWebClient, // Sử dụng Qualifier
                     @Value("${hr.service.validate-token-path}") String validateTokenPath) {
        this.hrWebClient = hrWebClient;
        this.validateTokenPath = validateTokenPath;
    }

    public TokenValidationResponse validateTokenAndGetUserDetails(String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            log.warn("Invalid or missing Authorization header format.");
            throw new BusinessException("AUTH001", "Unauthorized: Invalid or missing token format.");
        }

        TokenValidationRequest requestPayload = new TokenValidationRequest(authorizationHeader);
        String tokenPreview = requestPayload.getAuthorization().substring(0, Math.min(requestPayload.getAuthorization().length(), 15)) + "...";
        log.debug("Validating token with HR Service via WebClient. Path: {}, Token Preview: {}", validateTokenPath, tokenPreview);

        try {
            Mono<TokenValidationResponse> responseMono = hrWebClient.post()
                    .uri(validateTokenPath)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(requestPayload))
                    .retrieve()
                    .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), clientResponse ->
                            clientResponse.bodyToMono(String.class)
                                    .switchIfEmpty(Mono.just("No error body available"))
                                    .flatMap(errorBody -> handleHrServiceError(clientResponse, errorBody)) // Gọi phương thức helper
                    )
                    .bodyToMono(TokenValidationResponse.class)
                    .doOnError(error -> log.error("Error during WebClient call to HRMS validate API: {}", error.getMessage(), error));

            TokenValidationResponse validationResponse = responseMono.block(Duration.ofSeconds(10)); // Ví dụ timeout 10 giây

            if (validationResponse == null || !validationResponse.isValid()) {
                String detailMessage = (validationResponse != null && validationResponse.getMessage() != null)
                        ? validationResponse.getMessage()
                        : "Token validation failed or invalid response from HR service.";
                log.warn("Token validation failed. HR Service Message: {}", detailMessage);
                throw new BusinessException("AUTH002", "Unauthorized: " + detailMessage);
            }

            log.info("Token validated successfully via WebClient for employeeId: {}, isAdmin: {}",
                    validationResponse.getEmployeeId(), validationResponse.isAdmin());
            return validationResponse;

        } catch (
                IllegalStateException e) { // Thường xảy ra khi .block() không nhận được giá trị (ví dụ: do lỗi trước đó)
            log.error("WebClient .block() failed, possibly due to prior error in reactive chain for HR service validation.", e);
            throw new BusinessException("SE", "System error processing response from authentication service.");
        } catch (RuntimeException e) { // Bắt các lỗi runtime khác từ WebClient hoặc .block()
            if (e.getCause() instanceof BusinessException) { // Nếu lỗi đã được map thành BusinessException
                throw (BusinessException) e.getCause();
            }
            log.error("RuntimeException during WebClient call to HR service for token validation", e);
            throw new BusinessException("SE", "System error communicating with authentication service.");
        }
    }

    private Mono<? extends Throwable> handleHrServiceError(ClientResponse clientResponse, String errorBody) {
        log.error("Error from HR service: Status {}, Body: {}", clientResponse.statusCode(), errorBody);
        BusinessException cause;
        if (clientResponse.statusCode().is4xxClientError()) {
            cause = new BusinessException("AUTH003", "Unauthorized: HR service rejected token (HTTP " + clientResponse.statusCode().value() + "). Details: " + errorBody);
        } else { // 5xx errors
            cause = new BusinessException("SE_HR", "HR service error (HTTP " + clientResponse.statusCode().value() + "). Details: " + errorBody);
        }
        return Mono.error(cause);
    }
}