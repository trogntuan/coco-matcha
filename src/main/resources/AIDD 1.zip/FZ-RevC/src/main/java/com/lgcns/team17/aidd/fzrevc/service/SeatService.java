package com.lgcns.team17.aidd.fzrevc.service;

import com.lgcns.team17.aidd.fzrevc.dto.response.SeatResponse;
import com.lgcns.team17.aidd.fzrevc.entity.Building;
import com.lgcns.team17.aidd.fzrevc.entity.Floor;
import com.lgcns.team17.aidd.fzrevc.entity.Seat;
import com.lgcns.team17.aidd.fzrevc.exception.BusinessException;
import com.lgcns.team17.aidd.fzrevc.mapper.BuildingMapper;
import com.lgcns.team17.aidd.fzrevc.mapper.SeatMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class SeatService {

    private final SeatMapper seatMapper;
    private final BuildingMapper buildingMapper;

    public List<Building> getAllBuildings() {
        return buildingMapper.findAllBuildings();
    }

    public List<SeatResponse> findAvailableSeats(
            Long buildingId, Long floorId, LocalDateTime startTime, LocalDateTime endTime, int skip, int limit) {
        log.info("Finding available seats. Building: {}, Floor: {}, Time: {} - {}, Page: {}/{}",
                buildingId, floorId, startTime, endTime, skip, limit);

        // "start_time phải là một thời điểm trong tương lai (không sớm hơn thời gian hiện tại)."
        // For finding seats, allowing start_time to be current time is reasonable.
        if (startTime.isBefore(LocalDateTime.now().minusMinutes(1))) { // Allow a minute for clock skew / request time
            // Re-evaluate this if strict "future only" is needed for search too.
             throw new BusinessException("RE001", "Search start time must be current or in the future.");
        }
        if (endTime.isBefore(startTime) || endTime.isEqual(startTime)) {
            throw new BusinessException("RE001", "Search end time must be after start time.");
        }

        List<Seat> seats = seatMapper.findAvailableSeats(buildingId, floorId, startTime, endTime, skip, limit);
        return seats.stream()
                .map(this::mapToSeatResponse) // Use the existing mapper
                .collect(Collectors.toList());
    }

    // U0201. Truy xuất Trạng thái Ghế (for employee view)
    public List<SeatResponse> getSeatStatus(Long buildingId, Long floorId) {
        log.info("Getting seat status for employee view. Building: {}, Floor: {}", buildingId, floorId);
        // "trả về trạng thái đơn giản cho nhân viên (ví dụ: "Có sẵn" nếu seat.status = 'AVAILABLE'`,
        // "Không có sẵn" nếu seat.status = 'UNAVAILABLE'` hoặc `BROKEN`)."
        // The current SeatResponse returns detailed status. UI can map this.
        // If backend needs to simplify, then logic here or a different DTO.
        List<Seat> seats = seatMapper.findSeatsByBuildingAndFloorWithDetails(buildingId, floorId); // Get all details
        return seats.stream()
                .map(this::mapToSeatResponse)
                .collect(Collectors.toList());
    }

    // U0204. Truy xuất Tầng
    public List<Floor> getFloorsByBuildingId(Long buildingId) {
        log.info("Fetching floors for buildingId: {}", buildingId);
        // Ensure building exists or handle gracefully if needed
        // Building building = buildingMapper.findById(buildingId);
        // if (building == null) throw new BusinessException("RE001", "Building not found.");
        return buildingMapper.findFloorsByBuildingId(buildingId);
    }

    // Helper to map Seat entity to SeatResponse DTO
    // Ensure this is comprehensive based on SeatResponse DTO and available joins
    public SeatResponse mapToSeatResponse(Seat seat) {
        SeatResponse response = new SeatResponse();
        response.setId(seat.getId());
        response.setSeatNumber(seat.getSeatNumber());
        response.setStatus(seat.getStatus());
        response.setDescription(seat.getDescription());

        if (seat.getFloor() != null) {
            response.setFloorId(seat.getFloor().getId());
            response.setFloorName(seat.getFloor().getName());
            if (seat.getFloor().getBuildingId() != null && seat.getBuilding() != null) { // Assuming building is joined
                response.setBuildingId(seat.getBuilding().getId());
                response.setBuildingName(seat.getBuilding().getName());
            } else if (seat.getBuilding() != null) { // Fallback if floor.buildingId is null but seat.building is present
                response.setBuildingId(seat.getBuilding().getId());
                response.setBuildingName(seat.getBuilding().getName());
            }
        } else if (seat.getBuilding() != null) { // Case where floor might be null but building info is directly on seat (less likely for normalized schema)
            response.setBuildingId(seat.getBuilding().getId());
            response.setBuildingName(seat.getBuilding().getName());
        }
        return response;
    }
}