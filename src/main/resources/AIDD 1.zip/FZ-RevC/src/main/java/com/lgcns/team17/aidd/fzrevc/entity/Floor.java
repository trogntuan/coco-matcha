package com.lgcns.team17.aidd.fzrevc.entity;

import lombok.Data;

@Data
public class Floor {
    private Long id;
    private Long buildingId;
    private Integer floorNumber;
    private String name;
    private String description;
}