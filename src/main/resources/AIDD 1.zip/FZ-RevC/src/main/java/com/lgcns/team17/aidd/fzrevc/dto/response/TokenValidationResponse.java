package com.lgcns.team17.aidd.fzrevc.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenValidationResponse {
    @JsonProperty("is_valid")
    private boolean isValid;
    @JsonProperty("employee_id")
    private Long employeeId;
    @JsonProperty("is_admin")
    private boolean isAdmin;
    private String message;
}