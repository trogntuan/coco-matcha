package com.lgcns.team17.aidd.fzrevc.service;

import com.lgcns.team17.aidd.fzrevc.dto.request.CreateReservationRequest;
import com.lgcns.team17.aidd.fzrevc.dto.response.ReservationResponse;
import com.lgcns.team17.aidd.fzrevc.entity.Reservation;
import com.lgcns.team17.aidd.fzrevc.entity.Seat;
import com.lgcns.team17.aidd.fzrevc.enums.ReservationStatus;
import com.lgcns.team17.aidd.fzrevc.enums.SeatStatus;
import com.lgcns.team17.aidd.fzrevc.exception.BusinessException;
import com.lgcns.team17.aidd.fzrevc.mapper.ReservationMapper;
import com.lgcns.team17.aidd.fzrevc.mapper.SeatMapper;
import com.lgcns.team17.aidd.fzrevc.util.DateTimeUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReservationService {

    private final ReservationMapper reservationMapper;
    private final SeatMapper seatMapper;

    private static final int MAX_DAILY_HOURS = 8;
    private static final int EXTENSION_MINUTES = 60;


    // U0102. Đăng ký Đặt chỗ
    @Transactional
    public ReservationResponse createReservation(CreateReservationRequest request, Long requestingEmployeeId) {
        // Ensure user is creating for themselves (already handled in controller, but good for service layer integrity)
        if (!request.getEmployeeId().equals(requestingEmployeeId)) {
            log.warn("Security alert: Employee {} attempting to create reservation for employee {}.", requestingEmployeeId, request.getEmployeeId());
            throw new BusinessException("RE003", "Not authorized to create reservation for another employee.");
        }

        log.info("Processing createReservation request for employeeId: {}, seatId: {}, start: {}, end: {}",
                request.getEmployeeId(), request.getSeatId(), request.getStartTime(), request.getEndTime());

        validateReservationRequestTimes(request.getStartTime(), request.getEndTime()); // Centralized time validation

        // 3. Check seat exists and not broken
        Seat seat = seatMapper.findById(request.getSeatId());
        if (seat == null) {
            throw new BusinessException("RE001", "Seat with ID " + request.getSeatId() + " not found.");
        }
        if (seat.getStatus() == SeatStatus.BROKEN) {
            throw new BusinessException("RE001", "Seat " + request.getSeatId() + " is BROKEN and cannot be reserved.");
        }

        // 4. Check for conflicts
        List<Reservation> conflicts = reservationMapper.findConflictingReservations(
                request.getSeatId(), request.getStartTime(), request.getEndTime(), null); // null for excludeId
        if (!conflicts.isEmpty()) {
            log.warn("Conflict detected for seat {} between {} and {}", request.getSeatId(), request.getStartTime(), request.getEndTime());
            throw new BusinessException("RE002", "Seat is already reserved or in use for the requested time period.");
        }

        // 5. Check daily limit
        // "Tổng thời gian (của các đặt chỗ PENDING, RESERVED, IN_USE`) không được vượt quá 8 giờ."
        // This calculation should be for the day of the reservation's start_time.
        int currentDailyMinutes = reservationMapper.calculateDailyReservationMinutesForDate(
                request.getEmployeeId(), request.getStartTime().toLocalDate()); // Query sums PENDING, RESERVED, IN_USE for that day
        long requestMinutes = java.time.Duration.between(request.getStartTime(), request.getEndTime()).toMinutes();

        if (currentDailyMinutes + requestMinutes > MAX_DAILY_HOURS * 60) {
            log.warn("Employee {} exceeds daily limit. Current: {} mins, Request: {} mins.",
                    request.getEmployeeId(), currentDailyMinutes, requestMinutes);
            throw new BusinessException("RE004", "Exceeds maximum " + MAX_DAILY_HOURS + " hours daily reservation limit.");
        }

        // 6. Create reservation
        Reservation reservation = new Reservation();
        reservation.setEmployeeId(request.getEmployeeId());
        reservation.setSeatId(request.getSeatId());
        reservation.setStartTime(request.getStartTime());
        reservation.setEndTime(request.getEndTime());
        reservation.setStatus(ReservationStatus.PENDING); // Initial status
        reservation.setCreatedAt(LocalDateTime.now());
        // check_in_at and extended_from_reservation_id are NULL initially

        reservationMapper.insertReservation(reservation);
        log.info("Reservation created successfully with ID: {}. Status: PENDING.", reservation.getId());

        // Fetch the newly created reservation with joined details for the response
        Reservation createdReservation = reservationMapper.findByIdWithDetails(reservation.getId());
        return mapToReservationResponse(createdReservation);
    }

    private void validateReservationRequestTimes(LocalDateTime startTime, LocalDateTime endTime) {
        if (startTime.isBefore(LocalDateTime.now())) {
            // "start_time phải là một thời điểm trong tương lai (không sớm hơn thời gian hiện tại)."
            // Allowing a small grace period (e.g., few seconds) might be practical, but spec is strict.
            throw new BusinessException("RE001", "Start time must be in the future or present.");
        }
        if (endTime.isBefore(startTime) || endTime.isEqual(startTime)) {
            throw new BusinessException("RE001", "End time must be after start time.");
        }
        // Spec doesn't explicitly forbid multi-day reservations, but "Tính tổng thời gian đặt chỗ ... trong ngày"
        // and "Gia hạn không quá nửa đêm" imply single-day context. Let's enforce it.
        if (!DateTimeUtil.isSameDay(startTime, endTime.minusNanos(1))) { // .minusNanos(1) to correctly handle midnight as end
            throw new BusinessException("RE001", "Reservation cannot span multiple days. Must start and end on the same calendar day.");
        }
    }


    // U0103. Hủy Đặt chỗ
    @Transactional
    public void cancelReservation(Long employeeId, Long reservationId) {
        log.info("Processing cancelReservation for employeeId: {}, reservationId: {}", employeeId, reservationId);
        Reservation reservation = reservationMapper.findById(reservationId);
        if (reservation == null) {
            throw new BusinessException("RE001", "Reservation not found.");
        }
        if (!reservation.getEmployeeId().equals(employeeId)) {
            throw new BusinessException("RE003", "Not authorized to cancel this reservation. Belongs to another employee.");
        }
        if (reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new BusinessException("RE003", "Action not allowed: Can only cancel reservations with RESERVED status. Current status: " + reservation.getStatus());
        }
        reservationMapper.updateStatus(reservationId, ReservationStatus.CANCELLED);
        log.info("Reservation {} cancelled successfully for employee {}", reservationId, employeeId);
    }

    // U0104. Gia hạn Thời gian Đặt chỗ
    @Transactional
    public ReservationResponse extendReservation(Long employeeId, Long originalReservationId) {
        log.info("Processing extendReservation for employeeId: {}, originalReservationId: {}", employeeId, originalReservationId);
        Reservation originalReservation = reservationMapper.findByIdWithDetails(originalReservationId); // Fetch with details
        if (originalReservation == null) {
            throw new BusinessException("RE001", "Original reservation (ID: " + originalReservationId + ") not found for extension.");
        }
        if (!originalReservation.getEmployeeId().equals(employeeId)) {
            throw new BusinessException("RE003", "Not authorized to extend this reservation. Belongs to another employee.");
        }
        if (originalReservation.getStatus() != ReservationStatus.IN_USE) {
            throw new BusinessException("RE003", "Action not allowed: Can only extend reservations with IN_USE status. Current status: " + originalReservation.getStatus());
        }

        Seat seat = seatMapper.findById(originalReservation.getSeatId());
        if (seat == null || seat.getStatus() != SeatStatus.UNAVAILABLE) {
            // If reservation is IN_USE, seat should be UNAVAILABLE.
            log.error("Data integrity issue: Reservation {} is IN_USE, but seat {} status is {} (expected UNAVAILABLE).",
                    originalReservation.getId(), seat != null ? seat.getId() : "null", seat != null ? seat.getStatus() : "null");
            throw new BusinessException("RE003", "Cannot extend: Seat status is not consistent with an IN_USE reservation.");
        }

        LocalDateTime newStartTime = originalReservation.getEndTime();
        LocalDateTime newEndTime = newStartTime.plusMinutes(EXTENSION_MINUTES); // Gia hạn cố định 1 giờ

        // "Kiểm tra new_end_time phải trước 00:00 ngày hôm sau." (relative to new_start_time's day)
        if (!DateTimeUtil.isSameDay(newStartTime, newEndTime.minusNanos(1))) {
            throw new BusinessException("RE003", "Extension denied: Cannot extend reservation past midnight of the current reservation day.");
        }

        // "Kiểm tra trùng lặp đặt chỗ RESERVED hoặc IN_USE khác cho cùng ghế trong khoảng [new_start_time, new_end_time]."
        List<Reservation> conflicts = reservationMapper.findConflictingReservations(
                originalReservation.getSeatId(), newStartTime, newEndTime, null); // null: check all others
        if (!conflicts.isEmpty()) {
            throw new BusinessException("RE002", "Cannot extend: Seat is booked by another reservation immediately after the current one ends.");
        }

        // "Kiểm tra giới hạn 8 giờ/ngày: Tính tổng thời gian của *toàn bộ chuỗi đặt chỗ* ... cộng thêm 1 giờ gia hạn mới."
        int totalChainMinutesForDay = calculateTotalChainMinutesForDay(originalReservation.getId(), newStartTime.toLocalDate());
        if (totalChainMinutesForDay + EXTENSION_MINUTES > MAX_DAILY_HOURS * 60) {
            throw new BusinessException("RE004", "Extension denied: Would exceed daily limit of " + MAX_DAILY_HOURS + " hours for the reservation day.");
        }

        Reservation extension = new Reservation();
        extension.setEmployeeId(employeeId);
        extension.setSeatId(originalReservation.getSeatId());
        extension.setStartTime(newStartTime);
        extension.setEndTime(newEndTime);
        extension.setStatus(ReservationStatus.IN_USE); // "status của đặt chỗ mới = IN_USE"
        // "check_in_at của đặt chỗ mới có thể được kế thừa từ đặt chỗ gốc hoặc là start_time của đặt chỗ mới"
        // Since status is IN_USE, it implies check-in. Inheriting original check_in_at makes sense for the chain.
        // Or, if each segment is distinct, newStartTime. Let's use newStartTime as it's a new record.
        // Spec says: "vì trạng thái là IN_USE nên đã check-in".
        // To be precise, if it's a seamless extension, the original check_in_at of the *first* segment matters.
        // For simplicity and a new record, let's use its own start_time as the effective check-in for this segment.
        extension.setCheckInAt(newStartTime);
        extension.setExtendedFromReservationId(originalReservation.getId()); // Link to the immediate predecessor
        extension.setCreatedAt(LocalDateTime.now());

        reservationMapper.insertReservation(extension);
        log.info("Reservation {} extended successfully. New extension ID: {}.", originalReservationId, extension.getId());
        Reservation createdExtension = reservationMapper.findByIdWithDetails(extension.getId());
        return mapToReservationResponse(createdExtension);
    }

    private int calculateTotalChainMinutesForDay(Long anyReservationIdInChain, java.time.LocalDate date) {
        List<Reservation> chain = reservationMapper.findReservationChain(anyReservationIdInChain);
        return chain.stream()
                .filter(r -> r.getStatus() == ReservationStatus.PENDING || r.getStatus() == ReservationStatus.RESERVED || r.getStatus() == ReservationStatus.IN_USE)
                .filter(r -> r.getStartTime().toLocalDate().equals(date)) // Only count parts on the specific day
                .mapToInt(r -> (int) java.time.Duration.between(r.getStartTime(), r.getEndTime()).toMinutes())
                .sum();
    }


    // U0105. Truy xuất Lịch sử Đặt chỗ
    public List<ReservationResponse> getReservationHistory(
            Long employeeId, LocalDate queryStartDate, LocalDate queryEndDate, int skip, int limit) {
        log.info("Fetching reservation history for employeeId: {} from {} to {}, skip: {}, limit: {}",
                employeeId, queryStartDate, queryEndDate, skip, limit);

        if (queryStartDate == null || queryEndDate == null || queryEndDate.isBefore(queryStartDate)) {
            throw new BusinessException("RE001", "Invalid date range for history query.");
        }
        // "Ràng buộc "Lên đến 1 tháng": UI gợi ý người dùng chọn khoảng thời gian, mặc định là tháng hiện tại."
        // Let's interpret this as the query range itself should not exceed roughly one month.
        long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(queryStartDate, queryEndDate);
        if (daysBetween > 31) { // Approximate 1 month
            throw new BusinessException("RE001", "Query date range cannot exceed approximately 1 month (31 days).");
        }

        // "start_time (hoặc created_at - cần làm rõ "ngày đặt chỗ" là gì)"
        // Let's assume "ngày đặt chỗ" refers to the day the reservation is *for* (i.e., based on start_time).
        LocalDateTime startDateTime = queryStartDate.atStartOfDay();
        LocalDateTime endDateTime = queryEndDate.atTime(23, 59, 59, 999999999); // Inclusive end of day

        List<Reservation> reservations = reservationMapper.findByEmployeeIdAndDateRange(
                employeeId, startDateTime, endDateTime, skip, limit);

        return reservations.stream()
                .map(this::mapToReservationResponse)
                .collect(Collectors.toList());
    }

    // U0106. Truy xuất Trạng thái Đặt chỗ của tôi
    public List<ReservationResponse> getMyCurrentReservations(Long employeeId) {
        log.info("Fetching current/active reservations for employeeId: {}", employeeId);
        // "Lọc các đặt chỗ có status là PENDING, RESERVED, IN_USE."
        // "Lọc các đặt chỗ mà end_time >= thời gian hiện tại (UI "từ bây giờ trở đi")"
        LocalDateTime currentTime = LocalDateTime.now();
        List<Reservation> currentReservations = reservationMapper.findActiveReservationsByEmployeeIdForTodayAndFuture(
                employeeId, currentTime // Query filters by status PENDING, RESERVED, IN_USE and end_time >= currentTime
        );
        return currentReservations.stream()
                .map(this::mapToReservationResponse)
                .collect(Collectors.toList());
    }


    // U0202. Check-in
    @Transactional
    public void checkIn(Long employeeId, Long reservationId) {
        log.info("Processing checkIn for employeeId: {}, reservationId: {}", employeeId, reservationId);
        Reservation reservation = reservationMapper.findById(reservationId);
        if (reservation == null) {
            throw new BusinessException("RE001", "Reservation not found.");
        }
        if (!reservation.getEmployeeId().equals(employeeId)) {
            throw new BusinessException("RE003", "Not authorized. This reservation belongs to another employee.");
        }
        if (reservation.getStatus() != ReservationStatus.RESERVED) {
            throw new BusinessException("RE003", "Action not allowed: Can only check-in reservations with RESERVED status. Current status: " + reservation.getStatus());
        }

        Seat seat = seatMapper.findById(reservation.getSeatId());
        if (seat == null) { // Should not happen if DB is consistent
            throw new BusinessException("SE", "System error: Seat associated with reservation not found.");
        }
        if (seat.getStatus() != SeatStatus.AVAILABLE) {
            // "ghế đang AVAILABLE"
            throw new BusinessException("RE003", "Action not allowed: Seat is not AVAILABLE for check-in. Current seat status: " + seat.getStatus());
        }

        // "Cập nhật RESERVATION.status = 'IN_USE', RESERVATION.check_in_at = NOW(), SEAT.status = 'UNAVAILABLE'."
        reservationMapper.updateCheckIn(reservationId, LocalDateTime.now(), ReservationStatus.IN_USE);
        seatMapper.updateStatus(reservation.getSeatId(), SeatStatus.UNAVAILABLE);
        log.info("Check-in successful for reservation {}. Seat {} is now UNAVAILABLE.", reservationId, reservation.getSeatId());
    }

    // U0205. Trả Ghế (Check-out)
    @Transactional
    public void checkOut(Long employeeId, Long reservationId) {
        log.info("Processing checkOut for employeeId: {}, reservationId: {}", employeeId, reservationId);
        // The reservationId passed could be any part of an extension chain.
        Reservation targetReservation = reservationMapper.findById(reservationId);
        if (targetReservation == null) {
            throw new BusinessException("RE001", "Reservation not found.");
        }
        if (!targetReservation.getEmployeeId().equals(employeeId)) {
            throw new BusinessException("RE003", "Not authorized. This reservation belongs to another employee.");
        }
        // "đặt chỗ IN_USE"
        if (targetReservation.getStatus() != ReservationStatus.IN_USE) {
            throw new BusinessException("RE003", "Action not allowed: Can only check-out reservations with IN_USE status. Current status: " + targetReservation.getStatus());
        }

        Seat seat = seatMapper.findById(targetReservation.getSeatId());
        if (seat == null) {
            throw new BusinessException("SE", "System error: Seat associated with reservation not found.");
        }
        // "ghế UNAVAILABLE"
        if (seat.getStatus() != SeatStatus.UNAVAILABLE) {
            // This indicates a potential inconsistency if the reservation is IN_USE but seat is not UNAVAILABLE.
            log.warn("Potential inconsistency: Reservation {} is IN_USE, but seat {} status is {}. Proceeding with checkout.",
                    targetReservation.getId(), seat.getId(), seat.getStatus());
        }

        // "Xử lý chuỗi gia hạn: Nếu target_reservation là một phần của chuỗi gia hạn ...
        //  Chuyển status của tất cả các đặt chỗ IN_USE (hoặc RESERVED cho các phần tương lai chưa bắt đầu) trong chuỗi này thành COMPLETED."
        List<Reservation> chain = reservationMapper.findReservationChain(targetReservation.getId());
        List<Long> chainIdsToComplete = new ArrayList<>();
        boolean foundTargetInChain = false;

        for (Reservation r : chain) {
            if (r.getId().equals(targetReservation.getId())) {
                foundTargetInChain = true;
            }
            // Complete current IN_USE parts and any future RESERVED parts of this chain.
            // Past IN_USE parts should also be marked COMPLETED if not already.
            if (r.getStatus() == ReservationStatus.IN_USE ||
                    (r.getStatus() == ReservationStatus.RESERVED && r.getStartTime().isAfter(targetReservation.getStartTime()))) { // Future reserved parts
                chainIdsToComplete.add(r.getId());
            }
        }
        // Ensure the target reservation itself is included if it met criteria or is the one being acted upon.
        if (foundTargetInChain && !chainIdsToComplete.contains(targetReservation.getId()) && targetReservation.getStatus() == ReservationStatus.IN_USE) {
            chainIdsToComplete.add(targetReservation.getId());
        }


        if (!chainIdsToComplete.isEmpty()) {
            reservationMapper.updateReservationChainStatus(chainIdsToComplete, ReservationStatus.COMPLETED);
            log.info("Reservation chain IDs {} marked as COMPLETED.", chainIdsToComplete);
        } else if (targetReservation.getStatus() == ReservationStatus.IN_USE) { // Single reservation not in a formal chain but is IN_USE
            reservationMapper.updateStatus(targetReservation.getId(), ReservationStatus.COMPLETED);
            log.info("Single reservation {} marked as COMPLETED.", targetReservation.getId());
        }


        // "Cập nhật seat.status = 'AVAILABLE'."
        // More robust: check if any *other* reservation (not part of this chain) makes the seat UNAVAILABLE.
        // For now, following spec directly.
        seatMapper.updateStatus(targetReservation.getSeatId(), SeatStatus.AVAILABLE);
        log.info("Check-out successful for reservation (or chain starting with) {}. Seat {} is now AVAILABLE.", reservationId, targetReservation.getSeatId());
    }

    // Helper to map Reservation entity to ReservationResponse DTO
    // Ensure this method is comprehensive based on ReservationResponse DTO definition.
    private ReservationResponse mapToReservationResponse(Reservation reservation) {
        if (reservation == null) return null;
        ReservationResponse dto = new ReservationResponse();
        dto.setId(reservation.getId());
        dto.setEmployeeId(reservation.getEmployeeId());
        // EmployeeName is not directly in Reservation entity; would come from HR if needed.
        // dto.setEmployeeName(reservation.getEmployeeName());
        dto.setSeatId(reservation.getSeatId());
        if (reservation.getSeat() != null) {
            dto.setSeatNumber(reservation.getSeat().getSeatNumber());
            if (reservation.getSeat().getFloor() != null) {
                dto.setFloorName(reservation.getSeat().getFloor().getName());
                // Building name could be on seat.building or via seat.floor.building
                /* logic to fetch building name by floor.building_id if not directly joined */
                if (reservation.getSeat().getBuilding() != null) { // Prefer direct join if available
                    dto.setBuildingName(reservation.getSeat().getBuilding().getName());
                }
            }
        }
        dto.setStartTime(reservation.getStartTime());
        dto.setEndTime(reservation.getEndTime());
        dto.setStatus(reservation.getStatus());
        dto.setCreatedAt(reservation.getCreatedAt());
        dto.setCheckInAt(reservation.getCheckInAt());
        dto.setExtendedFromReservationId(reservation.getExtendedFromReservationId());
        return dto;
    }
}
