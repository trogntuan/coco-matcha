package com.lgcns.team17.aidd.fzrevc.entity;

import com.lgcns.team17.aidd.fzrevc.enums.ReservationStatus;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Reservation {
    private Long id;
    private Long employeeId;
    private Long seatId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private ReservationStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime checkInAt;
    private Long extendedFromReservationId;

    // Joined fields
    private Seat seat;
    private String employeeName;
    private String employeeEmail;
}
