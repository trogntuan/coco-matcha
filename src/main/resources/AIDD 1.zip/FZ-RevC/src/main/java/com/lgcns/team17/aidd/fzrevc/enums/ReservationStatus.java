package com.lgcns.team17.aidd.fzrevc.enums;

public enum ReservationStatus {
    PENDING, RESERVED, IN_USE, COMPLETED, CANCELLED, NO_SHOW, FAIL, FORCED_CANCEL
}
