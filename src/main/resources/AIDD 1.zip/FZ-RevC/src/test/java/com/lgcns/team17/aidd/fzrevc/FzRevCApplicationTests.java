package com.lgcns.team17.aidd.fzrevc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FzRevCApplicationTests {

    @Test
    void contextLoads() {
    }

}
